import unittest
from unittest.mock import MagicMock, patch
from config_modules_vmware.esxi.config_model.authorization_config_model import  AuthorizationData, DcuiAccess, Permissions, SystemUsers
from config_modules_vmware.esxi.config_submodules.authorization_config import AuthorizationConfig



class TestAuthorizationConfig(unittest.TestCase):
    def setUp(self):
        self.context = MagicMock()
        self.host_ref = MagicMock()
        self.host_ref.name = "test_host"
        self.authorization_config = AuthorizationConfig(self.context)

    def test_get_dcui_access(self):
        mock_option_1 = MagicMock(key="DCUI.Access", value="user1")
        mock_option_2 = MagicMock(key="Other.Option", value="value")
        self.host_ref.config.option = [mock_option_1, mock_option_2]

        dcui_obj = self.authorization_config._get_dcui_access(self.host_ref)
        expected_dcui_obj = DcuiAccess(["user1"])
        self.assertEqual(dcui_obj.to_dict(), expected_dcui_obj.to_dict())

    def test_get_permissions(self):
        self.maxDiff = None 
        mock_esxcli_client = self.context.esxcli_client.return_value
        mock_esxcli_client.host.return_value.namespace.return_value.command.return_value.execute.return_value = [
            {"Role": "Admin", "IsGroup": False, "Principal": "user1"},
            {"Role": "Operator", "IsGroup": True, "Principal": "group1"},
        ]

        permission_data = self.authorization_config._get_permissions(self.host_ref)
        permission_data[0] = permission_data[0].to_dict()
        permission_data[1] = permission_data[1].to_dict()
        expected_permission_data = [
            Permissions("Admin", False, "user1").to_dict(),
            Permissions("Operator", True, "group1").to_dict(),
        ]
        self.assertEqual(permission_data, expected_permission_data)

    def test_get_system_users(self):
        self.maxDiff = None 
        mock_esxcli_client = self.context.esxcli_client.return_value
        mock_esxcli_client.host.return_value.namespace.return_value.command.return_value.execute.return_value = [
            {"UserID": "user1"},
            {"UserID": "user2"},
        ]

        sys_user_obj = self.authorization_config._get_system_users(self.host_ref)
        expected_sys_user_obj = SystemUsers(["user1", "user2"])
        self.assertEqual(sys_user_obj.to_dict(), expected_sys_user_obj.to_dict())

    def test_get_configuration(self):
        self.authorization_config._get_dcui_access = MagicMock(return_value=DcuiAccess(["user1"]))
        self.authorization_config._get_permissions = MagicMock(return_value=[
            Permissions("Admin", False, "user1"),
            Permissions("Operator", True, "group1"),
        ])
        self.authorization_config._get_system_users = MagicMock(return_value=SystemUsers(["user1"]))

        config = self.authorization_config.get_configuration(self.host_ref)

        expected_config = AuthorizationData(
            DcuiAccess(["user1"]),
            [
                Permissions("Admin", False, "user1"),
                Permissions("Operator", True, "group1"),
            ],
            SystemUsers(["user1"])
        ).to_dict()
        self.assertEqual(config, expected_config)