# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from config_modules_vmware.lib.common.credentials import SddcCredentials


class Context:
    """
    Class provides baseclass to be extended by context classes for each module
    e.g EsxContext. Context objects should be placeholder for the various data
    needed for config objects to work on to deliver the config management functionalities.

    Respective child context classes extending this class should define the structure
    needed to hold various data/objects for the corresponding config module to work on.
    and common objects or methods should be defined here in the parent class.
    """
    def __init__(self, sddc_credentials: SddcCredentials):
        """
        Initialize base Context.

        :param sddc_credentials: The Sddc credentials.
        :type sddc_credentials: SddcCredentials
        """
        self._sddc_credentials = sddc_credentials
