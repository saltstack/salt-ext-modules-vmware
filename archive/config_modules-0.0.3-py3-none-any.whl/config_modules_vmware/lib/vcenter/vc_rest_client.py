# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from functools import partial
from http import HTTPStatus
import logging
import math
import time
import urllib3
import json

from config_modules_vmware.lib.common.consts import JSON_REQUEST_HEADERS
from config_modules_vmware.lib.vcenter import vc_consts
from config_modules_vmware.lib.common.credentials import VcenterCredentials
from config_modules_vmware.lib.common.rest_client import get_smart_rest_client, SmartRestClient
from config_modules_vmware.lib.common import consts

# Set up logger
logger = logging.getLogger(__name__)


class VcRestClient(object):
    """
    Class that exposes vCenter REST APIs to handle session. This may be used
    as the base class for other vCenter REST API client classes.
    """

    def __init__(self, vc_access: VcenterCredentials):
        """
        :type vc_access: :class:`VcenterCredentials`
        :param vc_access: credentials used to connect to vcenter.
        """
        self._vc_access = vc_access
        self._base_url = vc_consts.VC_API_BASE.format(self._vc_access.hostname)
        self._vcsa_version = None

        # Set up REST client
        get_session_headers = partial(
            VcRestClient._create_vmware_api_session_id,
            hostname=self._vc_access.hostname,
            username=self._vc_access.username,
            password=self._vc_access.password
        )
        delete_session = partial(
            VcRestClient._delete_session_by_hostname,
            hostname=self._vc_access.hostname
        )
        if vc_access.ssl_thumbprint:
            self._rest_client_session = get_smart_rest_client(
                assert_fingerprint=vc_access.ssl_thumbprint,
                get_session_headers_func=get_session_headers,
                delete_session_func=delete_session
            )
        else:
            self._rest_client_session = get_smart_rest_client(
                cert_reqs=consts.CERT_NONE,
                get_session_headers_func=get_session_headers,
                delete_session_func=delete_session
            )

        self.set_vcsa_version()

    @staticmethod
    def _create_vmware_api_session_id(client, hostname, username, password):
        """
        Make REST call to create vmware api session id.
        Vmware api session id is used for authentication.
        :param client: Rest client.
        :type client: 'urllib3.poolmanager.PoolManager'
        :param hostname: Host name
        :type hostname: 'str'
        :param username: User name
        :type username: 'str'
        :param password: Password
        :type password: 'str'
        :raise :class:`urllib3.exceptions.HTTPError`
            If REST call response has a non HTTPStatus.OK status code.
        """
        logger.info("Creating vmware api session")

        url = vc_consts.SESSION_ID_URL % hostname
        basic_auth_header = urllib3.make_headers(
            basic_auth="{}:{}".format(username, password))

        # Make REST request
        response = client.request(method='POST', url=url,
                                  headers=basic_auth_header)

        # Raise urllib3.exceptions.HTTPError
        # If the HTTP request returns an unsuccessful status code
        SmartRestClient.raise_for_status(response, url)

        # Parse response for vmware api session id.
        content_dict = SmartRestClient.extract_json_data(response)
        vmware_api_session_id = content_dict["value"]
        headers = \
            {vc_consts.VMWARE_API_SESSION_ID: vmware_api_session_id}

        logger.info("Successfully created vmware api session")
        return headers

    @staticmethod
    def _delete_session_by_hostname(client, hostname, session_headers):
        """
        Delete a session
        :param client: Rest client.
        :type client: 'urllib3.PoolManager'
        :param hostname: Host.
        :type hostname: 'str'
        :param session_headers: Rest call header of the to be deleted
            VMware API session ID
        :type session_headers: 'dict'
        """
        logger.info("Deleting vmware api session id")
        url = vc_consts.SESSION_ID_URL % hostname
        response = client.request(
            method='DELETE', url=url, headers=session_headers)
        logger.info(F"Response Code of 'DELETE' request on '{url}': {response.status}")
        logger.debug(F"Response content of 'DELETE' request on '{url}': {response.data}")
        if response.status == HTTPStatus.OK:
            logger.info(F"Delete vmware api session id succeeded. {str(session_headers)}")
        else:
            logger.warning(F"Failed to delete vmware api session id. "
                           F"Session might have already expired. {str(session_headers)}")

    def delete_vmware_api_session_id(self):
        """
        Make REST call to delete the vmware api session id.
        Vmware api session id is used for authentication.
        :raise :class:`urllib3.exceptions.RequestException`
            If REST call response reports failed.
        """
        self._rest_client_session.delete_session()

    def vcsa_request(self, url, method, **kwargs):
        """
        Invokes VCSA API request
        :param url: URL of the request.
        :type url: 'str'
        :param method: Request type
        :type method: 'str'
        :param kwargs: Parameters used by the request.
        :type kwargs: 'dict'
        :return: http response
        :rtype: 'HTTPResponse'
        """

        body = json.dumps(kwargs['body']) if 'body' in kwargs else None
        if 'headers' in kwargs:
            headers = {**kwargs['headers'], **JSON_REQUEST_HEADERS}
        else:
            headers = JSON_REQUEST_HEADERS.copy()
        if 'timeout' in kwargs:
            timeout = kwargs['timeout']
        else:
            timeout = urllib3.Timeout(
                total=vc_consts.VC_REST_API_TIMEOUT_VALUE)

        return self._rest_client_session.request(url=url, method=method,
                                                 body=body, headers=headers,
                                                 timeout=timeout)

    @staticmethod
    def _get_str_from_response(response):
        """
        Parse and get string result from http response.
        :param response: Existed http response.
        :return: Result as string.
        """
        result = str(SmartRestClient.decode_data(response))
        return result[1:-1]

    def _handle_response(self, url, response, **kwargs):
        """
        Handle http response according to given kwargs
        :param url:
        :param response:
        :param kwargs:
            raw_response: True if want to return response object,
                False otherwise.
            json_result: True if want to parse json result and return as dict,
                False will return result as string.
            raise_for_status: True if want to raise exception when
                response status code is not 200, False otherwise.
        :return: HTTPResponse, dict or str depends on kwargs.
        """
        if response.status == HTTPStatus.NO_CONTENT:
            logger.info("%s: 204 No Content", url)
            return None
        raise_for_status = kwargs["raise_for_status"] if "raise_for_status" \
                                                         in kwargs else True
        raw_response = kwargs["raw_response"] \
            if "raw_response" in kwargs else False
        json_result = kwargs["json_result"] if "json_result" in kwargs \
            else True
        if raise_for_status:
            SmartRestClient.raise_for_status(response, url)
        if raw_response:
            return response
        elif json_result:
            return SmartRestClient.extract_json_data(response)
        else:
            return self._get_str_from_response(response)

    def get_helper(self, url, **kwargs):
        """
        Make a HTTP GET request.
        :param url: Target http url
        :return: HTTPResponse, dict or str depends on kwargs.
        """
        response = self.vcsa_request(url, method='GET', **kwargs)
        return self._handle_response(url, response, **kwargs)

    def delete_helper(self, url, **kwargs):
        """
        Make a HTTP DELETE request.
        :param url: Target http url
        :return: HTTPResponse, dict or str depends on kwargs.
        """
        response = self.vcsa_request(url, method='DELETE', **kwargs)
        return self._handle_response(url, response, **kwargs)

    def post_helper(self, url, **kwargs):
        """
        Make a HTTP POST request.
        :param url: Target http url
        :return: HTTPResponse, dict or str depends on kwargs.
        """
        response = self.vcsa_request(url, method='POST', **kwargs)
        return self._handle_response(url, response, **kwargs)

    def put_helper(self, url, **kwargs):
        """
        Make a HTTP PUT request.
        :param url: Target http url
        :return: HTTPResponse, dict or str depends on kwargs.
        """
        response = self.vcsa_request(url, method='PUT', **kwargs)
        return self._handle_response(url, response, **kwargs)

    def patch_helper(self, url, **kwargs):
        """
        Make a HTTP PATCH request.
        :param url: Target http url
        :return: HTTPResponse, dict or str depends on kwargs.
        """

        response = self.vcsa_request(url, method='PATCH', **kwargs)
        return self._handle_response(url, response, **kwargs)

    @staticmethod
    def validate_cis_task_response(task_id: str, task_response: dict) -> dict:
        """
        Validate that the CIS task response and return CIS task value.
        :param task_id: CIS Task ID.
        :param task_response: CIS task response.
        :return: CIS task's value if valid, otherwise raise exception.
        """
        # Missing "value"
        if vc_consts.CIS_TASK_KEY_VALUE not in task_response:
            err_msg = F"Key {vc_consts.CIS_TASK_KEY_VALUE} not found in CIS task response," \
                      F"CIS task: {task_id} returned unexpected response"
            raise err_msg
        value = task_response["value"]

        # Missing "status"
        if vc_consts.CIS_TASK_KEY_STATUS not in value:
            err_msg = F"Key {vc_consts.CIS_TASK_KEY_STATUS} not found in CIS task response," \
                      F"CIS task: {task_id} returned unexpected response"
            raise err_msg

        return value

    def get_cis_task_info(self, task_id: str) -> dict:
        """
        Fetch the CIS task info for the given task_id
        :param task_id: Identifier of the task
        :return: Task info
        """
        url = self._base_url + vc_consts.CIS_TASKS_URL.format(task_id)
        return self.get_helper(url)

    def _wait_for_cis_task_completion(self, task_id, timeout=consts.SECS_IN_5_MINS,
                                      retry_wait_time=consts.SECS_30):
        """
        Wait for a timeout duration for the task to change to a terminal state.
        :type task_id: :class:'vim.task-id'
        :param task_id: task_id to wait.
        :type timeout: :class:'integer'
        :param timeout: wait timeout.
        :return: None
        """
        retry_count = math.ceil(timeout/retry_wait_time) + 1
        for retry in range(retry_count):
            json_response = self.get_cis_task_info(task_id)
            value = self.validate_cis_task_response(task_id, json_response)
            status = value[vc_consts.CIS_TASK_KEY_STATUS]
            if status in vc_consts.CIS_TASK_TERMINAL_STATUS:
                return value
            elif status in vc_consts.CIS_TASK_ACTIVE_STATUS:
                if retry < retry_count - 1:
                    time.sleep(retry_wait_time)
                    logger.info(F"Waiting for cis task completion for "
                                F"task_id:{task_id} Retry: {retry + 1}/{retry_count - 1}")
            else:
                return value

    def set_vcsa_version(self):
        """
        Set VCSA version.

        return: None
        """
        self._vcsa_version = self.get_vcsa_version()
        logger.info(F"Setting the VCSA version to {self._vcsa_version} in the vc rest client")

    def get_vcsa_version(self):
        """
        Make REST call to get the version of vCenter,
        return version of the vCenter.

        :rtype :class:`str`
        :return: The version of the vCenter.
        :raise :class:`urllib3.exceptions`
            If REST call response reports failed.
        """
        if self._vcsa_version:
            return self._vcsa_version

        url = self._base_url + vc_consts.VC_SYSTEM_VERSION_URL

        # Make REST request
        response = self.get_helper(url)
        return response["value"]["version"]

