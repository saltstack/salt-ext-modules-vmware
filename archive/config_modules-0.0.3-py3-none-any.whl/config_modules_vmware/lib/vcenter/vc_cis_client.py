# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging

from config_modules_vmware.lib.common.credentials import VcenterCredentials
from config_modules_vmware.lib.vcenter.vc_rest_client import VcRestClient

# Set up logger
logger = logging.getLogger(__name__)


class VcCisClient(VcRestClient):
    """
    Class to provide helper functions invoke  VCENTER CIS REST APIs.
    """

    def __init__(self, vc_access: VcenterCredentials):
        """
        :type vc_access: :class:`VcenterCredentials`
        :param vc_access: credentials used to connect to vcenter.
        """
        super(VcCisClient, self).__init__(vc_access)
        self._cis_base_url = self._base_url + "api/cis/"

    def get_task(self, task_id):
        """
        Get task info.
        """
        url = self._cis_base_url + "tasks/{}".format(task_id)
        return self.get_helper(url=url)
