# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl
from config_modules_vmware.esxi.config_model.hardware_config_model import UsbPassThroughSwitch, HardwareConfigData

logger = logging.getLogger(__name__)

class HardwareConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the hardware configs of ESXi host.
    """

    MODULE_NAME = 'hardware'

    def __init__(self, context):
        self._context = context

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns authorization configuration for the ESXi host
        """
        usb_pass_thru_data = self._get_usb_passthroguh_list(host_ref)
        esx_hardware_obj = HardwareConfigData(usb_pass_thru_data)

        return esx_hardware_obj.to_dict()

    def _get_usb_passthroguh_list(self, host_ref):
        """
        Fetch details of  usb pass throguh list  on the esxi host
        """
        logger.info(
            F"Populating the  USB PASS through list  host: {host_ref.name}")
        usb_pass_thru_list = []
        resp_data = self._context.esxcli_client().host(host_ref.name). namespace(
            ["hardware", "usb", "passthrough", "device"]).command("list").execute()
            
        for item in resp_data:
            usb_pass_thru_obj = UsbPassThroughSwitch(item['Bus'],
                                                 item["Dev"],
                                                 item["VendorId"],
                                                 item["ProductId"],
                                                 item["Enabled"])
            usb_pass_thru_list.append(usb_pass_thru_obj.to_dict())

        return usb_pass_thru_list

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME


