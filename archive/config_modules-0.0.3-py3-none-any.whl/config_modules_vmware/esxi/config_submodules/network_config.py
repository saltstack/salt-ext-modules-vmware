# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl


class NetworkConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the network configs of ESXi host.
    """

    MODULE_NAME = 'network'

    def __init__(self, context):
        pass

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns network configuration for the ESXi host.
        """
        pass

