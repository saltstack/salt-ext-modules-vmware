# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import click
import typing as t


class ModuleChoiceType(click.Choice):
    """
    Click custom Choice type option.
    Converts and formats input from command line into an enum for modules and submodules.
    """
    _enumCls = None

    def __init__(self, enumCls, choices: t.Sequence[str] = None, case_sensitive: bool = True) -> None:
        if choices is None:
            choices = enumCls.choice_list()
        super().__init__(choices, case_sensitive)
        self._enumCls = enumCls

    def convert(self, value, param, ctx):
        """
        Converts values from command line.
        Validates it is one of the valid choices and appends it to a list.
        """
        val_list = value.split(',')
        ret_list = []
        for val in val_list:
            val = val.strip().upper()
            if val not in self.choices:
                choices_str = ", ".join(map(repr, self.choices))
                self.fail(
                    "{value!r} is not one of {choices}.".format(value=val, choices=choices_str),
                    param,
                    ctx,
                )
            ret_list.append(val)
        return ret_list

    def module_formatter(self, ctx, param, value):
        """
        Processes the final value before it is sent to the function.
        In a case where the param can be sent multiple times, it combines all the lists into one.
        If there is only one, it converts the single value to the Enum class type.
        """
        if not param.multiple:
            return self._enumCls[value[0]]
        ret_list = []
        for sublist in value:
            for val in sublist:
                ret_list.append(self._enumCls[val])
        return ret_list
