# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import unittest

from config_modules_vmware.esxi.config_model.base_model import BaseModel


class PropertyClass(BaseModel):

    def __init__(self, nested_property=None, private_nested_property=None, null_nested_property=None):
        self._nested_property = nested_property
        self._private_nested_property = private_nested_property
        self._null_nested_property = null_nested_property

    @property
    def nested_property(self):
        """Get nested property to return"""
        return self._nested_property

    @nested_property.setter
    def nested_property(self, nested_property: None):
        """Set nested property"""
        self._nested_property = nested_property


class Module(BaseModel):

    def __init__(self, return_property=None, nested_class=None, private_property=None, null_property=None):
        self._return_property = return_property
        self._nested_class: PropertyClass = nested_class
        self._private_property = private_property
        self._null_property = null_property

    @property
    def return_property(self):
        """Get property to return"""
        return self._return_property

    @return_property.setter
    def return_property(self, return_property: None):
        """Set return property"""
        self._return_property = return_property

    @property
    def nested_class(self):
        """Get nested class to return"""
        return self._nested_class

    @nested_class.setter
    def nested_class(self, nested_class: None):
        """Set nested class"""
        self._nested_class = nested_class

    def class_method(self):
        pass


class TestBaseModel(unittest.TestCase):

    def test_to_dict(self):
        """
        Test class to test to_dict method to return only properties with valid getter method.
        """
        module = Module()
        module.return_property = "return_property_value"
        module._private_property = "private_property_value"
        nested_property_class = PropertyClass()
        nested_property_class.nested_property = "return_property_value"
        nested_property_class._private_nested_property = "private_property_value"
        module.nested_class = nested_property_class

        # test to remove private attributes and attributes with null values
        returned_dict = module.to_dict(strip_privates=True, strip_null=True)
        assert "return_property" in returned_dict
        assert "_private_property" not in returned_dict
        assert "_null_property" not in returned_dict
        assert "class_method" not in returned_dict
        nested_property_class = returned_dict.get("nested_class")
        assert nested_property_class is not None
        assert "nested_property" in nested_property_class
        assert "_private_nested_property" not in nested_property_class
        assert "_null_nested_property" not in nested_property_class

        # test to include private attributes but skip attributes with null values
        returned_dict = module.to_dict(strip_privates=False, strip_null=True)
        assert "_private_property" in returned_dict
        assert "_null_property" not in returned_dict
        nested_property_class = returned_dict.get("nested_class")
        assert "_private_nested_property" in nested_property_class
        assert "_null_nested_property" not in nested_property_class

        # test to include both private attributes and attributes with null values
        returned_dict = module.to_dict(strip_privates=False, strip_null=False)
        assert "_private_property" in returned_dict
        assert "_null_property" in returned_dict
        nested_property_class = returned_dict.get("nested_class")
        assert "_private_nested_property" in nested_property_class
        assert "_null_nested_property" in nested_property_class
