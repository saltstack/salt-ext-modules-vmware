# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json
import os
import requests.exceptions
import requests_mock

from pytest_console_scripts import ScriptRunner
from unittest import mock
from unittest.mock import patch
from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.tests.cli import test_config_module_cli


@patch.object(EsxContext, '__init__')
def test_create_vc_credentials_token(mock_esx_context_init, script_runner: ScriptRunner) -> None:
    """
    Test to validate creating vcenter credentials using a provided token.
    @param mock_esx_context_init: mocked __init__ function for EsxContext
    @param script_runner:
    """
    mock_esx_context_init.return_value = None
    ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',
                             '--vc-fqdn', 'test_fqdn', '--auth-token', 'test_token'],
                            print_result=True, shell=True)
    assert mock_esx_context_init.call_count == 1
    received_vc_creds = mock_esx_context_init.call_args[0][0].vc_creds
    assert received_vc_creds.username is None
    assert received_vc_creds.password is None
    assert received_vc_creds.hostname == 'test_fqdn'
    assert received_vc_creds.saml_token == 'test_token'
    assert received_vc_creds.ssl_thumbprint is None
    assert not ret.success


@patch.object(EsxContext, '__init__')
def test_create_vc_credentials_username_password_thumbprint(mock_esx_context_init, script_runner: ScriptRunner) -> None:
    """
    Test to validate creating vcenter credentials using username, password and thumbprint.
    @param mock_esx_context_init: mocked __init__ function for EsxContext
    @param script_runner:
    """
    mock_esx_context_init.return_value = None
    ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',

                             '--vc-fqdn', 'test_fqdn', '--password', 'test_password', '--username', 'test_username',
                             '--ssl-thumbprint', 'test_thumbprint'],
                            print_result=True, shell=True)
    assert mock_esx_context_init.call_count == 1
    received_vc_creds = mock_esx_context_init.call_args[0][0].vc_creds
    assert received_vc_creds.username == 'test_username'
    assert received_vc_creds.password == 'test_password'
    assert received_vc_creds.hostname == 'test_fqdn'
    assert received_vc_creds.saml_token is None
    assert received_vc_creds.ssl_thumbprint == 'test_thumbprint'

    assert not ret.success


@patch.object(EsxContext, '__init__')
def test_create_vc_credentials_password_from_environment_variable(mock_esx_context_init,
                                                                  script_runner: ScriptRunner) -> None:
    """
    Test to validate creating vcenter credentials using a password that is stored as an environment variable.
    @param mock_esx_context_init: mocked __init__ function for EsxContext
    @param script_runner:
    """
    mock_esx_context_init.return_value = None
    mock_env_vars = mock.patch.dict(os.environ, {'test_env_var': 'test_password'})
    mock_env_vars.start()
    ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',

                             '--vc-fqdn', 'test_fqdn', '--password', 'env:test_env_var', '--username', 'test_username',
                             '--ssl-thumbprint', 'test_thumbprint'],
                            print_result=True, shell=True)
    mock_env_vars.stop()
    assert mock_esx_context_init.call_count == 1
    received_vc_creds = mock_esx_context_init.call_args[0][0].vc_creds
    assert received_vc_creds.username == 'test_username'
    assert received_vc_creds.password == 'test_password'
    assert received_vc_creds.hostname == 'test_fqdn'
    assert received_vc_creds.saml_token is None
    assert received_vc_creds.ssl_thumbprint == 'test_thumbprint'

    assert not ret.success


@patch.object(EsxContext, '__init__')
def test_create_vc_credentials_password_from_environment_variable_does_not_exist(mock_esx_context_init,
                                                                                 script_runner: ScriptRunner) -> None:
    """
    Test to validate errors when an environment variable passed for a password does not exist.
    @param mock_esx_context_init: mocked __init__ function for EsxContext
    @param script_runner:
    """
    mock_esx_context_init.return_value = None
    mock_env_vars = mock.patch.dict(os.environ, {'something': 'test_password', 'AGENT_NAME': 'stderr'})
    mock_env_vars.start()
    ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',

                             '--vc-fqdn', 'test_fqdn', '--password', 'env:test_env_var', '--username', 'test_username',
                             '--ssl-thumbprint', 'test_thumbprint'],
                            print_result=True, shell=True)
    mock_env_vars.stop()
    assert mock_esx_context_init.call_count == 0
    returned_response = json.loads(ret.stdout)
    assert returned_response == test_config_module_cli.FAILED_RESPONSE
    assert "The environment variable test_env_var does not exist or cannot be accessed." in ret.stderr
    assert not ret.success


@patch.object(EsxContext, '__init__')
def test_create_vc_credentials_auth_url(mock_esx_context_init, script_runner: ScriptRunner) -> None:
    """
    Test to validate creating vcenter credentials after retrieving a saml_token from an auth-url.
    @param mock_esx_context_init: mocked __init__ function for EsxContext
    @param script_runner:
    """
    with requests_mock.Mocker() as requests_mocker:
        requests_mocker.get('http://test.com', json={'token': 'test_token'})
        mock_esx_context_init.return_value = None

        ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',

                                 '--vc-fqdn', 'test_fqdn', '--password', 'test_password', '--username', 'test_username',
                                 '--auth-url', 'http://test.com'],
                                print_result=True, shell=True)

        assert mock_esx_context_init.call_count == 1
        received_vc_creds = mock_esx_context_init.call_args[0][0].vc_creds
        assert received_vc_creds.username is None
        assert received_vc_creds.password is None
        assert received_vc_creds.hostname == 'test_fqdn'
        assert received_vc_creds.saml_token == 'test_token'
        assert received_vc_creds.ssl_thumbprint is None

        assert not ret.success


@patch.object(EsxContext, '__init__')
def test_create_vc_credentials_auth_url_failed_request(mock_esx_context_init, script_runner: ScriptRunner) -> None:
    """
    Test to validate errors when the rest request to the provided auth-url fails.
    @param mock_esx_context_init: mocked __init__ function for EsxContext
    @param script_runner:
    """
    with requests_mock.Mocker() as requests_mocker:
        requests_mocker.get('http://test.com', exc=requests.exceptions.ConnectTimeout)
        mock_esx_context_init.return_value = None

        mock_env_vars = mock.patch.dict(os.environ, {'something': 'test_password', 'AGENT_NAME': 'stderr'})
        mock_env_vars.start()
        ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',

                                 '--vc-fqdn', 'test_fqdn', '--password', 'test_password', '--username', 'test_username',
                                 '--auth-url', 'http://test.com'],
                                print_result=True, shell=True)
        mock_env_vars.stop()
        assert mock_esx_context_init.call_count == 0
        returned_response = json.loads(ret.stdout)
        assert returned_response == test_config_module_cli.FAILED_RESPONSE
        assert "There was a problem connecting to auth url to retrieve the saml token. Error info" in ret.stderr
        assert not ret.success
