# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import ssl

# Rest client related
HTTPS_URL = "https://"
SSL_VERIFY_CA_PATH = '/etc/ssl/certs/'
TLS_VERSION = ssl.PROTOCOL_TLSv1_2
CERT_REQUIRED = 'CERT_REQUIRED'
CERT_NONE = 'CERT_NONE'
STATUS_FORCE_LIST_FOR_RETRY = [404, 500, 502, 503, 504]
JSON_REQUEST_HEADERS = {
    'Content-Type': 'application/json'
}

# Constants regarding time
SECS_5 = 5
SECS_10 = 10
SECS_15 = 15
SECS_30 = 30
SECS_60 = 60
SECS_75 = 75
SECS_IN_2_MINS = 2 * 60  # Number of seconds in 2 minutes
SECS_IN_3_MINS = 3 * 60  # Number of seconds in 3 minutes
SECS_IN_5_MINS = 5 * 60  # Number of seconds in 5 minutes
SECS_IN_10_MINS = 10 * 60  # Number of seconds in 10 minutes
SECS_IN_15_MINS = 15 * 60  # Number of seconds in 15 minutes
SECS_IN_30_MINS = 30 * 60  # Number of seconds in 30 minutes
SECS_IN_60_MINS = 60 * 60  # Number of seconds in 60 minutes

# Drift Detection alog related
STATIC_KEY_MAP = "static_key_map"
REGEX_KEY_MAP = "regex_key_map"
COMPLIANCE_STATUS = "compliance_status"
NON_COMPLIANT = "NON_COMPLIANT"
COMPLIANT = "COMPLIANT"
DRIFTS = "drifts"
DRIFT_KEY_DESIRED = "desired"
DRIFT_KEY_CURRENT = "current"
DRIFT_KEY_KEY = "key"
