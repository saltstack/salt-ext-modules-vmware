# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import csv
import io
import logging
import shutil
import subprocess


logger = logging.getLogger(__name__)


class EsxCli(object):
    """
    Wrapper for invoking esxcli command
    """

    def __init__(self):
        self._path = None
        self._host = None
        self._credential = None
        self._namespaces = []
        self._command = None
        self._esxcli_options = ['--formatter', 'csv']
        self._command_options = []

    def clear(self):
        """Clears the current state

        Returns:
            EsxCli: self
        """
        self._path = None
        self._host = None
        self._credential = None
        self._namespaces = []
        self._command = None
        self._esxcli_options = ['--formatter', 'csv']
        self._command_options = []
        return self

    def credential(self, credential):
        """Sets credential to be used while invoking esxcli

        Args:
            credential (VcenterCredentials): Credential

        Returns:
            EsxCli: self
        """
        self._credential = credential
        return self

    def namespace(self, namespace):
        """Sets or Append the namespace.
        If str argument is provided, the given value will be added to namespace hierarchy.
        if list<str> is provided, that will be set as the namespaces clearing existing values

        Args:
            namespace (str|list): single namespace as string or multiple namespaces as a List

        Returns:
            EsxCli: self
        """
        if isinstance(namespace, list):
            self._namespaces = [str(item) for item in namespace]
        else:
            self._namespaces.append(str(namespace))
        return self

    def esxcli_option(self, key, value=None):
        """esxcli binaries options to be set. This is different from namespace command's options

        Args:
            key (str): Option name
            value (str, optional): Option's value. Defaults to None.

        Returns:
            EsxCli: self
        """
        option = ""
        if value:
            option = f"{key} {value}"
        else:
            option = key

        self._esxcli_options.append(str(option))
        return self

    def command_options(self, key, value=None):
        """Sets the command options to be used. This is differnt than esxcli option

        Args:
            key (str): Option name
            value (str, optional): Option's value. Defaults to None.

        Returns:
            EsxCli: self
        """
        option = ""
        if value:
            option = f"{key}={value}"
        else:
            option = key

        self._command_options.append(str(option))
        return self

    def command(self, command):
        """Sets the command (in the namespace) to be invoked

        Args:
            command (str): command in the namespace

        Returns:
            EsxCli: self
        """
        self._command = str(command)
        return self

    def host(self, host):
        """Sets the host to be used as target if connected to vCenter

        Args:
            host (_type_): target host's name in the inventory

        Returns:
            EsxCli: self
        """
        self._host = str(host)
        return self

    def path(self, path):
        """Sets path of the esxcli

        Args:
            path (_type_): esxcli path. if not set, PATH will be looked at

        Returns:
            EsxCli: self
        """
        self._path = str(path)
        return self

    def execute(self):
        """_summary_

        Raises:
            subprocess.CalledProcessError: if process invocation failed
            Exception: Any exception which is not process related

        Returns:
            dict: Output of the esxcli command execution in dict
        """
        if self._path is None:
            self._path = shutil.which('esxcli')
            if self._path is None:
                raise Exception(
                    "ESXCLI path is not set. Please set with wrapper.path('/esxcli')")

        logger.info("Using %s", self._path)

        # ESXCLI Usage: esxcli [options] {namespace}+ {cmd} [cmd options]
        args = [
            self._path
        ]
        if self._credential:
            args.append("-s")
            args.append(self._credential.hostname)
            args.append("-u")
            args.append(self._credential.username)
            args.append("-p")
            args.append(self._credential.password)
            args.append("-d")
            args.append(self._credential.ssl_thumbprint)
        if self._host:
            args.append("-h")
            args.append(self._host)
        # Append cli options
        args.extend(self._esxcli_options)

        # Append namespaces
        args.extend(self._namespaces)

        # Append cmd
        args.append(self._command)

        # Append cmd options
        args.extend(self._command_options)
        try:
            logger.info(" ".join(args))
            process = subprocess.run(args, check=True,
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout = str(process.stdout).strip()
            if process.returncode == 0:
                f = io.StringIO(stdout)
                reader = csv.DictReader(f, delimiter=',')
                result = []
                for row in reader:
                    result.append(row)
                return result
            else:
                raise Exception(
                    f"Unexpected returncode {process.returncode}, Stdout: {process.stdout}, Stderr: {process.stderr}")
        except subprocess.CalledProcessError as ex:
            logger.exception(str(ex))
            raise ex
        except Exception as ex:
            logger.exception(str(ex))
            raise ex
