# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
import json

logger = logging.getLogger(__name__)


def get_template_json(filepath):
    """Read json file, convert it to object before returning to caller"""
    logger.info(f"Read the {filepath} in memory.")
    with open(filepath) as json_file:
        data = json.load(json_file)
    return data
