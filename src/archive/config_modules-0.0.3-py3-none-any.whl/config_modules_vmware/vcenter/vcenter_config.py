# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging

from config_modules_vmware.base_config import BaseConfig
from config_modules_vmware.esxi.esx_context import EsxContext

logger = logging.getLogger(__name__)

# Desired Spec related keys
CONFIG = "config"
PROFILE = "profile"
HOST_SPECIFIC = "host-specific"
HOST_OVERRIDE = "host-override"
METADATA = "metadata"
REFERENCE_HOST = "reference_host"
ESX = "esx"


class VcenterConfig(BaseConfig):
    """
    Class to implement config management functionalities for ESXi module
    """

    def __init__(self, context: EsxContext):
        super().__init__(context)
        self._esx_config_module_objs = None
        self.esx_config_modules = None
        self.include_defaults = False

    def get_advanced_settings_virtual_center(self):
        return {"advanced_settings_virtual_center": self._query_settings_by_prefix("VirtualCenter.")}

    def get_advanced_settings_log_config(self):
        return {"advanced_settings_log_config": self._query_settings_by_prefix("config.log.")}

    def get_advanced_settings_vpxd_events(self):
        return {"advanced_settings_vpxd_events": self._query_settings_by_prefix("vpxd.event.")}

    def _query_settings_by_prefix(self, prefix):
        vc_vmomi_client = self._context.vc_vmomi_client()
        option_values = vc_vmomi_client.content.setting.QueryOptions(prefix)
        settings = []
        for option_value in option_values:
            settings.append({option_value.key: option_value.value})
        return settings
