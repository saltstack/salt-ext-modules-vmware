# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from typing import List

from config_modules_vmware.esxi.config_model.base_model import BaseModel


class AdvancedOptionsUserVars(BaseModel):
    """Class to set Advanced options user vars config for ESXi host."""
    def __init__(self, option_name=None, integer_value=None, string_value=None):
        self._option_name = option_name
        self._integer_value = integer_value
        self._string_value = string_value

    @property
    def option_name(self):
        """Get option name"""
        return self._option_name

    @option_name.setter
    def option_name(self, option_name: str):
        """Set option name"""
        self._option_name = option_name

    @property
    def integer_value(self):
        """Get integer value"""
        return self._integer_value

    @integer_value.setter
    def integer_value(self, integer_value: int):
        """Set integer value"""
        self._integer_value = integer_value

    @property
    def string_value(self):
        """Get string value"""
        return self._string_value

    @string_value.setter
    def string_value(self, string_value: str):
        """Get string value"""
        self._string_value = string_value


class AdvancedOptionsConfigModel(BaseModel):
    """Class to set Advanced options config for ESXi host."""

    # Array key map define the key(id) or list of keys for the item of an array object. This could be used in comparing
    # two array objects that do not have the items in the same order.
    ARRAY_KEY_MAP = {
        "static_key_map": {"user_vars": ["option_name"]},
        "regex_key_map": {}
    }

    def __init__(self, user_vars=None, net=None):
        self._CBRC = None
        self._COW = None
        self._FDS = None
        self._FSS = None
        self._FT = None
        self._HBR = None
        self._ISCSI = None
        self._LVM = None
        self._NFSv3 = None
        self._NFSv41 = None
        self._RCU = None
        self._SE = None
        self._USB = None
        self._VFLASH = None
        self._VMFS3 = None
        self._VMKTRACING = None
        self._VSCSI_stats = None
        self._VVOL = None
        self._buffer_cache2 = None
        self._cpu = None
        self._data_mover = None
        self._digest = None
        self._direntry_cache = None
        self._disk = None
        self._file_system = None
        self._hpp = None
        self._irq = None
        self._loadESX = None
        self._lpage = None
        self._mem = None
        self._migrate = None
        self._misc = None
        self._net = None
        self._nmp = None
        self._numa = None
        self._page_retire = None
        self._pmem = None
        self._power = None
        self._scsi = None
        self._sunRPC = None
        self._svmotion = None
        self._user = None
        self._user_vars = None
        self._userMem = None
        self._userObj = None
        self._visorFS = None
        self._vmkAccess = None
        self._vprobes = None
        self._world = None
        self._xvmotion = None

    @classmethod
    def array_key_map(cls):
        return cls.ARRAY_KEY_MAP

    @property
    def CBRC(self):
        """Get CBRC"""
        return self._CBRC

    @CBRC.setter
    def CBRC(self, crbc: dict):
        """Set CBRC"""
        self._CBRC = crbc

    @property
    def COW(self):
        """Get COW config"""
        return self._COW

    @COW.setter
    def COW(self, cow: dict):
        """Set COW config"""
        self._COW = cow

    @property
    def FDS(self):
        """Get FDS config"""
        return self._FDS

    @FDS.setter
    def FDS(self, fds: dict):
        """Set COW config"""
        self._FDS = fds

    @property
    def FSS(self):
        """Get FDS config"""
        return self._FSS

    @FSS.setter
    def FSS(self, fss: dict):
        """Set COW config"""
        self._FSS = fss

    @property
    def FT(self):
        """Get FT config"""
        return self._FT

    @FT.setter
    def FT(self, ft: dict):
        """Set COW config"""
        self._FT = ft

    @property
    def HBR(self):
        """Get HBR config"""
        return self._HBR

    @HBR.setter
    def HBR(self, hbr: dict):
        """Set COW config"""
        self._HBR = hbr

    @property
    def ISCSI(self):
        """Get ISCSI config"""
        return self._ISCSI

    @ISCSI.setter
    def ISCSI(self, iscsi: dict):
        """Set ISCSI config"""
        self._ISCSI = iscsi

    @property
    def LVM(self):
        """Get LVM config"""
        return self._LVM

    @LVM.setter
    def LVM(self, lvm: dict):
        """Set LVM config"""
        self._LVM = lvm

    @property
    def NFSv3(self):
        """Get NFSv3 config"""
        return self._NFSv3

    @NFSv3.setter
    def NFSv3(self, nfsv3: dict):
        """Set NFSv3 config"""
        self._NFSv3 = nfsv3

    @property
    def NFSv41(self):
        """Get NFSv41 config"""
        return self._NFSv41

    @NFSv41.setter
    def NFSv41(self, nfsv41: dict):
        """Set NFSv41 config"""
        self._NFSv41 = nfsv41

    @property
    def RCU(self):
        """Get RCU config"""
        return self._RCU

    @RCU.setter
    def RCU(self, rcu: dict):
        """Set RCU config"""
        self._RCU = rcu

    @property
    def SE(self):
        """Get SE config"""
        return self._SE

    @SE.setter
    def SE(self, se: dict):
        """Set SE config"""
        self._SE = se

    @property
    def USB(self):
        """Get USB config"""
        return self._USB

    @USB.setter
    def USB(self, usb: dict):
        """Set USB config"""
        self._USB = usb

    @property
    def VFLASH(self):
        """Get VFLASH config"""
        return self._VFLASH

    @VFLASH.setter
    def VFLASH(self, vflash: dict):
        """Set VFLASH config"""
        self._VFLASH = vflash

    @property
    def VMFS3(self):
        """Get VMFS3 config"""
        return self._VMFS3

    @VMFS3.setter
    def VMFS3(self, vmfs3: dict):
        """Set VMFS3 config"""
        self._VMFS3 = vmfs3

    @property
    def VMKTRACING(self):
        """Get VMKTRACING config"""
        return self._VMKTRACING

    @VMKTRACING.setter
    def VMKTRACING(self, vmtracking: dict):
        """Set VMKTRACING config"""
        self._VMKTRACING = vmtracking

    @property
    def VSCSI_stats(self):
        """Get VSCSI_stats config"""
        return self._VMFS3

    @VSCSI_stats.setter
    def VSCSI_stats(self, vscsi_stats: dict):
        """Set VSCSI_stats config"""
        self._VSCSI_stats = vscsi_stats

    @property
    def VVOL(self):
        """Get VVOL config"""
        return self._VVOL

    @VVOL.setter
    def VVOL(self, vvol: dict):
        """Set VVOL config"""
        self._VVOL = vvol

    @property
    def buffer_cache2(self):
        """Get buffer_cache2 config"""
        return self._buffer_cache2

    @buffer_cache2.setter
    def buffer_cache2(self, buffer_cache2: dict):
        """Set buffer_cache2 config"""
        self._buffer_cache2 = buffer_cache2

    @property
    def cpu(self):
        """Get cpu config"""
        return self._cpu

    @cpu.setter
    def cpu(self, cpu: dict):
        """Set cpu config"""
        self._cpu = cpu

    @property
    def data_mover(self):
        """Get data_mover config"""
        return self._data_mover

    @data_mover.setter
    def data_mover(self, data_mover: dict):
        """Set data_mover config"""
        self._data_mover = data_mover

    @property
    def digest(self):
        """Get digest config"""
        return self._digest

    @digest.setter
    def digest(self, digest: dict):
        """Set digest config"""
        self._digest = digest

    @property
    def direntry_cache(self):
        """Get direntry_cache config"""
        return self._direntry_cache

    @direntry_cache.setter
    def direntry_cache(self, direntry_cache: dict):
        """Set direntry_cache config"""
        self._direntry_cache = direntry_cache

    @property
    def disk(self):
        """Get disk config"""
        return self._disk

    @disk.setter
    def disk(self, disk: dict):
        """Set disk config"""
        self._disk = disk

    @property
    def file_system(self):
        """Get file_system config"""
        return self._file_system

    @file_system.setter
    def file_system(self, file_system: dict):
        """Set file_system config"""
        self._file_system = file_system

    @property
    def hpp(self):
        """Get hpp config"""
        return self._hpp

    @hpp.setter
    def hpp(self, hpp: dict):
        """Set hpp config"""
        self._hpp = hpp

    @property
    def irq(self):
        """Get irq config"""
        return self._irq

    @irq.setter
    def irq(self, irq: dict):
        """Set irq config"""
        self._irq = irq

    @property
    def loadESX(self):
        """Get loadESX config"""
        return self._loadESX

    @loadESX.setter
    def loadESX(self, loadESX: dict):
        """Set loadESX config"""
        self._loadESX = loadESX

    @property
    def lpage(self):
        """Get lpage config"""
        return self._lpage

    @lpage.setter
    def lpage(self, lpage: dict):
        """Set lpage config"""
        self._lpage = lpage

    @property
    def mem(self):
        """Get mem config"""
        return self._mem

    @mem.setter
    def mem(self, mem: dict):
        """Set mem config"""
        self._mem = mem

    @property
    def migrate(self):
        """Get migrate config"""
        return self._migrate

    @migrate.setter
    def migrate(self, migrate: dict):
        """Set migrate config"""
        self._migrate = migrate

    @property
    def misc(self):
        """Get misc config"""
        return self._misc

    @misc.setter
    def misc(self, misc: dict):
        """Set misc config"""
        self._misc = misc

    @property
    def net(self):
        """Get net config"""
        return self._net

    @net.setter
    def net(self, net: dict):
        """Set net config"""
        self._net = net

    @property
    def nmp(self):
        """Get nmp config"""
        return self._nmp

    @nmp.setter
    def nmp(self, nmp: dict):
        """Set nmp config"""
        self._nmp = nmp

    @property
    def numa(self):
        """Get numa config"""
        return self._numa

    @numa.setter
    def numa(self, numa: dict):
        """Set numa config"""
        self._numa = numa

    @property
    def page_retire(self):
        """Get page_retire config"""
        return self._page_retire

    @page_retire.setter
    def page_retire(self, page_retire: dict):
        """Set page_retire config"""
        self._page_retire = page_retire

    @property
    def pmem(self):
        """Get pmem config"""
        return self._pmem

    @pmem.setter
    def pmem(self, pmem: dict):
        """Set pmem config"""
        self._pmem = pmem

    @property
    def power(self):
        """Get power config"""
        return self._power

    @power.setter
    def power(self, power: dict):
        """Set power config"""
        self._power = power

    @property
    def scsi(self):
        """Get scsi config"""
        return self._scsi

    @scsi.setter
    def scsi(self, scsi: dict):
        """Set scsi config"""
        self._scsi = scsi

    @property
    def sunRPC(self):
        """Get sunRPC config"""
        return self._sunRPC

    @VVOL.setter
    def sunRPC(self, sunRPC: dict):
        """Set sunRPC config"""
        self._sunRPC = sunRPC

    @property
    def svmotion(self):
        """Get svmotion config"""
        return self._svmotion

    @svmotion.setter
    def svmotion(self, svmotion: dict):
        """Set svmotion config"""
        self._svmotion = svmotion

    @property
    def user(self):
        """Get user config"""
        return self._user

    @user.setter
    def user(self, user: dict):
        """Set user config"""
        self._user = user

    @property
    def userMem(self):
        """Get userMem config"""
        return self._userMem

    @userMem.setter
    def userMem(self, userMem: dict):
        """Set userMem config"""
        self._userMem = userMem

    @property
    def userObj(self):
        """Get userObj config"""
        return self._userObj

    @userObj.setter
    def userObj(self, userObj: dict):
        """Set userObj config"""
        self._userObj = userObj

    @property
    def user_vars(self):
        """Get user vars"""
        return self._user_vars

    @user_vars.setter
    def user_vars(self, user_vars: AdvancedOptionsUserVars):
        """Set user vars"""
        self._user_vars = user_vars

    @property
    def visorFS(self):
        """Get visorFS config"""
        return self._visorFS

    @visorFS.setter
    def visorFS(self, visorFS: dict):
        """Set visorFS config"""
        self._visorFS = visorFS

    @property
    def vmkAccess(self):
        """Get vmkAccess config"""
        return self._vmkAccess

    @vmkAccess.setter
    def vmkAccess(self, vmkAccess: dict):
        """Set vmkAccess config"""
        self._vmkAccess = vmkAccess

    @property
    def vprobes(self):
        """Get vprobes config"""
        return self._vprobes

    @vprobes.setter
    def vprobes(self, vprobes: dict):
        """Set vprobes config"""
        self._vprobes = vprobes

    @property
    def world(self):
        """Get world config"""
        return self._world

    @world.setter
    def world(self, world: dict):
        """Set world config"""
        self._world = world

    @property
    def xvmotion(self):
        """Get xvmotion config"""
        return self._xvmotion

    @xvmotion.setter
    def xvmotion(self, xvmotion: dict):
        """Set xvmotion config"""
        self._xvmotion = xvmotion
