# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum

from config_modules_vmware.esxi.config_submodules.network_config import NetworkConfig
from config_modules_vmware.esxi.config_submodules.network_vss_config import NetworkVssConfig
from config_modules_vmware.esxi.config_submodules.storage_config import StorageConfig
from config_modules_vmware.esxi.config_submodules.advanced_options_config import AdvancedOptionsConfig
from config_modules_vmware.esxi.config_submodules.storage_iscsi_config import StorageIscsiConfig
from config_modules_vmware.esxi.config_submodules.authorization_config import AuthorizationConfig
from config_modules_vmware.esxi.config_submodules.hardware_config import HardwareConfig


class EsxConfigModulesEnum(Enum):
    """
    Enum Class to define Esx config modules and values hold corresponding module class name.
    """
    NETWORK = NetworkConfig
    STORAGE = StorageConfig
    NETWORK_VSS = NetworkVssConfig
    STORAGE_ISCSI = StorageIscsiConfig
    ADVANCED_OPTIONS = AdvancedOptionsConfig
    AUTHORIZATION = AuthorizationConfig
    HARDWARE = HardwareConfig

    @staticmethod
    def choice_list():
        """
        Returns a list of names for this enum.
        """
        return [i.name for i in EsxConfigModulesEnum]
