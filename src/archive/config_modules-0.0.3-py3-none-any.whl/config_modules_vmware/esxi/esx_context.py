# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from config_modules_vmware.context import Context
from config_modules_vmware.lib.common.credentials import SddcCredentials
from config_modules_vmware.lib.esxcli.esxcli import EsxCli
from config_modules_vmware.lib.vcenter.vc_vmomi_client import VcVmomiClient
from config_modules_vmware.lib.vcenter.vc_vlcm_client import VcVlcmClient



class EsxContext(Context):
    """
    Class to be shared among ESX config modules, i.e it is placeholder for connection related objects
    which ESX config modules would need to talk to. It supports context manager to trigger
    cleanup of any active connections during the exit of this object.
    """

    def __init__(self, sddc_credentials: SddcCredentials):
        """
        Initialize context for Esx config functionalities to work on.
        :param sddc_credentials: The Sddc credentials.
        :type sddc_credentials: SddcCredentials
        """
        super(EsxContext, self).__init__(sddc_credentials)
        self._vc_vmomi_client = None
        self._vc_vlcm_client = None

    @classmethod
    def from_kwargs(cls, sddc_credentials: SddcCredentials, **kwargs):
        return cls(sddc_credentials)

    def __enter__(self):
        """
        Called when the consumer starts the 'with context:' block
        """
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Called when the consumer's 'with context:' block ends.
        Disconnects from any instantiated clients.
        """
        if self._vc_vmomi_client:
            self._vc_vmomi_client.disconnect()
        if self._vc_vlcm_client:
            del self._vc_vlcm_client
            self._vc_vlcm_client = None

    def vc_vmomi_client(self):
        """
        Returns the instance of a VcVmomiClient
        Initializes if one does not exist.
        """
        if not self._vc_vmomi_client:
            vc_creds = self._sddc_credentials.vc_creds
            self._vc_vmomi_client = VcVmomiClient(
                hostname=vc_creds.hostname,
                user=vc_creds.username,
                pwd=vc_creds.password,
                ssl_thumbprint=vc_creds.ssl_thumbprint,
                saml_token=vc_creds.saml_token)
        return self._vc_vmomi_client

    def vc_vlcm_client(self):
        """
        Returns the  instance of a VcVlcmClient
        Initializes if one does not exist.
        """
        if not self._vc_vlcm_client:
            self._vc_vlcm_client = VcVlcmClient(vc_access=self._sddc_credentials.vc_creds)
        return self._vc_vlcm_client

    def esxcli_client(self):
        """
        Returns the instance of a EsxCli Wrapper
        """
        return EsxCli().credential(self._sddc_credentials.vc_creds)
