# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import logging

from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl
from config_modules_vmware.esxi.config_model.network_vss_config_model import NetworkVss
from config_modules_vmware.esxi.config_model.network_vss_config_model import Switches
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchesBridge
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchesBridgeLinkDiscoveryProtocol
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchPolicy
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchPolicySecurity
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchPolicyNicTeaming
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchPolicyTrafficShaping
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchesPortGroups
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchPolicyNicTeamingPolicyEnum
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchPolicyNicTeamingLinkCriteriaBeaconEnum
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchesBridgeLinkDiscoveryProtocolProtocolEnum
from config_modules_vmware.esxi.config_model.network_vss_config_model import SwitchesBridgeLinkDiscoveryProtocolOperationEnum


logger = logging.getLogger(__name__)


class NetworkVssConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the network vss configs of ESXi host.
    """

    MODULE_NAME = 'network_vss'

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def __init__(self, context):
        pass

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns network_vss configuration for the ESXi host.
        """
        logger.info(F"Populating the Network_VSS config for host: {host_ref.name}")
        network_vss_config = NetworkVss()
        vswitches = list()
        if host_ref.configManager.networkSystem.networkInfo:
            vswitches_ref = host_ref.configManager.networkSystem.networkInfo.vswitch
            if vswitches_ref:
                for vswitch_ref in vswitches_ref:
                    vswitch = Switches()
                    vswitch.mtu = vswitch_ref.mtu if vswitch_ref.mtu else None
                    vswitch.name = vswitch_ref.name
                    vswitch.num_ports = vswitch_ref.numPorts
                    vswitch.bridge = self._get_vswitch_bridge_config(vswitch_ref.spec.bridge)
                    vswitch.policy = self._get_vswitch_policy_config(vswitch_ref.spec.policy)
                    vswitch.port_groups = self._get_vswitch_port_group_config(host_ref, vswitch_ref.portgroup)
                    vswitches.append(vswitch)
        logger.info(F"Finished populating the Network_VSS config for "
                    F"vswitches:{[x.name for x in vswitches]} for host: {host_ref.name}")
        network_vss_config.switches = vswitches
        return network_vss_config

    def _get_vswitch_bridge_config(self, vswitch_bridge_ref):
        if vswitch_bridge_ref:
            bridge = SwitchesBridge()
            if hasattr(vswitch_bridge_ref, "nicDevice") and isinstance(vswitch_bridge_ref.nicDevice, list):
                bridge.nics = [nic for nic in vswitch_bridge_ref.nicDevice]
            if hasattr(vswitch_bridge_ref, 'linkDiscoveryProtocolConfig'):
                bridge.link_discovery_protocol = SwitchesBridgeLinkDiscoveryProtocol()
                bridge.link_discovery_protocol.protocol = SwitchesBridgeLinkDiscoveryProtocolProtocolEnum(
                    vswitch_bridge_ref.linkDiscoveryProtocolConfig.protocol) if \
                    vswitch_bridge_ref.linkDiscoveryProtocolConfig.protocol else None
                bridge.link_discovery_protocol.operation = SwitchesBridgeLinkDiscoveryProtocolOperationEnum(
                    vswitch_bridge_ref.linkDiscoveryProtocolConfig.operation) if \
                    vswitch_bridge_ref.linkDiscoveryProtocolConfig.operation else None
            if hasattr(vswitch_bridge_ref, 'beacon'):
                bridge.beacon_interval = vswitch_bridge_ref.beacon.interval
            return bridge

    def _get_vswitch_policy_config(self, vswitch_policy_ref):
        if vswitch_policy_ref:
            policy = SwitchPolicy()

            if vswitch_policy_ref.security:
                security = SwitchPolicySecurity()
                security_ref = vswitch_policy_ref.security
                security.mac_changes = security_ref.macChanges
                security.forged_transmits = security_ref.forgedTransmits
                security.allow_promiscuous = security_ref.allowPromiscuous
                policy.security = security

            if vswitch_policy_ref.nicTeaming:
                nic_teaming = SwitchPolicyNicTeaming()
                nic_teaming_ref = vswitch_policy_ref.nicTeaming
                nic_teaming.policy = SwitchPolicyNicTeamingPolicyEnum(nic_teaming_ref.policy) if\
                    nic_teaming_ref.policy else None
                nic_teaming.rolling_order = nic_teaming_ref.rollingOrder
                nic_teaming.notify_switches = nic_teaming_ref.notifySwitches
                nic_teaming.link_criteria_beacon = SwitchPolicyNicTeamingLinkCriteriaBeaconEnum.TRUE if\
                    nic_teaming_ref.failureCriteria.checkBeacon else SwitchPolicyNicTeamingLinkCriteriaBeaconEnum.IGNORE
                if nic_teaming_ref.nicOrder and nic_teaming_ref.nicOrder.activeNic:
                    nic_teaming.active_nics = [nic for nic in nic_teaming_ref.nicOrder.activeNic]
                if nic_teaming_ref.nicOrder and nic_teaming_ref.nicOrder.standbyNic:
                    nic_teaming.standby_nics = [nic for nic in nic_teaming_ref.nicOrder.standbyNic]
                policy.nic_teaming = nic_teaming

            if vswitch_policy_ref.shapingPolicy:
                traffic_shaping = SwitchPolicyTrafficShaping()
                traffic_shaping_ref = vswitch_policy_ref.shapingPolicy
                traffic_shaping.enabled = traffic_shaping_ref.enabled
                traffic_shaping.burst_size = traffic_shaping_ref.burstSize
                traffic_shaping.average_bandwidth = traffic_shaping_ref.averageBandwidth
                traffic_shaping.peak_bandwidth = traffic_shaping_ref.peakBandwidth
                policy.traffic_shaping = traffic_shaping

            return policy

    def _get_vswitch_port_group_config(self, host_ref, vswitch_portgroups_name):
        if vswitch_portgroups_name is not None:
            logger.info(F"Populate vswitch port group config for port groups: {vswitch_portgroups_name} "
                        F"for host: {host_ref.name}")
            port_groups_ref = host_ref.configManager.networkSystem.networkInfo.portgroup
            vswitch_portgroups = list()
            if port_groups_ref:
                for port_group_ref in port_groups_ref:
                    if port_group_ref.key in vswitch_portgroups_name:
                        vswitch_portgroup = SwitchesPortGroups()
                        vswitch_portgroup.name = port_group_ref.spec.name
                        vswitch_portgroup.vlan_id = port_group_ref.spec.vlanId
                        vswitch_portgroup.policy = self._get_vswitch_policy_config(port_group_ref.spec.policy)
                        vswitch_portgroups.append(vswitch_portgroup)
            logger.info(F"Finished populating vswitch port group config for port groups: "
                        F"{[x.name for x in vswitch_portgroups]} for host: {host_ref.name}")
            return vswitch_portgroups
