# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from __future__ import absolute_import
from enum import Enum
from typing import List

from config_modules_vmware.esxi.config_model.base_model import BaseModel


class SwitchPolicyNicTeamingPolicyEnum(BaseModel, Enum):
    """
    Enum Class to define values for policy property in nic_teaming section
    """
    LOADBALANCE_IP = "loadbalance_ip"
    LOADBALANCE_SRCMAC = "loadbalance_srcmac"
    LOADBALANCE_SRCID = "loadbalance_srcid"
    FAILOVER_EXPLICIT = "failover_explicit"
    NONE = None


class SwitchPolicyNicTeamingLinkCriteriaBeaconEnum(BaseModel, Enum):
    """
    Enum Class to define values for link_criteria_beacon property in nic_teaming section
    """
    TRUE = "TRUE"
    IGNORE = "IGNORE"


class SwitchesBridgeLinkDiscoveryProtocolProtocolEnum(BaseModel, Enum):
    """
    Enum Class to define values for protocol property in link_discovery_protocol section
    """
    CDP = "cdp"
    LLDP = "lldp"


class SwitchesBridgeLinkDiscoveryProtocolOperationEnum(BaseModel, Enum):
    """
    Enum Class to define values for operation property in link_discovery_protocol section
    """
    NONE = "none"
    LISTEN = "listen"
    ADVERTISE = "advertise"
    BOTH = "both"


class SwitchPolicySecurity(BaseModel):

    def __init__(self, mac_changes=None, forged_transmits=None, allow_promiscuous=None):
        """SwitchPolicySecurity
        :param mac_changes: The mac_changes of this SwitchPolicySecurity.
        :type mac_changes: bool
        :param forged_transmits: The forged_transmits of this SwitchPolicySecurity.
        :type forged_transmits: bool
        :param allow_promiscuous: The allow_promiscuous of this SwitchPolicySecurity.
        :type allow_promiscuous: bool
        """
        self._mac_changes = mac_changes
        self._forged_transmits = forged_transmits
        self._allow_promiscuous = allow_promiscuous

    @property
    def mac_changes(self):
        """Gets the mac_changes of this SwitchPolicySecurity.
        :return: The mac_changes of this SwitchPolicySecurity.
        :rtype: bool
        """
        return self._mac_changes

    @mac_changes.setter
    def mac_changes(self, mac_changes):
        """Sets the mac_changes of this SwitchPolicySecurity.
        :param mac_changes: The mac_changes of this SwitchPolicySecurity.
        :type mac_changes: bool
        """

        self._mac_changes = mac_changes

    @property
    def forged_transmits(self):
        """Gets the forged_transmits of this SwitchPolicySecurity.
        :return: The forged_transmits of this SwitchPolicySecurity.
        :rtype: bool
        """
        return self._forged_transmits

    @forged_transmits.setter
    def forged_transmits(self, forged_transmits):
        """Sets the forged_transmits of this SwitchPolicySecurity.
        :param forged_transmits: The forged_transmits of this SwitchPolicySecurity.
        :type forged_transmits: bool
        """

        self._forged_transmits = forged_transmits

    @property
    def allow_promiscuous(self):
        """Gets the allow_promiscuous of this SwitchPolicySecurity.
        :return: The allow_promiscuous of this SwitchPolicySecurity.
        :rtype: bool
        """
        return self._allow_promiscuous

    @allow_promiscuous.setter
    def allow_promiscuous(self, allow_promiscuous):
        """Sets the allow_promiscuous of this SwitchPolicySecurity.
        :param allow_promiscuous: The allow_promiscuous of this SwitchPolicySecurity.
        :type allow_promiscuous: bool
        """

        self._allow_promiscuous = allow_promiscuous


class SwitchPolicyNicTeaming(BaseModel):

    def __init__(self, policy: SwitchPolicyNicTeamingPolicyEnum = None, active_nics=None, standby_nics=None,
                 rolling_order=None, notify_switches=None,
                 link_criteria_beacon: SwitchPolicyNicTeamingLinkCriteriaBeaconEnum = None):
        """SwitchPolicyNicTeaming
        :param policy: The policy of this SwitchPolicyNicTeaming.
        :type policy: SwitchPolicyNicTeamingPolicyEnum
        :param active_nics: The active_nics of this SwitchPolicyNicTeaming.
        :type active_nics: List[str]
        :param standby_nics: The standby_nics of this SwitchPolicyNicTeaming.
        :type standby_nics: List[str]
        :param rolling_order: The rolling_order of this SwitchPolicyNicTeaming.
        :type rolling_order: bool
        :param notify_switches: The notify_switches of this SwitchPolicyNicTeaming.
        :type notify_switches: bool
        :param link_criteria_beacon: The link_criteria_beacon of this SwitchPolicyNicTeaming.
        :type link_criteria_beacon: SwitchPolicyNicTeamingLinkCriteriaBeaconEnum
        """
        self._policy = policy
        self._active_nics = active_nics
        self._standby_nics = standby_nics
        self._rolling_order = rolling_order
        self._notify_switches = notify_switches
        self._link_criteria_beacon = link_criteria_beacon

    @property
    def policy(self):
        """Gets the policy of this SwitchPolicyNicTeaming.
        :return: The policy of this SwitchPolicyNicTeaming.
        :rtype: SwitchPolicyNicTeamingPolicyEnum
        """
        return self._policy

    @policy.setter
    def policy(self, policy: SwitchPolicyNicTeamingPolicyEnum):
        """Sets the policy of this SwitchPolicyNicTeaming.
        :param policy: The policy of this SwitchPolicyNicTeaming.
        :type policy: SwitchPolicyNicTeamingPolicyEnum
        """

        self._policy = policy

    @property
    def active_nics(self):
        """Gets the active_nics of this SwitchPolicyNicTeaming.
        :return: The active_nics of this SwitchPolicyNicTeaming.
        :rtype: List[str]
        """
        return self._active_nics

    @active_nics.setter
    def active_nics(self, active_nics: List[str]):
        """Sets the active_nics of this SwitchPolicyNicTeaming.
        :param active_nics: The active_nics of this SwitchPolicyNicTeaming.
        :type active_nics: List[str]
        """

        self._active_nics = active_nics

    @property
    def standby_nics(self):
        """Gets the standby_nics of this SwitchPolicyNicTeaming.
        :return: The standby_nics of this SwitchPolicyNicTeaming.
        :rtype: List[str]
        """
        return self._standby_nics

    @standby_nics.setter
    def standby_nics(self, standby_nics: List[str]):
        """Sets the standby_nics of this SwitchPolicyNicTeaming.
        :param standby_nics: The standby_nics of this SwitchPolicyNicTeaming.
        :type standby_nics: List[str]
        """

        self._standby_nics = standby_nics

    @property
    def rolling_order(self):
        """Gets the rolling_order of this SwitchPolicyNicTeaming.
        :return: The rolling_order of this SwitchPolicyNicTeaming.
        :rtype: bool
        """
        return self._rolling_order

    @rolling_order.setter
    def rolling_order(self, rolling_order):
        """Sets the rolling_order of this SwitchPolicyNicTeaming.
        :param rolling_order: The rolling_order of this SwitchPolicyNicTeaming.
        :type rolling_order: bool
        """

        self._rolling_order = rolling_order

    @property
    def notify_switches(self):
        """Gets the notify_switches of this SwitchPolicyNicTeaming.
        :return: The notify_switches of this SwitchPolicyNicTeaming.
        :rtype: bool
        """
        return self._notify_switches

    @notify_switches.setter
    def notify_switches(self, notify_switches):
        """Sets the notify_switches of this SwitchPolicyNicTeaming.
        :param notify_switches: The notify_switches of this SwitchPolicyNicTeaming.
        :type notify_switches: bool
        """

        self._notify_switches = notify_switches

    @property
    def link_criteria_beacon(self):
        """Gets the link_criteria_beacon of this SwitchPolicyNicTeaming.
        :return: The link_criteria_beacon of this SwitchPolicyNicTeaming.
        :rtype: SwitchPolicyNicTeamingLinkCriteriaBeaconEnum
        """
        return self._link_criteria_beacon

    @link_criteria_beacon.setter
    def link_criteria_beacon(self, link_criteria_beacon: SwitchPolicyNicTeamingLinkCriteriaBeaconEnum):
        """Sets the link_criteria_beacon of this SwitchPolicyNicTeaming.
        :param link_criteria_beacon: The link_criteria_beacon of this SwitchPolicyNicTeaming.
        :type link_criteria_beacon: str
        """

        self._link_criteria_beacon = link_criteria_beacon


class SwitchPolicyTrafficShaping(BaseModel):

    def __init__(self, enabled=None, burst_size=None, peak_bandwidth=None, average_bandwidth=None):
        """SwitchPolicyTrafficShaping
        :param enabled: The enabled of this SwitchPolicyTrafficShaping.
        :type enabled: bool
        :param burst_size: The burst_size of this SwitchPolicyTrafficShaping.
        :type burst_size: int
        :param peak_bandwidth: The peak_bandwidth of this SwitchPolicyTrafficShaping.
        :type peak_bandwidth: int
        :param average_bandwidth: The average_bandwidth of this SwitchPolicyTrafficShaping.
        :type average_bandwidth: int
        """
        self._enabled = enabled
        self._burst_size = burst_size
        self._peak_bandwidth = peak_bandwidth
        self._average_bandwidth = average_bandwidth

    @property
    def enabled(self):
        """Gets the enabled of this SwitchPolicyTrafficShaping.
        :return: The enabled of this SwitchPolicyTrafficShaping.
        :rtype: bool
        """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled):
        """Sets the enabled of this SwitchPolicyTrafficShaping.
        :param enabled: The enabled of this SwitchPolicyTrafficShaping.
        :type enabled: bool
        """

        self._enabled = enabled

    @property
    def burst_size(self):
        """Gets the burst_size of this SwitchPolicyTrafficShaping.
        :return: The burst_size of this SwitchPolicyTrafficShaping.
        :rtype: int
        """
        return self._burst_size

    @burst_size.setter
    def burst_size(self, burst_size):
        """Sets the burst_size of this SwitchPolicyTrafficShaping.
        :param burst_size: The burst_size of this SwitchPolicyTrafficShaping.
        :type burst_size: int
        """

        self._burst_size = burst_size

    @property
    def peak_bandwidth(self):
        """Gets the peak_bandwidth of this SwitchPolicyTrafficShaping.
        :return: The peak_bandwidth of this SwitchPolicyTrafficShaping.
        :rtype: int
        """
        return self._peak_bandwidth

    @peak_bandwidth.setter
    def peak_bandwidth(self, peak_bandwidth):
        """Sets the peak_bandwidth of this SwitchPolicyTrafficShaping.
        :param peak_bandwidth: The peak_bandwidth of this SwitchPolicyTrafficShaping.
        :type peak_bandwidth: int
        """

        self._peak_bandwidth = peak_bandwidth

    @property
    def average_bandwidth(self):
        """Gets the average_bandwidth of this SwitchPolicyTrafficShaping.
        :return: The average_bandwidth of this SwitchPolicyTrafficShaping.
        :rtype: int
        """
        return self._average_bandwidth

    @average_bandwidth.setter
    def average_bandwidth(self, average_bandwidth):
        """Sets the average_bandwidth of this SwitchPolicyTrafficShaping.
        :param average_bandwidth: The average_bandwidth of this SwitchPolicyTrafficShaping.
        :type average_bandwidth: int
        """

        self._average_bandwidth = average_bandwidth


class SwitchPolicy(BaseModel):

    def __init__(self, security: SwitchPolicySecurity = None, nic_teaming: SwitchPolicyNicTeaming = None,
                 traffic_shaping: SwitchPolicyTrafficShaping = None):
        """SwitchPolicy
        :param security: The security of this SwitchPolicy.
        :type security: SwitchPolicySecurity
        :param nic_teaming: The nic_teaming of this SwitchPolicy.
        :type nic_teaming: SwitchPolicyNicTeaming
        :param traffic_shaping: The traffic_shaping of this SwitchPolicy.
        :type traffic_shaping: SwitchPolicyTrafficShaping
        """
        self._security = security
        self._nic_teaming = nic_teaming
        self._traffic_shaping = traffic_shaping

    @property
    def security(self):
        """Gets the security of this SwitchPolicy.
        :return: The security of this SwitchPolicy.
        :rtype: SwitchPolicySecurity
        """
        return self._security

    @security.setter
    def security(self, security: SwitchPolicySecurity):
        """Sets the security of this SwitchPolicy.
        :param security: The security of this SwitchPolicy.
        :type security: SwitchPolicySecurity
        """

        self._security = security

    @property
    def nic_teaming(self):
        """Gets the nic_teaming of this SwitchPolicy.
        :return: The nic_teaming of this SwitchPolicy.
        :rtype: SwitchPolicyNicTeaming
        """
        return self._nic_teaming

    @nic_teaming.setter
    def nic_teaming(self, nic_teaming: SwitchPolicyNicTeaming):
        """Sets the nic_teaming of this SwitchPolicy.
        :param nic_teaming: The nic_teaming of this SwitchPolicy.
        :type nic_teaming: SwitchPolicyNicTeaming
        """

        self._nic_teaming = nic_teaming

    @property
    def traffic_shaping(self):
        """Gets the traffic_shaping of this SwitchPolicy.
        :return: The traffic_shaping of this SwitchPolicy.
        :rtype: SwitchPolicyTrafficShaping
        """
        return self._traffic_shaping

    @traffic_shaping.setter
    def traffic_shaping(self, traffic_shaping: SwitchPolicyTrafficShaping):
        """Sets the traffic_shaping of this SwitchPolicy.
        :param traffic_shaping: The traffic_shaping of this SwitchPolicy.
        :type traffic_shaping: SwitchPolicyTrafficShaping
        """

        self._traffic_shaping = traffic_shaping


class SwitchesPortGroups(BaseModel):

    def __init__(self, name=None, policy: SwitchPolicy = None, vlan_id=None):
        """SwitchesPortGroups
        :param name: The name of this SwitchesPortGroups.
        :type name: str
        :param policy: The policy of this SwitchesPortGroups.
        :type policy: SwitchPolicy
        :param vlan_id: The vlan_id of this SwitchesPortGroups.
        :type vlan_id: int
        """
        self._name = name
        self._policy = policy
        self._vlan_id = vlan_id

    @property
    def name(self):
        """Gets the name of this SwitchesPortGroups.
        :return: The name of this SwitchesPortGroups.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this SwitchesPortGroups.
        :param name: The name of this SwitchesPortGroups.
        :type name: str
        """

        self._name = name

    @property
    def policy(self):
        """Gets the policy of this SwitchesPortGroups.
        :return: The policy of this SwitchesPortGroups.
        :rtype: SwitchPolicy
        """
        return self._policy

    @policy.setter
    def policy(self, policy: SwitchPolicy):
        """Sets the policy of this SwitchesPortGroups.
        :param policy: The policy of this SwitchesPortGroups.
        :type policy: SwitchPolicy
        """

        self._policy = policy

    @property
    def vlan_id(self):
        """Gets the vlan_id of this SwitchesPortGroups.
        :return: The vlan_id of this SwitchesPortGroups.
        :rtype: int
        """
        return self._vlan_id

    @vlan_id.setter
    def vlan_id(self, vlan_id):
        """Sets the vlan_id of this SwitchesPortGroups.
        :param vlan_id: The vlan_id of this SwitchesPortGroups.
        :type vlan_id: int
        """

        self._vlan_id = vlan_id


class SwitchesBridgeLinkDiscoveryProtocol(BaseModel):

    def __init__(self, protocol: SwitchesBridgeLinkDiscoveryProtocolProtocolEnum = None,
                 operation: SwitchesBridgeLinkDiscoveryProtocolOperationEnum = None):
        """SwitchesBridgeLinkDiscoveryProtocol
        :param protocol: The protocol of this SwitchesBridgeLinkDiscoveryProtocol.
        :type protocol: SwitchesBridgeLinkDiscoveryProtocolProtocolEnum
        :param operation: The operation of this SwitchesBridgeLinkDiscoveryProtocol.
        :type operation: SwitchesBridgeLinkDiscoveryProtocolOperationEnum
        """
        self._protocol = protocol
        self._operation = operation

    @property
    def protocol(self):
        """Gets the protocol of this SwitchesBridgeLinkDiscoveryProtocol.
        :return: The protocol of this SwitchesBridgeLinkDiscoveryProtocol.
        :rtype: SwitchesBridgeLinkDiscoveryProtocolProtocolEnum
        """
        return self._protocol

    @protocol.setter
    def protocol(self, protocol: SwitchesBridgeLinkDiscoveryProtocolProtocolEnum):
        """Sets the protocol of this SwitchesBridgeLinkDiscoveryProtocol.
        :param protocol: The protocol of this SwitchesBridgeLinkDiscoveryProtocol.
        :type protocol: SwitchesBridgeLinkDiscoveryProtocolProtocolEnum
        """

        self._protocol = protocol

    @property
    def operation(self):
        """Gets the operation of this SwitchesBridgeLinkDiscoveryProtocol.
        :return: The operation of this SwitchesBridgeLinkDiscoveryProtocol.
        :rtype: SwitchesBridgeLinkDiscoveryProtocolOperationEnum
        """
        return self._operation

    @operation.setter
    def operation(self, operation: SwitchesBridgeLinkDiscoveryProtocolOperationEnum):
        """Sets the operation of this SwitchesBridgeLinkDiscoveryProtocol.
        :param operation: The operation of this SwitchesBridgeLinkDiscoveryProtocol.
        :type operation: SwitchesBridgeLinkDiscoveryProtocolOperationEnum
        """

        self._operation = operation


class SwitchesBridge(BaseModel):

    def __init__(self, nics: List[str] = None, link_discovery_protocol: SwitchesBridgeLinkDiscoveryProtocol = None,
                 beacon_interval=None):
        """SwitchesBridge
        :param nics: The nics of this SwitchesBridge.
        :type nics: List[str]
        :param link_discovery_protocol: The link_discovery_protocol of this SwitchesBridge.
        :type link_discovery_protocol: SwitchesBridgeLinkDiscoveryProtocol
        :param beacon_interval:
        :type beacon_interval: int
        """
        self._nics = nics
        self._link_discovery_protocol = link_discovery_protocol
        self._beacon_interval = beacon_interval

    @property
    def nics(self):
        """Gets the nics of this SwitchesBridge.
        :return: The nics of this SwitchesBridge.
        :rtype: List[str]
        """
        return self._nics

    @nics.setter
    def nics(self, nics: List[str]):
        """Sets the nics of this SwitchesBridge.
        :param nics: The nics of this SwitchesBridge.
        :type nics: List[str]
        """

        self._nics = nics

    @property
    def beacon_interval(self):
        """Gets the beacon_interval of this SwitchesBridge.
        :return: The beacon_interval of this SwitchesBridge.
        :rtype: int
        """
        return self._beacon_interval

    @beacon_interval.setter
    def beacon_interval(self, beacon_interval):
        """Sets the beacon_interval of this SwitchesBridge.
        :param beacon_interval: The beacon_interval of this SwitchesBridge.
        :type beacon_interval: int
        """

        self._beacon_interval = beacon_interval

    @property
    def link_discovery_protocol(self):
        """Gets the link_discovery_protocol of this SwitchesBridge.
        :return: The link_discovery_protocol of this SwitchesBridge.
        :rtype: SwitchesBridgeLinkDiscoveryProtocol
        """
        return self._link_discovery_protocol

    @link_discovery_protocol.setter
    def link_discovery_protocol(self, link_discovery_protocol: SwitchesBridgeLinkDiscoveryProtocol):
        """Sets the link_discovery_protocol of this SwitchesBridge.
        :param link_discovery_protocol: The link_discovery_protocol of this SwitchesBridge.
        :type link_discovery_protocol: SwitchesBridgeLinkDiscoveryProtocol
        """

        self._link_discovery_protocol = link_discovery_protocol


class Switches(BaseModel):

    def __init__(self, mtu=None, name=None, bridge: SwitchesBridge = None, policy: SwitchPolicy = None, num_ports=None,
                 port_groups: List[SwitchesPortGroups] = None):
        """Switches
        :param mtu: The mtu of this Switches.
        :type mtu: int
        :param name: The name of this Switches.
        :type name: str
        :param bridge: The bridge of this Switches.
        :type bridge: SwitchesBridge
        :param policy: The policy of this Switches.
        :type policy: SwitchPolicy
        :param num_ports: The num_ports of this Switches.
        :type num_ports: int
        :param port_groups: The port_groups of this Switches.
        :type port_groups: List[SwitchesPortGroups]
        """
        self._mtu = mtu
        self._name = name
        self._bridge = bridge
        self._policy = policy
        self._num_ports = num_ports
        self._port_groups = port_groups

    @property
    def mtu(self):
        """Gets the mtu of this Switches.
        :return: The mtu of this Switches.
        :rtype: int
        """
        return self._mtu

    @mtu.setter
    def mtu(self, mtu):
        """Sets the mtu of this Switches.
        :param mtu: The mtu of this Switches.
        :type mtu: int
        """

        self._mtu = mtu

    @property
    def name(self):
        """Gets the name of this Switches.
        :return: The name of this Switches.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this Switches.
        :param name: The name of this Switches.
        :type name: str
        """

        self._name = name

    @property
    def bridge(self):
        """Gets the bridge of this Switches.
        :return: The bridge of this Switches.
        :rtype: SwitchesBridge
        """
        return self._bridge

    @bridge.setter
    def bridge(self, bridge: SwitchesBridge):
        """Sets the bridge of this Switches.
        :param bridge: The bridge of this Switches.
        :type bridge: SwitchesBridge
        """

        self._bridge = bridge

    @property
    def policy(self):
        """Gets the policy of this Switches.
        :return: The policy of this Switches.
        :rtype: SwitchPolicy
        """
        return self._policy

    @policy.setter
    def policy(self, policy: SwitchPolicy):
        """Sets the policy of this Switches.
        :param policy: The policy of this Switches.
        :type policy: SwitchPolicy
        """

        self._policy = policy

    @property
    def num_ports(self):
        """Gets the num_ports of this Switches.
        :return: The num_ports of this Switches.
        :rtype: int
        """
        return self._num_ports

    @num_ports.setter
    def num_ports(self, num_ports):
        """Sets the num_ports of this Switches.
        :param num_ports: The num_ports of this Switches.
        :type num_ports: int
        """

        self._num_ports = num_ports

    @property
    def port_groups(self):
        """Gets the port_groups of this Switches.
        :return: The port_groups of this Switches.
        :rtype: List[SwitchesPortGroups]
        """
        return self._port_groups

    @port_groups.setter
    def port_groups(self, port_groups: List[SwitchesPortGroups]):
        """Sets the port_groups of this Switches.
        :param port_groups: The port_groups of this Switches.
        :type port_groups: List[SwitchesPortGroups]
        """

        self._port_groups = port_groups


class NetworkVss(BaseModel):
    def __init__(self, switches: List[Switches] = None):
        """NetworkVss
        :param switches: The switches of this NetworkVss.
        :type switches: List[Switches]
        """

        self._switches = switches

    @property
    def switches(self):
        """Gets the switches of this NetworkVss.
        :return: The switches of this NetworkVss.
        :rtype: List[Switches]
        """
        return self._switches

    @switches.setter
    def switches(self, switches: List[Switches]):
        """Sets the switches of this NetworkVss.
        :param switches: The switches of this NetworkVss.
        :type switches: List[Switches]
        """

        self._switches = switches
