# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import copy
import json
import os

from config_modules_vmware.esxi.esx_config import EsxConfig
from pytest_console_scripts import ScriptRunner
from unittest import mock
from unittest.mock import patch

EXPECTED_CONFIG = \
    {
        "clusters":
            [
                {
                    "name": "Cluster-1",
                    "moid": "cluster-a",
                    "hosts":
                        [
                            {
                                "name": "1.1.1.1",
                                "moid": "host-1",
                                "config": {}
                            }
                        ]
                }
            ],
        "standalone_hosts":
            [
                {
                    "name": "2.2.2.2",
                    "moid": "host-2",
                    "config": {}
                }
            ]
    }

EXPECTED_RESPONSE = \
    {
        "status": "SUCCEEDED",
        "config": copy.deepcopy(EXPECTED_CONFIG)
    }


@patch.object(EsxConfig, 'get_configuration')
def test_retrieving_esx_configurations(mock_esx_config_get_configuration_method, script_runner: ScriptRunner) -> None:
    """
    Test to validate invoking and returning the esx module configuration from the CLI command tool.
    @param mock_esx_config_get_configuration_method: mocked get_configuration method from EsxConfig.
    @param script_runner:
    """
    mock_esx_config_get_configuration_method.return_value = EXPECTED_CONFIG
    mock_env_vars = mock.patch.dict(os.environ, {'AGENT_NAME': 'stderr'})
    mock_env_vars.start()
    ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',
                            '--vc-fqdn', 'test', '--password', 'test', '--username', 'test', '--auth-token', 'test'],
                            print_result=True, shell=True)

    returned_response = json.loads(ret.stdout)

    assert ret.success
    assert returned_response == EXPECTED_RESPONSE


