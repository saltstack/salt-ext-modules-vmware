# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json
import os

from config_modules_vmware.esxi.esx_config import EsxConfig
from pytest_console_scripts import ScriptRunner
from unittest import mock
from unittest.mock import patch


FAILED_RESPONSE = \
    {
        "status": "FAILED",
        "config": {}
    }


def test_config_module_cli(script_runner) -> None:
    """
    Test to validate that the CLI command tool works.
    @param script_runner:
    """
    ret = script_runner.run(['config-modules-cli', '--help'])
    assert ret.success
    assert ret.stderr == ''


def mock_get_configuration_exception(*args, **kwargs):
    raise Exception('mocked_exception')


@patch.object(EsxConfig, 'get_configuration')
def test_failed_get_config_workflow(mock_esx_config_get_configuration_method, script_runner: ScriptRunner) -> None:
    """
    Test to validate errors returned after the esx module fails.
    @param mock_esx_config_get_configuration_method: mocked get_configuration method from EsxConfig.
    @param script_runner:
    """
    mock_esx_config_get_configuration_method.side_effect = mock_get_configuration_exception
    mock_env_vars = mock.patch.dict(os.environ, {'AGENT_NAME': 'stderr'})
    mock_env_vars.start()
    ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',
                            '--vc-fqdn', 'test_fqdn', '--password', 'test_password', '--username', 'test_username', '--ssl-thumbprint', 'test_thumbprint'],
                            print_result=True, shell=True)
    mock_env_vars.stop()
    returned_response = json.loads(ret.stdout)
    assert returned_response == FAILED_RESPONSE
    assert "mocked_exception" in ret.stderr
    assert not ret.success


