# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import copy
import unittest
from unittest.mock import MagicMock

from pyVmomi import vim

from config_modules_vmware.esxi.config_submodules.storage_iscsi_config import StorageIscsiConfig
from config_modules_vmware.esxi.config_model.storage_iscsi_config_model import IpAddress


class TestStorageIscsiConfig(unittest.TestCase):

    def setUp(self) -> None:
        self.context = MagicMock()
        self.storage_iscsi_config = StorageIscsiConfig(self.context)
        self.host_ref = MagicMock()
        self.host_ref.config.storageDevice.softwareInternetScsiEnabled = True
        self.authentication_properties = vim.host.InternetScsiHba.AuthenticationProperties(
            chapAuthEnabled=True,
            chapName='chapName',
            chapSecret='chapSecret',
            chapAuthenticationType='chapProhibited',
            mutualChapName='mutualChapName',
            mutualChapSecret='mutualChapSecret',
            mutualChapAuthenticationType='chapProhibited'
        )
        self.digest_properties = vim.host.InternetScsiHba.DigestProperties(
            headerDigestType="digestProhibited",
            dataDigestType="digestProhibited"
        )
        self.advanced_options = [
            vim.host.InternetScsiHba.ParamValue(
                key='ErrorRecoveryLevel',
                value=0,
            ),
            vim.host.InternetScsiHba.ParamValue(
                key='MaxOutstandingR2T',
                value=1,
            ),
            vim.host.InternetScsiHba.ParamValue(
                key='DelayedAck',
                value=False,
            )
        ]
        self.ip_properties = vim.host.InternetScsiHba.IPProperties(
            ipv4Enabled=True,
            mac='00:10:9b:19:56:fb',
            address='0.0.0.0',
            dhcpConfigurationEnabled=False,
            subnetMask='0.0.0.0',
            defaultGateway='0.0.0.0',
            primaryDnsServerAddress='8.8.8.8',
            alternateDnsServerAddress='8.8.4.4',
            ipv6Enabled=True,
            ipv6Address="",
            ipv6SubnetMask="",
            ipv6DefaultGateway="",
            arpRedirectEnabled=False,
            mtu=8342,
            ipv6properties=vim.host.InternetScsiHba.IPv6Properties(
                iscsiIpv6Address=[
                    vim.host.InternetScsiHba.IscsiIpv6Address(
                        address='fe80::210:9bff:fe19:56fb',
                        prefixLength=64,
                        origin='Static'
                    ),
                    vim.host.InternetScsiHba.IscsiIpv6Address(
                        address='fd01:1:3:3004:210:9bff:fe19:56fb',
                        prefixLength=64,
                        origin='Static'
                    )
                ],
                ipv6DhcpConfigurationEnabled=False,
                ipv6LinkLocalAutoConfigurationEnabled=True,
                ipv6RouterAdvertisementConfigurationEnabled=False,
                ipv6DefaultGateway='fe80::464c:a8ff:fe2c:993d',
            )
        )
        # mock software adapter
        self.software_adapter = vim.host.InternetScsiHba(
            iScsiName='iqn.1998-01.com.vmware:esx-0.sddc-10-212-12-193.vmwarevmc.com:1144323480:65',
            iScsiAlias='iscsi_vmk',
            # vmknics
            driver='iscsi_vmk',
            authenticationProperties=self.authentication_properties,
            configuredStaticTarget=[
                vim.host.InternetScsiHba.StaticTarget(
                    address='10.115.40.112',
                    port=3260,
                    iScsiName='iqn.1998-01.com.vmware:target',
                    authenticationProperties=self.authentication_properties,
                    advancedOptions=self.advanced_options,
                    digestProperties=self.digest_properties,
                )
            ],
            configuredSendTarget=[
                vim.host.InternetScsiHba.SendTarget(
                    address='10.115.40.112',
                    port=3260,
                    authenticationProperties=self.authentication_properties,
                    advancedOptions=self.advanced_options,
                    digestProperties=self.digest_properties,
                )
            ],
            advancedOptions=self.advanced_options,
            digestProperties=self.digest_properties,
            device="vmhba2"
        )

        def query_bound_vnics(*args):
            if args[0] == 'vmhba2':
                return ['vmk0', 'vmk1'],
            else:
                raise Exception

        self.host_ref.configManager.iscsiManager.QueryBoundVnics = MagicMock(side_effect=query_bound_vnics)
        self.host_ref.config.storageDevice.hostBusAdapter = []
        self.host_ref.config.storageDevice.hostBusAdapter.append(self.software_adapter)
        # mock dependent hardware adapter
        self.hardware_dependent_adapter = copy.deepcopy(self.software_adapter)
        self.hardware_dependent_adapter.driver = 'elxiscsi'
        self.hardware_dependent_adapter.isSoftwareBased = True
        self.hardware_dependent_adapter.device = 'vmhba64'
        self.host_ref.config.storageDevice.hostBusAdapter.append(self.hardware_dependent_adapter)
        # mock independent hardware adapter
        self.hardware_independent_adapter = copy.deepcopy(self.hardware_dependent_adapter)
        self.hardware_independent_adapter.driver = 'qfle3i'
        self.hardware_independent_adapter.isSoftwareBased = False
        self.hardware_independent_adapter.ipProperties = self.ip_properties
        self.host_ref.config.storageDevice.hostBusAdapter.append(self.hardware_independent_adapter)

    def test_get_configuration(self):
        """
        Test case to validate get configuration for storage_iscsi
        """
        expected_data = {'hardware_adapters':[{'alias':'iscsi_vmk','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'discovery_send_targets':[{'address':'10.115.40.112','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','max_outstanding_r2t':1,'port':3260,'type':'SENDTARGET'}],'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','iqn':'iqn.1998-01.com.vmware:esx-0.sddc-10-212-12-193.vmwarevmc.com:1144323480:65','max_outstanding_r2t':1,'targets':[{'address':'10.115.40.112','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','max_outstanding_r2t':1,'port':3260,'type':'STATIC'}],'type':'DEPENDENT','vmhba':'vmhba64','vmknics':[]},{'alias':'iscsi_vmk','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'discovery_send_targets':[{'address':'10.115.40.112','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','max_outstanding_r2t':1,'port':3260,'type':'SENDTARGET'}],'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','independent_networking':{'arp_redirect':False,'ipv4':{'address':'0.0.0.0','gateway':'0.0.0.0','subnet_mask':'0.0.0.0'},'ipv4_option':'STATIC','ipv6':{'addresses':[{'address':'fd01:1:3:3004:210:9bff:fe19:56fb','prefix_length':64}],'gateway':'fe80::464c:a8ff:fe2c:993d'},'ipv6_option':'STATIC','link_local_address':{'address':'fe80::210:9bff:fe19:56fb','prefix_length':64},'mtu':8342,'primary_dns':'8.8.8.8','secondary_dns':'8.8.4.4'},'iqn':'iqn.1998-01.com.vmware:esx-0.sddc-10-212-12-193.vmwarevmc.com:1144323480:65','max_outstanding_r2t':1,'targets':[{'address':'10.115.40.112','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','max_outstanding_r2t':1,'port':3260,'type':'STATIC'}],'type':'INDEPENDENT','vmhba':'vmhba64','vmknics':[]}],'software_adapter':{'alias':'iscsi_vmk','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'discovery_send_targets':[{'address':'10.115.40.112','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','max_outstanding_r2t':1,'port':3260,'type':'SENDTARGET'}],'enabled':True,'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','iqn':'iqn.1998-01.com.vmware:esx-0.sddc-10-212-12-193.vmwarevmc.com:1144323480:65','max_outstanding_r2t':1,'targets':[{'address':'10.115.40.112','chap_authentication':{'mutual_chap_auth':{'credentials':{'password':'mutualChapSecret','username':'mutualChapName'},'level':'PROHIBITED'},'uni_chap_auth_credentials':{'password':'chapSecret','username':'chapName'},'uni_chap_level':'PROHIBITED'},'data_digest_level':'PROHIBITED','delayed_ack':False,'error_recovery_level':'SESSION_RECOVERY','header_digest_level':'PROHIBITED','max_outstanding_r2t':1,'port':3260,'type':'STATIC'}],'vmknics':[]}}
        data = self.storage_iscsi_config.get_configuration(self.host_ref)
        if data is None:
            self.assertEqual(data, None)
        else:
            self.assertEqual(data, expected_data)

    def test_independent_networking(self):
        """
        Test case to test independent networking cases.
        """
        # dhcp case
        expected = {'arp_redirect':False,'ipv4':{'address':'0.0.0.0','gateway':'0.0.0.0','subnet_mask':'0.0.0.0'},'ipv4_option':'DHCP','ipv6':{'addresses':[{'address':'fd01:1:3:3004:210:9bff:fe19:56fb','prefix_length':64}],'gateway':'192.168.1.1'},'ipv6_option':'DHCPV6','link_local_address':{'address':'fe80::210:9bff:fe19:56fb','prefix_length':64},'mtu':8342,'primary_dns':'8.8.8.8','secondary_dns':'8.8.4.4'}
        self.ip_properties.dhcpConfigurationEnabled = True
        self.ip_properties.ipv6properties.ipv6DhcpConfigurationEnabled = True
        self.ip_properties.ipv6properties.ipv6DefaultGateway = None
        self.ip_properties.ipv6DefaultGateway = "192.168.1.1"
        independent_networking = self.storage_iscsi_config._get_independent_networking(self.ip_properties)
        assert expected == independent_networking.to_dict()
        # router advertisement case
        expected = {'arp_redirect':False,'ipv4':{'address':'0.0.0.0','gateway':'0.0.0.0','subnet_mask':'0.0.0.0'},'ipv4_option':'DHCP','ipv6':{'addresses':[{'address':'fd01:1:3:3004:210:9bff:fe19:56fb','prefix_length':64}],'gateway':'192.168.1.1'},'ipv6_option':'RA','link_local_address':{'address':'fe80::210:9bff:fe19:56fb','prefix_length':64},'mtu':8342,'primary_dns':'8.8.8.8','secondary_dns':'8.8.4.4'}
        self.ip_properties.ipv6properties.ipv6DhcpConfigurationEnabled = False
        self.ip_properties.ipv6properties.ipv6RouterAdvertisementConfigurationEnabled = True
        independent_networking = self.storage_iscsi_config._get_independent_networking(self.ip_properties)
        assert expected == independent_networking.to_dict()
        # no ipv4 and ipv6
        self.ip_properties.ipv4Enabled = False
        self.ip_properties.ipv6Enabled = False
        expected = {'arp_redirect':False,'ipv4_option':'NO_IPV4','ipv6_option':'NO_IPV6','mtu':8342,'primary_dns':'8.8.8.8','secondary_dns':'8.8.4.4'}
        independent_networking = self.storage_iscsi_config._get_independent_networking(self.ip_properties)
        assert expected == independent_networking.to_dict()

    def test_link_local_address(self):
        """
        Test case to check for valid link local ipv6 address.
        """
        ipv6_address = IpAddress()
        ipv6_address.address = "fe80::210:9bff:fe19:56fb"
        ipv6_address.prefix_length = 64
        assert self.storage_iscsi_config._is_link_local_address(ipv6_address)
        ipv6_address.address = "ff80::210:9bff:fe19:56fb"
        ipv6_address.prefix_length = 64
        assert not self.storage_iscsi_config._is_link_local_address(ipv6_address)
        ipv6_address.address = "fe80::210:9bff:fe19:56fb"
        ipv6_address.prefix_length = 16
        assert not self.storage_iscsi_config._is_link_local_address(ipv6_address)

    def test_module_name(self):
        self.assertEqual(self.storage_iscsi_config.module_name(), 'storage_iscsi')
