import unittest
from unittest.mock import patch, Mock
from config_modules_vmware.esxi.config_submodules.advanced_options_config import AdvancedOptionsConfig


class TestAdvancedOptionsConfig(unittest.TestCase):
    def setUp(self) -> None:
        pass

    def tearDown(self) -> None:
        pass

    @patch.object(AdvancedOptionsConfig, '_get_user_vars_config')
    @patch.object(AdvancedOptionsConfig, '_get_dict_options_config')
    @patch.object(AdvancedOptionsConfig, '_get_hidden_options_config')
    def test_get_configurations(self, mock_get_hidden_options_config, mock_get_dict_options_config, mock_get_user_vars_config):
        AdvancedOptionsConfig(Mock()).get_configuration(Mock(), include_defaults=True)
        mock_get_user_vars_config.assert_called_with()

    @patch.object(AdvancedOptionsConfig, '_invoke_advanced_option_query')
    def test_user_vars(self, mock_invoke_advanced_option_query):
        obj = AdvancedOptionsConfig(Mock())
        obj.host_ref = Mock(name='host-1')
        obj._get_user_vars_config()
        mock_invoke_advanced_option_query.assert_called_with(query='UserVars.')

    @patch.object(AdvancedOptionsConfig, '_get_updated_config_dict')
    def test_get_non_default_advanced_options_config(self, mock_get_updated_config_dict):
        obj = AdvancedOptionsConfig(Mock())
        obj.host_ref = Mock(name='host-1')
        obj.get_non_default_advanced_options_config()
        mock_get_updated_config_dict.assert_called()

    @patch.object(AdvancedOptionsConfig, '_get_data_using_esxcli')
    def test_get_updated_config_dict(self, mock_get_data_using_esxcli):
        res = [{'DefaultIntValue': '5', 'DefaultStringValue': '', 'Description': 'Desc1', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '90', 'MaxValue': '86400', 'MinValue': '1', 'Path': '/Misc/HeartbeatTimeout', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''},
               {'DefaultIntValue': '10', 'DefaultStringValue': '', 'Description': 'Desc2', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '900', 'MaxValue': '86400', 'MinValue': '1', 'Path': '/Misc/HeartbeatPanicTimeout', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''},
               {'DefaultIntValue': '0', 'DefaultStringValue': 'localhost', 'Description': 'Desc3', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '0', 'MaxValue': '0', 'MinValue': '0', 'Path': '/Misc/HostName', 'StringValue': 'sc2-10-186-130-14.eng.vmware.com', 'Type': 'string', 'ValidCharacters': '**', '': ''},
               {'DefaultIntValue': '0', 'DefaultStringValue': '', 'Description': 'Desc4', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '1', 'MaxValue': '1', 'MinValue': '0', 'Path': '/Net/FollowHardwareMac', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''},
               {'DefaultIntValue': '4294967295', 'DefaultStringValue': '', 'Description': 'Desc5', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '0', 'MaxValue': '4294967295', 'MinValue': '0', 'Path': '/Mem/VMOverheadGrowthLimit', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''},
               {'DefaultIntValue': '0', 'DefaultStringValue': '', 'Description': 'Desc6', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '0', 'MaxValue': '0', 'MinValue': '0', 'Path': '/Migrate/Vmknic', 'StringValue': 'vmk0', 'Type': 'string', 'ValidCharacters': '**', '': ''}]

        mock_get_data_using_esxcli.return_value = res
        expected_ret_val = {'Misc': [{'HeartbeatTimeout': '90'}, {'HeartbeatPanicTimeout': '900'}],
               'Net': [{'FollowHardwareMac': '1'}],
               'Mem': [{'VMOverheadGrowthLimit': '0'}]}
        obj = AdvancedOptionsConfig(Mock())
        ret_val = obj._get_updated_config_dict()
        assert expected_ret_val == ret_val

    @patch.object(AdvancedOptionsConfig, '_get_data_using_esxcli')
    def test_get_hidden_options_config(self, mock_get_data_using_esxcli):
        obj = AdvancedOptionsConfig(Mock())
        obj.advanced_options_mapping = {
            "COW": {
                "COWAllowVMFSSparseCoalesce": {
                    "hidden": True,
                    "name": "COW_allow_VMFS_sparse_coalesce"
                }
            }
        }
        obj._get_hidden_options_config('COW', {})
        query_string = f'-o=/COW/COWAllowVMFSSparseCoalesce'
        mock_get_data_using_esxcli.assert_called_with(query_string)

    @patch.object(AdvancedOptionsConfig, '_get_data_using_esxcli')
    def test_get_hidden_options_config_not_called(self, mock_get_data_using_esxcli):
        obj = AdvancedOptionsConfig(Mock())
        obj.advanced_options_mapping = {
            "COW": {
                "COWAllowVMFSSparseCoalesce": {
                    "hidden": False,
                    "name": "COW_allow_VMFS_sparse_coalesce"
                }
            }
        }
        obj._get_hidden_options_config('COW', {})
        mock_get_data_using_esxcli.assert_not_called()
