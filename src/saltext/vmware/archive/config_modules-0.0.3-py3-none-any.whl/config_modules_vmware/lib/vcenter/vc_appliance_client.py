# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging

from config_modules_vmware.lib.common.credentials import VcenterCredentials
from config_modules_vmware.lib.vcenter.vc_rest_client import VcRestClient

# Set up logger
logger = logging.getLogger(__name__)


class VcApplianceClient(VcRestClient):
    """
    Class to provide helper functions invoke  VCENTER Appliance REST APIs.
    """

    def __init__(self, vc_access: VcenterCredentials):
        """
        :type vc_access: :class:`VcenterCredentials`
        :param vc_access: credentials used to connect to vcenter.
        """
        super(VcApplianceClient, self).__init__(vc_access)
        self._appliance_base_url = self._base_url + "api/appliance/vcenter/"

    def extract_current_config(self):
        """
        Extracts the current config of VC appliance.
        """
        url = self._appliance_base_url + "settings/v1/config-current"
        return self.get_helper(url=url)

    def get_desired_state(self):
        """
        Get desired state configured in VC
        """
        url = self._appliance_base_url + "settings/v1/config"
        return self.get_helper(url=url)

    def check_for_drift(self, profile_id):
        """
        Check for drift against configured profile id.
        """
        url = self._appliance_base_url + "settings/v1/config/{}?action=scan&vmw-task=true".format(profile_id)
        return self.post_helper(url=url)

    def create_desired_state_profile(self, payload):
        """
        Create desired state profile
        """
        url = self._appliance_base_url + "settings/v1/config"
        return self.post_helper(url=url, body=payload)

    def validate_desired_state_config(self, payload):
        """
        Validate desired state payload against schema.
        """
        url = self._appliance_base_url + "settings/v1/config?action=check-desired-state&vmw-task=true"
        return self.post_helper(url=url, body=payload)