# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging

from config_modules_vmware.lib.common.credentials import VcenterCredentials
from config_modules_vmware.lib.vcenter.vc_rest_client import VcRestClient

# Set up logger
logger = logging.getLogger(__name__)


class VcVcenterClient(VcRestClient):
    """
    Class to provide helper functions invoke  VCENTER Appliance REST APIs.
    """

    def __init__(self, vc_access: VcenterCredentials):
        """
        :type vc_access: :class:`VcenterCredentials`
        :param vc_access: credentials used to connect to vcenter.
        """
        super(VcVcenterClient, self).__init__(vc_access)
        self._appliance_base_url = self._base_url + "api/vcenter/"

    def get_clusters(self):
        """
        Extracts the current config of VC appliance.
        """
        url = self._appliance_base_url + "cluster"
        return self.get_helper(url=url)
