from time import sleep

from flask import Flask

app = Flask(__name__)


@app.route('/server/request-1', methods=['GET'])
def get_request_1():
    sleep(5)
    return "request 1 result"


@app.route('/server/request-2', methods=['GET'])
def get_request_2():
    sleep(2)
    return "request 2 result"


if __name__ == '__main__':
    app.run(debug=True)