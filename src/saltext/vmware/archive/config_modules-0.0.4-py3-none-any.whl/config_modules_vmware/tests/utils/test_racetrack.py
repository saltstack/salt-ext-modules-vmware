# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from config_modules_vmware.tests.test_helpers.racetrack import Racetrack

racetrack1 = Racetrack()
racetrack2 = Racetrack()


def test_positive_create_test_set():
    test_set_creation = racetrack1.test_set_begin("build", "user", "product", "description", "host")
    assert test_set_creation == True


def test_positive_create_test_case():
    test_case_creation = racetrack1.test_case_begin("test case", "feature", "description")
    assert test_case_creation == True


def test_positive_add_comment():
    add_comment = racetrack1.comment("Adding a comment to racetrack")
    assert add_comment == True


def test_positive_add_warning():
    add_warning = racetrack1.warning("warning")
    assert add_warning == True


def test_positive_verify():
    equal_verify = racetrack1.verify("Checking verify for equal values?", "true", "true")
    assert equal_verify == True


def test_positive_test_case_end():
    test_case_status = racetrack1.test_case_end("PASS")
    assert test_case_status == True


def test_positive_test_set_end():
    test_case_end = racetrack1.test_set_end()
    assert test_case_end == True


def test_negative_test_set_begin():
    test_set_failure = racetrack2.test_set_begin("", "user", "product", "description", "host")
    assert test_set_failure == False

    # Creating successful testset to continue testing
    racetrack2.test_set_begin("build", "user", "product", "description", "host")


def test_negative_test_case_begin():
    test_case_failure = racetrack2.test_case_begin("test case", "", "description")
    assert test_case_failure == False

    # Creating a successful test case to test failures updating it
    racetrack2.test_case_begin("test case", "feature", "description")


def test_negative_add_comment():
    comment_failure = racetrack2.comment("")
    assert comment_failure == False


def test_negative_add_warning():
    warning_failure = racetrack2.warning("")
    assert warning_failure == False


def test_negative_verify():
    verify_failure = racetrack2.verify("Are they the same?", "", "true")
    assert verify_failure == False


def test_negative_test_case_end():
    # Failing due to missing ID
    test_case_end_failure = racetrack2.test_case_end("")
    assert test_case_end_failure == False

    # Failing due to invalid result type
    racetrack2.result_id = ""
    test_case_end_failure = racetrack2.test_case_end("PASS")
    assert test_case_end_failure == False


def test_negative_test_set_end():
    racetrack2.test_set_id = ""
    test_set_end_failure = racetrack2.test_set_end()
    assert test_set_end_failure == False
