# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import pytest
import unittest
import json
from unittest.mock import MagicMock, patch

from config_modules_vmware.utils.config_manipulation import ConfigManipulation, Operations, SetStatus
from config_modules_vmware.esxi.config_submodules.config_property_base import ConfigProperty


class TestConfigKey(ConfigProperty):
    def get(self, context, host_ref):
        return host_ref.test_key

    def set(self, context, host_ref, value):
        context.set_function_called = True
        if host_ref.set_status:
            host_ref.test_key = value
            return True
        return False

    def precheck(self, context, host_ref, value):
        return 'REBOOT_REQUIRED'


class TestConfigManipulation(unittest.TestCase):

    def setUp(self) -> None:
        self.context = MagicMock()
        self.host_ref = MagicMock()
        self.host_ref.name = "test_host_name"
        self.host_ref.test_key = 'init_value'
        self.host_ref.set_status = True
        self.config_mapping = {
            "config": {
                "profile": {
                    "esx": {
                        "test_key": __name__ + ".TestConfigKey"
                    }
                }
            }
        }
        self.context.set_function_called = False

    def test_no_config_template(self):
        config_mapping = None
        expected_config = None
        with pytest.raises(Exception):
            config = ConfigManipulation.operate(self.context, self.host_ref, config_mapping, Operations.GET)
            assert config == expected_config

    def test_get_bad_module_path(self):
        config_mapping = {
            "config": {
                "profile": {
                    "esx": {
                        "test_key": "bad_path"
                    }
                }
            }
        }
        expected_config = {'config': {'profile': {'esx': {}}}}
        config = ConfigManipulation.operate(self.context, self.host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_no_config_class(self):
        config_mapping = {
            "config": {
                "profile": {
                    "esx": {
                        "test_key": __name__ + ".BadConfigClass"
                    }
                }
            }
        }
        expected_config = {'config': {'profile': {'esx': {}}}}
        config = ConfigManipulation.operate(self.context, self.host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_operation(self):
        expected_config = {'config': {'profile': {'esx': {'test_key': 'test_get_val'}}}}
        self.host_ref.test_key = 'test_get_val'
        config = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.GET)
        assert config == expected_config

    def test_set_operation_success(self):
        self.host_ref.set_status = True
        set_values = {'config': {'profile': {'esx': {'test_key': 'test_set_val'}}}}
        expected_result = {SetStatus.SUCCESS.value: ['/config/profile/esx/test_key'], SetStatus.FAILED.value: [], SetStatus.SKIPPED.value: []}
        assert self.host_ref.test_key == 'init_value'
        assert not self.context.set_function_called
        result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.SET, set_values)
        assert self.host_ref.test_key == 'test_set_val'
        assert result == expected_result
        assert self.context.set_function_called

    def test_set_operation_same_as_current_value(self):
        self.host_ref.set_status = True
        set_values = {'config': {'profile': {'esx': {'test_key': 'init_value'}}}}
        expected_result = {SetStatus.SKIPPED.value: ['/config/profile/esx/test_key'], SetStatus.FAILED.value: [], SetStatus.SUCCESS.value: []}
        assert self.host_ref.test_key == 'init_value'
        assert not self.context.set_function_called
        result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.SET, set_values)
        assert self.host_ref.test_key == 'init_value'
        assert result == expected_result
        assert not self.context.set_function_called

    def test_set_operation_failed(self):
        self.host_ref.set_status = False
        set_values = {'config': {'profile': {'esx': {'test_key': 'test_set_val'}}}}
        expected_result = {SetStatus.SUCCESS.value: [], SetStatus.FAILED.value: ['/config/profile/esx/test_key']}
        assert self.host_ref.test_key == 'init_value'
        with pytest.raises(Exception):
            result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.SET, set_values)
            assert self.host_ref.test_key == 'init_value'
            assert result == expected_result

    def test_remediate_operation_success(self):
        self.host_ref.set_status = True
        set_values = {'config': {'profile': {'esx': {'test_key': 'test_remediate_val'}}}}
        expected_result = {SetStatus.SUCCESS.value: ['/config/profile/esx/test_key'], SetStatus.FAILED.value: [], SetStatus.SKIPPED.value: []}
        assert self.host_ref.test_key == 'init_value'
        assert not self.context.set_function_called
        result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.REMEDIATE, set_values)
        assert self.host_ref.test_key == 'test_remediate_val'
        assert result == expected_result
        assert self.context.set_function_called

    def test_remediate_operation_failed(self):
        self.host_ref.set_status = False
        set_values = {'config': {'profile': {'esx': {'test_key': 'test_remediate_val'}}}}
        expected_result = {SetStatus.SUCCESS.value: [], SetStatus.FAILED.value: ['/config/profile/esx/test_key']}
        assert self.host_ref.test_key == 'init_value'
        with pytest.raises(Exception):
            result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.REMEDIATE, set_values)
            assert self.host_ref.test_key == 'init_value'
            assert result == expected_result

    def test_set_operation_missing_new_value(self):
        self.host_ref.set_status = False
        set_values = {'config': {'profile': {}}}
        expected_result = {SetStatus.SUCCESS.value: [], SetStatus.FAILED.value: ['/config/profile/esx']}
        assert self.host_ref.test_key == 'init_value'
        with pytest.raises(Exception):
            result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.SET, set_values)
            assert self.host_ref.test_key == 'init_value'
            assert result == expected_result

    def test_set_operation_no_apply_values(self):
        self.host_ref.set_status = False
        set_values = None
        expected_result = None
        assert self.host_ref.test_key == 'init_value'
        with pytest.raises(Exception):
            result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.SET, set_values)
            assert self.host_ref.test_key == 'init_value'
            assert result == expected_result

    def test_set_bad_module_path(self):
        config_mapping = {
            "config": {
                "profile": {
                    "esx": {
                        "test_key": "bad_path"
                    }
                }
            }
        }
        set_values = {'config': {'profile': {'esx': {'test_key': 'test_set_val'}}}}
        expected_result = {SetStatus.SUCCESS.value: [], SetStatus.FAILED.value: ['/config/profile/esx/test_key']}
        assert self.host_ref.test_key == 'init_value'
        with pytest.raises(Exception):
            result = ConfigManipulation.operate(self.context, self.host_ref, config_mapping, Operations.SET, set_values)
            assert self.host_ref.test_key == 'init_value'
            assert result == expected_result

    def test_precheck_operation(self):
        # PRECHECK responses are not yet defined.
        # Using REBOOT_REQUIRED as a placeholder but this should be replaced when the final implementation is done.
        expected_data = {'config': {'profile': {'esx': {'test_key': 'REBOOT_REQUIRED'}}}}
        set_values = {'config': {'profile': {'esx': {'test_key': 'test_set_val'}}}}
        config = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.PRECHECK, set_values)
        assert config == expected_data

    def test_precheck_operation_missing_new_value(self):
        self.host_ref.set_status = False
        set_values = {'config': {'profile': {}}}
        expected_result = {'config': {'profile': {'esx': 'UNKNOWN'}}}
        assert self.host_ref.test_key == 'init_value'
        result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.PRECHECK, set_values)
        assert self.host_ref.test_key == 'init_value'
        assert result == expected_result

    def test_precheck_operation_no_apply_values(self):
        self.host_ref.set_status = False
        set_values = None
        expected_result = None
        assert self.host_ref.test_key == 'init_value'
        with pytest.raises(Exception):
            result = ConfigManipulation.operate(self.context, self.host_ref, self.config_mapping, Operations.PRECHECK, set_values)
            assert self.host_ref.test_key == 'init_value'
            assert result == expected_result

    def test_precheck_bad_module_path(self):
        config_mapping = {
            "config": {
                "profile": {
                    "esx": {
                        "test_key": "bad_path"
                    }
                }
            }
        }
        expected_config = {'config': {'profile': {'esx': {}}}}
        set_values = {'config': {'profile': {'esx': {'test_key': 'test_set_val'}}}}
        config = ConfigManipulation.operate(self.context, self.host_ref, config_mapping, Operations.PRECHECK, set_values)
        assert config == expected_config

    def test_get_config_mapping_template(self):
        """
        Test to get config mapping template
        """

        config_mapping_template = ConfigManipulation.get_config_mapping_template()
        assert config_mapping_template is not None

    def test_get_config_mapping_template_file_not_present(self):
        with patch('os.path.exists', return_value=False):
            with pytest.raises(Exception) as excinfo:
                ConfigManipulation.get_config_mapping_template()
        assert "Missing file" in str(excinfo.value)

    def test_get_config_mapping_template_json_exception(self):
        with patch('os.path.exists', return_value=True):
            with patch('json.load', side_effect=json.JSONDecodeError('JSON decode error', '', 0)):
                with pytest.raises(Exception) as excinfo:
                    ConfigManipulation.get_config_mapping_template()
            assert "Error decoding" in str(excinfo.value)
