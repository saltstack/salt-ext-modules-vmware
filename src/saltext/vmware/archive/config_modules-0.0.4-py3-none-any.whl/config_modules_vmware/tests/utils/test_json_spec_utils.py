# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import pytest
from config_modules_vmware.utils.json_spec_utils import JSONSpecUtils

class TestJSONSpecUtils:

    def test_compare_specs_and_report_differences_same_objects(self):
        obj1 = {"profile": "esx"}
        obj2 = {"profile": "esx"}
        differences = JSONSpecUtils.compare_specs_and_report_differences(obj1, obj2)
        assert differences == {}

    def test_compare_specs_and_report_differences_different_objects(self):
        obj1 = {"profile": {"esx": {"mtu": "9000", "ssh": True}}}
        obj2 = {"profile": {"esx": {"mtu": "9000", "ssh": False}}}
        differences = JSONSpecUtils.compare_specs_and_report_differences(obj1, obj2)
        assert differences == {"profile/esx/ssh": (True, False)}

    def test_compare_specs_and_report_differences_nested_objects(self):
        obj1 = {"profile": {"esx": {"mtu": "9000", "ssh": True}}}
        obj2 = {"profile": {"esx": {"mtu": "9000", "ssh": True}}}
        differences = JSONSpecUtils.compare_specs_and_report_differences(obj1, obj2)
        assert differences == {}

    def test_compare_specs_and_report_differences_arrays(self):
        obj1 = {"profile": {"esx": {"network" : {"vmnics": [{"mtu": 9000}, {"mtu": 9000}]}}}}
        obj2 = {"profile": {"esx": {"network" : {"vmnics": [{"mtu": 9000}, {"mtu": 7000}]}}}}
        differences = JSONSpecUtils.compare_specs_and_report_differences(obj1, obj2)
        expected_differences = {'profile/esx/network/vmnics/1/mtu': (9000, 7000)}
        assert differences == expected_differences