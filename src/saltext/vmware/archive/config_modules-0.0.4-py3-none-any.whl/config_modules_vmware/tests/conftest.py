# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import importlib
import os
from configparser import ConfigParser
from unittest.mock import MagicMock, Mock

import pytest

from config_modules_vmware.lib.common.credentials import SddcCredentials, VcenterCredentials

UNIT_TEST = os.getenv('DEV_TEST', 'False') == 'False'


@pytest.fixture
def creds_fixture():
    parser = ConfigParser()
    parser.optionxform = str
    config_file_path = os.path.join(os.path.dirname(__file__), "config.ini")
    config = parser.read(config_file_path)
    if not config:
        raise ValueError('No config file found!')

    # Loading Vcenter credentials
    vc_creds = VcenterCredentials()
    items = parser.items("VcenterCredentials")
    vc_creds.__dict__.update(items)
    return SddcCredentials(vc_creds=vc_creds)


@pytest.fixture(autouse=True, scope='function')
def patch_functions(request):
    _patch_functions = request.node.get_closest_marker('patch_functions')
    if _patch_functions:
        function_paths = request.node.get_closest_marker("patch_functions").kwargs.get("function_paths", [])
        if UNIT_TEST and function_paths:
            for func_path, mocked_func in function_paths.items():
                module_path, class_name, func_name = func_path.rsplit('.', 2)
                module = importlib.import_module(module_path)
                class_ = getattr(module, class_name)
                setattr(class_, func_name, MagicMock(side_effect=lambda *args, **kwargs: mocked_func(*args, **kwargs)))


@pytest.fixture(autouse=True, scope='function')
def patch_classes(request, mocker):
    _patch_classes = request.node.get_closest_marker('patch_classes')
    if _patch_classes:
        class_paths = request.node.get_closest_marker("patch_classes").kwargs.get("class_paths", [])
        if UNIT_TEST and class_paths:
            for class_path, mock_obj in class_paths.items():
                mocker.patch(class_path, return_value=mock_obj)
