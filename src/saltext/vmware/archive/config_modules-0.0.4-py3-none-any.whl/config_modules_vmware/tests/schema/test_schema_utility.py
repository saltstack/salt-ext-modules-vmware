# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from unittest.mock import patch

import pytest

from config_modules_vmware.schema.schema_utility import retrieve_reference_schema, Product


def test_retrieve_reference_schema():
    """
    Test to retrieve reference schema
    """
    reference_schema = retrieve_reference_schema(Product.ESX)
    assert reference_schema is not None


def test_retrieve_missing_reference_schema():
    """
    Test to retrieve missing reference schema
    """
    with patch('config_modules_vmware.schema.schema_utility.Product') as mock_enum:
        with pytest.raises(Exception):
            mock_enum.ESX = "invalid.json"
            reference_schema = retrieve_reference_schema(Product.ESX)
            assert reference_schema is None
