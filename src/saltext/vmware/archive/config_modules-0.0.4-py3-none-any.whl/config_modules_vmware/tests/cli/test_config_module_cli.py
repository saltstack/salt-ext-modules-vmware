# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json
import os

import pytest

from config_modules_vmware.esxi.esx_config import EsxConfig
from pytest_console_scripts import ScriptRunner
from unittest import mock
from unittest.mock import patch, MagicMock

from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.lib.vcenter.vc_vmomi_client import VcVmomiClient

FAILED_RESPONSE = \
    {
        "status": "FAILED",
        "config": {}
    }


def test_config_module_cli(script_runner) -> None:
    """
    Test to validate that the CLI command tool works.
    @param script_runner:
    """
    ret = script_runner.run(['config-modules-cli', '--help'])
    assert ret.success
    assert ret.stderr == ''


def mock_get_configuration_exception(*args, **kwargs):
    raise Exception('mocked_exception')


@patch.object(EsxConfig, 'get_configuration')
def test_failed_get_config_workflow(mock_esx_config_get_configuration_method, script_runner: ScriptRunner) -> None:
    """
    Test to validate errors returned after the esx module fails.
    @param mock_esx_config_get_configuration_method: mocked get_configuration method from EsxConfig.
    @param script_runner:
    """
    mock_esx_config_get_configuration_method.side_effect = mock_get_configuration_exception
    mock_env_vars = mock.patch.dict(os.environ, {'AGENT_NAME': 'stderr'})
    mock_env_vars.start()
    ret = script_runner.run(['config-modules-cli', 'config', 'get', '--product', 'esx',
                             '--vc-fqdn', 'test_fqdn', '--password', 'test_password', '--username', 'test_username',
                             '--ssl-thumbprint', 'test_thumbprint'],
                            print_result=True, shell=True)
    mock_env_vars.stop()
    returned_response = json.loads(ret.stdout)
    assert returned_response == FAILED_RESPONSE
    assert "mocked_exception" in ret.stderr
    assert not ret.success


@pytest.mark.parametrize('test_command, non_vlcm_expected_call_count, vlcm_expected_call_count',
                         [
                             (['config-modules-cli', 'config', 'get', '--product', 'esx',
                               '--vc-fqdn', 'test_fqdn', '--password', 'test_password', '--username', 'test_username',
                               '--ssl-thumbprint', 'test_thumbprint'], 1, 0),
                             (['config-modules-cli', 'config', 'get', '--product', 'esx',
                               '--vc-fqdn', 'test_fqdn', '--password', 'test_password', '--username', 'test_username',
                               '--ssl-thumbprint', 'test_thumbprint', '--enable-vlcm-flow'], 0, 1),
                         ])
@patch.object(EsxConfig, '_get_esx_config_vlcm_flow')
@patch.object(EsxConfig, '_get_esx_config_non_vlcm_flow')
@patch.object(EsxContext, 'vc_vmomi_client')
@patch.object(EsxContext, 'vc_vlcm_client')
def test_enable_vlcm_flow_flag(mock_esx_context_vc_vlcm_client, mock_esx_context_vc_vmomi_client,
                               mock_esx_config_get_non_vlcm_flow,
                               mock_esx_config_get_vlcm_flow, test_command, non_vlcm_expected_call_count,
                               vlcm_expected_call_count,
                               script_runner: ScriptRunner) -> None:
    """
    Test to validate that --enable-vlcm-flow flag in CLI works as expected.
    @param mock_esx_context_vc_vlcm_client: mock EsxContext.vc_vlcm_client()
    @param mock_esx_context_vc_vmomi_client: mock EsxContext.vc_vmomoi_client()
    @param mock_esx_config_get_non_vlcm_flow: mock EsxConfig._get_esx_config_non_vlcm_flow()
    @param mock_esx_config_get_vlcm_flow: mock EsxConfig._get_esx_config_vlcm_flow()
    @param test_command: parametrized test command (pass --enable-vlcm-flow flag or not)
    @param non_vlcm_expected_call_count: parametrized  call count for non_vlcm_flow method
    @param vlcm_expected_call_count: parametrized  call count for vlcm_flow method
    @param script_runner: calls config-modules-cli executable
    """
    mock_vc_vlcm_client_obj = MagicMock()
    mock_vc_vlcm_client_obj.is_vlcm_config_manager_supported_in_vcsa.return_value = True
    mock_esx_context_vc_vlcm_client.return_value = mock_vc_vlcm_client_obj

    mock_cluster_ref = MagicMock()
    mock_host_ref = MagicMock()
    mock_vc_vmomi_client_obj = MagicMock()
    mock_vc_vmomi_client_obj.get_all_clusters.return_value = [mock_cluster_ref]
    mock_vc_vmomi_client_obj.get_all_hosts_from_parent.return_value = [mock_host_ref]
    mock_vc_vmomi_client_obj.get_all_standalone_esx_hosts_from_vc.return_value = []
    mock_esx_context_vc_vmomi_client.return_value = mock_vc_vmomi_client_obj

    mock_esx_config_get_non_vlcm_flow.return_value = {}
    mock_esx_config_get_vlcm_flow.return_value = {}
    script_runner.run(test_command,
                      print_result=True, shell=True)
    assert mock_esx_config_get_non_vlcm_flow.call_count == non_vlcm_expected_call_count
    assert mock_esx_config_get_vlcm_flow.call_count == vlcm_expected_call_count
