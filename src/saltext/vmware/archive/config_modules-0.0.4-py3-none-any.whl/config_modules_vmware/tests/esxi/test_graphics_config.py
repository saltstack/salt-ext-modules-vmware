# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import copy
import unittest
from unittest.mock import MagicMock

from config_modules_vmware.esxi.config_submodules.graphics_config import GraphicsConfig, GraphicsConfigModel, DefaultType, SharedPassthruAssignmentPolicy, Policy, Device

class TestGraphicsConfig(unittest.TestCase):
    def setUp(self) -> None:
        self.context = MagicMock()
        self.graphics_config = GraphicsConfig(self.context)
        self.vgpu_device_info = []
        self.graphics_config.hostDefaultGraphicsType = DefaultType.SHARED
        self.graphics_config.sharedPassthruAssignmentPolicy = SharedPassthruAssignmentPolicy.PERFORMANCE
        self.host_ref = MagicMock()
        self.graphics_info_object = MagicMock()
        self.graphics_info_object.deviceName = "device"
        self.graphics_info_object.graphics_type = DefaultType.SHARED
        self.host_ref.config.graphicsConfig = self.graphics_config
        self.host_ref.configManager.graphicsManager.graphicsConfig = self.graphics_config
        self.host_ref.configManager.graphicsManager.graphicsInfo = []
        self.host_ref.configManager.graphicsManager.graphicsInfo.append(self.graphics_info_object)
        self.devices = []
        self.device = Device()
        self.device.type = DefaultType.SHARED
        self.device.device = "device"
        self.devices.append(self.device)
        self.policy = Policy()
        self.policy.default_type = DefaultType.SHARED
        self.policy.shared_passthru_assignment_policy = SharedPassthruAssignmentPolicy.PERFORMANCE
        self.graphics_config_obj = GraphicsConfigModel(self.policy, self.devices)
        self.host_ref.configManager.graphicsManager.graphicsConfig.graphics_config_obj = self.graphics_config_obj

    def test_get_configuration(self):
        expected_data = {'devices': [{'device': 'device', 'type': 'SHARED'}], 'policy': {'default_type': 'SHARED', 'shared_passthru_assignment_policy': 'PERFORMANCE'}}
        data = self.graphics_config.get_configuration(self.host_ref)
        if data is None:
            self.assertEqual(data, None)
        else:
            self.assertEqual(data, expected_data)

    def test_module_name(self):
        self.assertEqual(self.graphics_config.module_name(), 'graphics')