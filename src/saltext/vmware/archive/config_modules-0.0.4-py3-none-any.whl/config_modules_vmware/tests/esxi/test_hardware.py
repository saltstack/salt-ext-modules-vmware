import unittest
from unittest.mock import MagicMock, patch
from config_modules_vmware.esxi.config_model.hardware_config_model import  UsbPassThroughSwitch, HardwareConfigData
from config_modules_vmware.esxi.config_submodules.hardware_config   import HardwareConfig


class TestHardwareConfig(unittest.TestCase):
    def setUp(self):
        self.context = MagicMock()
        self.host_ref = MagicMock()
        self.host_ref.name = "test_host"
        self.hardware_config = HardwareConfig(self.context)

    def test_get_usb_passthrough_list(self):
        mock_esxcli_client = self.context.esxcli_client.return_value
        mock_execute_result = [
            {"Bus": "00", "Dev": "01", "VendorId": "1234", "ProductId": "5678", "Enabled": True},
            {"Bus": "01", "Dev": "02", "VendorId": "5678", "ProductId": "1234", "Enabled": False},
        ]
        mock_esxcli_client.host.return_value.namespace.return_value.command.return_value.execute.return_value = mock_execute_result

        usb_pass_thru_list = self.hardware_config._get_usb_passthroguh_list(self.host_ref)

        expected_usb_pass_thru_list = [
            UsbPassThroughSwitch("00", "01", "1234", "5678", True).to_dict(),
            UsbPassThroughSwitch("01", "02", "5678", "1234", False).to_dict(),
        ]
        self.assertEqual(usb_pass_thru_list, expected_usb_pass_thru_list)

    def test_get_configuration(self):
        self.hardware_config._get_usb_passthroguh_list = MagicMock(return_value=[
            UsbPassThroughSwitch("00", "01", "1234", "5678", True).to_dict(),
            UsbPassThroughSwitch("01", "02", "5678", "1234", False).to_dict(),
        ])

        expected_config = HardwareConfigData([
            UsbPassThroughSwitch("00", "01", "1234", "5678", True).to_dict(),
            UsbPassThroughSwitch("01", "02", "5678", "1234", False).to_dict(),
        ])

        data = self.hardware_config.get_configuration(self.host_ref)


        if data is None:
            self.assertEqual(data, None)
        else:
             self.assertEqual(data, expected_config.to_dict())

