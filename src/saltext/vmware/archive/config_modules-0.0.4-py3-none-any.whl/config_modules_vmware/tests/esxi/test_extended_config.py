# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import pytest
import unittest
from unittest.mock import MagicMock

from config_modules_vmware.utils.config_manipulation import ConfigManipulation, Operations, SetStatus

class EsxiServiceConfigMock:
    def __init__(self, dict) -> None:
        self.key = dict.get("key")
        self.running = dict.get("running")
    
class TestExtendedConfig(unittest.TestCase):

    def setUp(self) -> None:
        self.context = MagicMock()

    def test_get_cim_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "cim_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Cim",
                    }
        expected_config = { "cim_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_cim(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "sfcbd-watchdog", "running": True})]
        config_mapping = {
          "cim_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Cim",
                    }
        expected_config = { "cim_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_shell_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "shell_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Shell",
                    }
        expected_config = { "shell_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_shell(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "TSM", "running": True})]
        config_mapping = {
          "shell_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Shell",
                    }
        expected_config = { "shell_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_slp_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "slp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Slp",
                    }
        expected_config = { "slp_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_slp(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "slpd", "running": True})]
        config_mapping = {
          "slp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Slp",
                    }
        expected_config = { "slp_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_snmp_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "snmp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Snmp",
                    }
        expected_config = { "snmp_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_snmp(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "snmpd", "running": True})]
        config_mapping = {
          "snmp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Snmp",
                    }
        expected_config = { "snmp_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_ssh_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "ssh_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Ssh",
                    }
        expected_config = { "ssh_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_ssh(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "TSM-SSH", "running": True})]
        config_mapping = {
          "ssh_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Ssh",
                    }
        expected_config = { "ssh_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_lockdown_exception_users(self):
        host_ref = MagicMock()
        exceptions = ["user1", "user2"]
        host_ref.configManager.hostAccessManager.QueryLockdownExceptions = MagicMock(return_value=exceptions)
        config_mapping = {
          "lockdown_exception_users": "config_modules_vmware.esxi.config_submodules.extended_config.LockdownExceptionUsers",
                    }
        expected_config = { "lockdown_exception_users": exceptions}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_lockdown_mode_disabled(self):
        host_ref = MagicMock()
        host_ref.config.lockdownMode = "lockdownDisabled"
        config_mapping = {
          "lockdown_mode": "config_modules_vmware.esxi.config_submodules.extended_config.LockdownMode",
                    }
        expected_config = { "lockdown_mode": "disabled"}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_lockdown_mode_normal(self):
        host_ref = MagicMock()
        host_ref.config.lockdownMode = "lockdownNormal"
        config_mapping = {
          "lockdown_mode": "config_modules_vmware.esxi.config_submodules.extended_config.LockdownMode",
                    }
        expected_config = { "lockdown_mode": "normal"}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config