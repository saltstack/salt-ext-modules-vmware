# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import pytest
import unittest
from unittest.mock import MagicMock,patch
from config_modules_vmware.esxi.config_submodules.extended_config import (
    Cim,
    Shell,
    Slp,
    Snmp,
    Ssh,
    LockdownExceptionUsers,
    LockdownMode,    
    ServiceConfig,
)


from config_modules_vmware.utils.config_manipulation import ConfigManipulation, Operations, SetStatus

# Define a common setup function for the tests
@pytest.fixture
def setup_config_property():
    context = MagicMock()
    host_ref = MagicMock()

    with patch.object(ServiceConfig, "_get_service") as mock_get_service:
        with patch.object(ServiceConfig, "_start_service") as mock_start_service:
            with patch.object(ServiceConfig, "_stop_service") as mock_stop_service:
                yield context, host_ref, mock_get_service, mock_start_service, mock_stop_service

# Test the set method for Cim when the service is already running
def test_set_cim_service_already_running(setup_config_property):
    context, host_ref, mock_get_service, _, _ = setup_config_property
    value = True
    mock_get_service.return_value.running = True
    assert Cim().set(context, host_ref, value) == True


# Test the set method for Shell when the service is not running
def test_set_shell_service_not_running(setup_config_property):
    context, host_ref, mock_get_service, mock_start_service, _ = setup_config_property
    value = True
    mock_get_service.return_value.running = False
    mock_start_service.return_value = True
    assert Shell().set(context, host_ref, value) == True

# Test the set method for Slp when the service is already running
def test_set_slp_service_already_running(setup_config_property):
    context, host_ref, mock_get_service, _, mock_stop_service = setup_config_property
    value = False
    mock_get_service.return_value.running = True
    mock_stop_service.return_value = True
    assert Slp().set(context, host_ref, value) == True


def test_set_shell_service_not_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="TSM", running=False)]
    host_ref.configManager.serviceSystem = host_service
    assert Shell().set(context, host_ref, value) == True


def test_set_shell_service_already_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="TSM", running=True)]
    host_ref.configManager.serviceSystem = host_service
    assert Shell().set(context, host_ref, value) == True


def test_set_slp_service_not_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="slpd", running=False)]
    host_ref.configManager.serviceSystem = host_service
    assert Slp().set(context, host_ref, value) == True


def test_set_slp_service_already_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="slpd", running=True)]
    host_ref.configManager.serviceSystem = host_service
    assert Slp().set(context, host_ref, value) == True


def test_set_snmp_service_not_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="snmpd", running=False)]
    host_ref.configManager.serviceSystem = host_service
    assert Snmp().set(context, host_ref, value) == True


def test_set_snmp_service_already_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="snmpd", running=True)]
    host_ref.configManager.serviceSystem = host_service
    assert Snmp().set(context, host_ref, value) == True


def test_set_ssh_service_not_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="TSM-SSH", running=False)]
    host_ref.configManager.serviceSystem = host_service
    assert Ssh().set(context, host_ref, value) == True


def test_set_ssh_service_already_running(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = True
    host_service = MagicMock()
    host_service.serviceInfo.service = [MagicMock(key="TSM-SSH", running=True)]
    host_ref.configManager.serviceSystem = host_service
    assert Ssh().set(context, host_ref, value) == True


def test_set_lockdown_mode_valid(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = "normal"  # A valid Lockdown Mode
    assert LockdownMode().set(context, host_ref, value) == True


def test_set_lockdown_mode_invalid(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = "invalid_mode"  # An invalid Lockdown Mode
    assert LockdownMode().set(context, host_ref, value) == False


def test_set_lockdown_exception_users_valid(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = ["user1", "user2"]  # Valid list of users
    assert LockdownExceptionUsers().set(context, host_ref, value) == True


def test_set_lockdown_exception_users_invalid(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = "user"  # Invalid value, not a list
    assert LockdownExceptionUsers().set(context, host_ref, value) == False


def test_set_lockdown_exception_users_exception(setup_config_property):
    context, host_ref, _, _, _ = setup_config_property
    value = ["user1", "user2"]
    access_manager = MagicMock()
    access_manager.UpdateLockdownExceptions.side_effect = Exception("Error updating exceptions")
    host_ref.configManager.hostAccessManager = access_manager
    assert LockdownExceptionUsers().set(context, host_ref, value) == False

class EsxiServiceConfigMock:
    def __init__(self, dict) -> None:
        self.key = dict.get("key")
        self.running = dict.get("running")
    
class TestExtendedConfig(unittest.TestCase):

    def setUp(self) -> None:
        self.context = MagicMock()

    def test_get_cim_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "cim_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Cim",
                    }
        expected_config = { "cim_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_cim(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "sfcbd-watchdog", "running": True})]
        config_mapping = {
          "cim_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Cim",
                    }
        expected_config = { "cim_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_shell_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "shell_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Shell",
                    }
        expected_config = { "shell_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_shell(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "TSM", "running": True})]
        config_mapping = {
          "shell_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Shell",
                    }
        expected_config = { "shell_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_slp_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "slp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Slp",
                    }
        expected_config = { "slp_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_slp(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "slpd", "running": True})]
        config_mapping = {
          "slp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Slp",
                    }
        expected_config = { "slp_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_snmp_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "snmp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Snmp",
                    }
        expected_config = { "snmp_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_snmp(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "snmpd", "running": True})]
        config_mapping = {
          "snmp_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Snmp",
                    }
        expected_config = { "snmp_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_ssh_not_found(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = []
        config_mapping = {
          "ssh_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Ssh",
                    }
        expected_config = { "ssh_service_enabled": None}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_ssh(self):
        host_ref = MagicMock()
        host_ref.configManager.serviceSystem.serviceInfo.service = [EsxiServiceConfigMock({"key": "TSM-SSH", "running": True})]
        config_mapping = {
          "ssh_service_enabled": "config_modules_vmware.esxi.config_submodules.extended_config.Ssh",
                    }
        expected_config = { "ssh_service_enabled": True}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_lockdown_exception_users(self):
        host_ref = MagicMock()
        exceptions = ["user1", "user2"]
        host_ref.configManager.hostAccessManager.QueryLockdownExceptions = MagicMock(return_value=exceptions)
        config_mapping = {
          "lockdown_exception_users": "config_modules_vmware.esxi.config_submodules.extended_config.LockdownExceptionUsers",
                    }
        expected_config = { "lockdown_exception_users": exceptions}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_lockdown_mode_disabled(self):
        host_ref = MagicMock()
        host_ref.config.lockdownMode = "lockdownDisabled"
        config_mapping = {
          "lockdown_mode": "config_modules_vmware.esxi.config_submodules.extended_config.LockdownMode",
                    }
        expected_config = { "lockdown_mode": "disabled"}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config

    def test_get_lockdown_mode_normal(self):
        host_ref = MagicMock()
        host_ref.config.lockdownMode = "lockdownNormal"
        config_mapping = {
          "lockdown_mode": "config_modules_vmware.esxi.config_submodules.extended_config.LockdownMode",
                    }
        expected_config = { "lockdown_mode": "normal"}
        config = ConfigManipulation.operate(self.context, host_ref, config_mapping, Operations.GET)
        assert config == expected_config
