# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import pytest

from config_modules_vmware.utils.config_manipulation import ConfigManipulation
from config_modules_vmware.esxi.esx_config_utility import EsxConfigUtility

sample_desired_spec = {
    "extended_config": {
        "profile": {
            "esx": {
                "services": {
                    "ssh_service_enabled": True,
                    "cim_service_enabled": True
                }
            }
        },
        "metadata": {
            "reference_host": {
                "uuid": "4201486f-384a-62f4-07f2-952b5e9f28c2",
                "build": "Releasebuild-22380479",
                "patch": "0",
                "update": "2",
                "version": "8.0.2"
            },
        },
        "host-override": {
            "42010911-6d01-49ea-54f7-f8cccfba768c": {
                "esx": {
                    "services": {
                        "ssh_service_enabled": False,
                        "cim_service_enabled": True,
                    },
                },
            },
            "42019fb9-936f-85aa-241f-20119d3410bb": {
                "esx": {
                    "services": {
                        "ssh_service_enabled": True,
                    },
                },
            },
        },
    },
}

sample_host_config = {
    "extended_config": {
        "profile": {
            "esx": {
                "services": {
                    "ssh_service_enabled": True,
                    "cim_service_enabled": True,
                },
            },
        },
    },
}

class TestEsxConfigUtility:
    def test_flatten_config_by_host(self):
        flattened_config = EsxConfigUtility.flatten_config_by_host(sample_desired_spec)
        assert isinstance(flattened_config, dict)
        assert len(flattened_config) == 3

        for uuid, profile_data in flattened_config.items():
            assert "profile" in profile_data
            assert "esx" in profile_data["profile"]
            esx_profile = profile_data["profile"]["esx"]
            assert "services" in esx_profile
            assert "ssh_service_enabled" in esx_profile["services"]
            assert "cim_service_enabled" in esx_profile["services"]

    def test_merge_config(self):
        reference_config_template = ConfigManipulation.get_config_mapping_template()
        merged_config = EsxConfigUtility.merge_config(reference_config_template, sample_host_config)

        extended_merged_config = merged_config["extended_config"]
        assert "profile" in extended_merged_config
        assert "esx" in extended_merged_config["profile"]

        esx_profile = merged_config["extended_config"]["profile"]["esx"]
        assert "services" in esx_profile
        assert "ssh_service_enabled" in esx_profile["services"]
        assert "cim_service_enabled" in esx_profile["services"]

    def test_create_config_mapping(self):
        config_mapping = EsxConfigUtility.create_config_mapping(sample_host_config)
        extended_config_mapping = config_mapping["extended_config"]
        assert "profile" in extended_config_mapping
        assert "esx" in extended_config_mapping["profile"]

        esx_profile = extended_config_mapping["profile"]["esx"]
        assert "services" in esx_profile
        assert "ssh_service_enabled" in esx_profile["services"]
        assert "cim_service_enabled" in esx_profile["services"]
