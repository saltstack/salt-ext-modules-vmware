import unittest
from config_modules_vmware.esxi.utils.formatters.formatters import Formatters

import uuid


class VlcmFormatterTest(unittest.TestCase):
    def setUp(self) -> None:
        self.hosts = {
            "0a0d1544-2822-4108-86a2-4ffdeaf92b70": {
                "config": {
                    "profile": {
                        "esx": {
                            "network": {
                                "net_stacks": [
                                    {
                                        "key": "ops",
                                        "name": "null"
                                    },
                                    {
                                        "key": "mirror",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vSphereProvisioning",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vmotion",
                                        "name": "null"
                                    },
                                    {
                                        "key": "defaultTcpipStack",
                                        "name": "defaultTcpipStack"
                                    }
                                ],
                                "vmknics": [
                                    {
                                        "ip": {
                                            "dhcp": "true",
                                            "ipv6": {
                                                "dhcp": "false",
                                                "dhcp_dns": "null",
                                                "ipv6_address": [
                                                    {
                                                        "address": "fe80::bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd05:0:106:204:0:bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:a:0:b76",
                                                        "prefix_length": 64
                                                    }
                                                ],
                                                "auto_configuration_enabled": "true"
                                            },
                                            "dhcp_dns": "null",
                                            "ipv4_address": "10.182.189.145",
                                            "ipv6_enabled": "true",
                                            "ipv4_subnet_mask": "255.255.240.0"
                                        },
                                        "mtu": 1500,
                                        "nic": "null",
                                        "device": "vmk0",
                                        "enabled": "null",
                                        "mac_mode": "null",
                                        "port_group": "Management Network",
                                        "enabled_services": "null",
                                        "port_connection_type": "null",
                                        "net_stack_instance_key": "defaultTcpipStack"
                                    }
                                ]
                            }
                        }
                    }
                },
                "extended_config": {
                    "profile": {
                        "esx": {
                            "system": {
                                "keyboard": {
                                    "layout": "US Default"
                                }
                            },
                            "advanced_options": {
                                "user_vars": [
                                    {
                                        "option_name": "ESXiShellTimeOut",
                                        "integer_value": 0
                                    }
                                ],
                                "VVOL": {
                                    "vvol_lazy_unbind_timeout": 60
                                },
                                "net": {
                                    "follow_hardware_mac": 1
                                },
                                "mem": {
                                    "VM_overhead_growth_limit": 0
                                }
                            }
                        }
                    }
                }
            },
            "0b4d2629-bd01-4988-9a70-7d4325fdacb3": {
                "config": {
                    "profile": {
                        "esx": {
                            "network": {
                                "net_stacks": [
                                    {
                                        "key": "ops",
                                        "name": "null"
                                    },
                                    {
                                        "key": "mirror",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vSphereProvisioning",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vmotion",
                                        "name": "helloWorld"
                                    },
                                    {
                                        "key": "defaultTcpipStack",
                                        "name": "defaultTcpipStack"
                                    }
                                ],
                                "vmknics": [
                                    {
                                        "ip": {
                                            "dhcp": "true",
                                            "ipv6": {
                                                "dhcp": "false",
                                                "dhcp_dns": "null",
                                                "ipv6_address": [
                                                    {
                                                        "address": "fe90::bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:a:0:b76",
                                                        "prefix_length": 64
                                                    }
                                                ],
                                                "auto_configuration_enabled": "true"
                                            },
                                            "dhcp_dns": "null",
                                            "ipv4_address": "10.182.189.145",
                                            "ipv6_enabled": "true",
                                            "ipv4_subnet_mask": "255.255.240.0"
                                        },
                                        "mtu": 1500,
                                        "nic": "null",
                                        "device": "vmk0",
                                        "enabled": "null",
                                        "mac_mode": "null",
                                        "port_group": "Management Network",
                                        "enabled_services": "null",
                                        "port_connection_type": "null",
                                        "net_stack_instance_key": "defaultTcpipStack"
                                    }
                                ]
                            }
                        }
                    }
                },
                "extended_config": {
                    "profile": {
                        "esx": {
                            "system": {
                                "keyboard": {
                                    "layout": "MX Default"
                                }
                            },
                            "advanced_options": {
                                "user_vars": [
                                    {
                                        "option_name": "ESXiShellTimeOut",
                                        "integer_value": 0
                                    }
                                ],
                                "VVOL": {
                                    "vvol_lazy_unbind_timeout": 60
                                },
                                "net": {
                                    "follow_hardware_mac": 1
                                },
                                "mem": {
                                    "VM_overhead_growth_limit": 0
                                }
                            }
                        }
                    }
                }
            },
            "3a45346c-cab1-462c-ad9d-65c5fd9b1ea1": {
                "config": {
                    "profile": {
                        "esx": {
                            "network": {
                                "net_stacks": [
                                    {
                                        "key": "ops",
                                        "name": "null"
                                    },
                                    {
                                        "key": "mirror",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vSphereProvisioning",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vmotion",
                                        "name": "null"
                                    },
                                    {
                                        "key": "defaultTcpipStack",
                                        "name": "defaultTcpipStack"
                                    }
                                ],
                                "vmknics": [
                                    {
                                        "ip": {
                                            "dhcp": "true",
                                            "ipv6": {
                                                "dhcp": "false",
                                                "dhcp_dns": "null",
                                                "ipv6_address": [
                                                    {
                                                        "address": "fe80::bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:a:0:b76",
                                                        "prefix_length": 64
                                                    }
                                                ],
                                                "auto_configuration_enabled": "true"
                                            },
                                            "dhcp_dns": "null",
                                            "ipv4_address": "10.182.189.145",
                                            "ipv6_enabled": "true",
                                            "ipv4_subnet_mask": "255.255.240.0"
                                        },
                                        "mtu": 1500,
                                        "nic": "null",
                                        "device": "vmk0",
                                        "enabled": "null",
                                        "mac_mode": "null",
                                        "port_group": "Management Network",
                                        "enabled_services": "null",
                                        "port_connection_type": "null",
                                        "net_stack_instance_key": "defaultTcpipStack"
                                    }
                                ]
                            }
                        }
                    }
                },
                "extended_config": {
                    "profile": {
                        "esx": {
                            "system": {
                                "keyboard": {
                                    "layout": "US Default"
                                }
                            },
                            "advanced_options": {
                                "user_vars": [
                                    {
                                        "option_name": "ESXiShellTimeOut",
                                        "integer_value": 0
                                    }
                                ],
                                "VVOL": {
                                    "vvol_lazy_unbind_timeout": 60
                                },
                                "net": {
                                    "follow_hardware_mac": 4
                                },
                                "mem": {
                                    "VM_overhead_growth_limit": 0
                                }
                            }
                        }
                    }
                }
            }
        }
        self.vlcm_expected_format = {
            "config": {
                "host-override": {
                    "0b4d2629-bd01-4988-9a70-7d4325fdacb3": {
                        "esx": {
                            "network": {
                                "net_stacks": [
                                    {
                                        "key": "ops",
                                        "name": "null"
                                    },
                                    {
                                        "key": "mirror",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vSphereProvisioning",
                                        "name": "null"
                                    },
                                    {
                                        "key": "vmotion",
                                        "name": "helloWorld"
                                    },
                                    {
                                        "key": "defaultTcpipStack",
                                        "name": "defaultTcpipStack"
                                    }
                                ],
                                "vmknics": [
                                    {
                                        "device": "vmk0",
                                        "enabled": "null",
                                        "enabled_services": "null",
                                        "ip": {
                                            "dhcp": "true",
                                            "dhcp_dns": "null",
                                            "ipv4_address": "10.182.189.145",
                                            "ipv4_subnet_mask": "255.255.240.0",
                                            "ipv6": {
                                                "auto_configuration_enabled": "true",
                                                "dhcp": "false",
                                                "dhcp_dns": "null",
                                                "ipv6_address": [
                                                    {
                                                        "address": "fe90::bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:a:0:b76",
                                                        "prefix_length": 64
                                                    }
                                                ]
                                            },
                                            "ipv6_enabled": "true"
                                        },
                                        "mac_mode": "null",
                                        "mtu": 1500,
                                        "net_stack_instance_key": "defaultTcpipStack",
                                        "nic": "null",
                                        "port_connection_type": "null",
                                        "port_group": "Management Network"
                                    }
                                ]
                            }
                        }
                    },
                    "3a45346c-cab1-462c-ad9d-65c5fd9b1ea1": {
                        "esx": {
                            "network": {
                                "vmknics": [
                                    {
                                        "device": "vmk0",
                                        "enabled": "null",
                                        "enabled_services": "null",
                                        "ip": {
                                            "dhcp": "true",
                                            "dhcp_dns": "null",
                                            "ipv4_address": "10.182.189.145",
                                            "ipv4_subnet_mask": "255.255.240.0",
                                            "ipv6": {
                                                "auto_configuration_enabled": "true",
                                                "dhcp": "false",
                                                "dhcp_dns": "null",
                                                "ipv6_address": [
                                                    {
                                                        "address": "fe80::bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:bff:fe9c:efce",
                                                        "prefix_length": 64
                                                    },
                                                    {
                                                        "address": "fd01:0:106:204:0:a:0:b76",
                                                        "prefix_length": 64
                                                    }
                                                ]
                                            },
                                            "ipv6_enabled": "true"
                                        },
                                        "mac_mode": "null",
                                        "mtu": 1500,
                                        "net_stack_instance_key": "defaultTcpipStack",
                                        "nic": "null",
                                        "port_connection_type": "null",
                                        "port_group": "Management Network"
                                    }
                                ],
                            }
                        }
                    }
                },
                "metadata": {
                    "reference_host": {
                        "uuid": "0a0d1544-2822-4108-86a2-4ffdeaf92b70"
                    }
                },
                "profile": {
                    "esx": {
                        "network": {
                            "net_stacks": [
                                {
                                    "key": "ops",
                                    "name": "null"
                                },
                                {
                                    "key": "mirror",
                                    "name": "null"
                                },
                                {
                                    "key": "vSphereProvisioning",
                                    "name": "null"
                                },
                                {
                                    "key": "vmotion",
                                    "name": "null"
                                },
                                {
                                    "key": "defaultTcpipStack",
                                    "name": "defaultTcpipStack"
                                }
                            ],
                            "vmknics": [
                                {
                                    "device": "vmk0",
                                    "enabled": "null",
                                    "enabled_services": "null",
                                    "ip": {
                                        "dhcp": "true",
                                        "dhcp_dns": "null",
                                        "ipv4_address": "10.182.189.145",
                                        "ipv4_subnet_mask": "255.255.240.0",
                                        "ipv6": {
                                            "auto_configuration_enabled": "true",
                                            "dhcp": "false",
                                            "dhcp_dns": "null",
                                            "ipv6_address": [
                                                {
                                                    "address": "fe80::bff:fe9c:efce",
                                                    "prefix_length": 64
                                                },
                                                {
                                                    "address": "fd05:0:106:204:0:bff:fe9c:efce",
                                                    "prefix_length": 64
                                                },
                                                {
                                                    "address": "fd01:0:106:204:0:a:0:b76",
                                                    "prefix_length": 64
                                                }
                                            ]
                                        },
                                        "ipv6_enabled": "true"
                                    },
                                    "mac_mode": "null",
                                    "mtu": 1500,
                                    "net_stack_instance_key": "defaultTcpipStack",
                                    "nic": "null",
                                    "port_connection_type": "null",
                                    "port_group": "Management Network"
                                }
                            ]
                        }
                    }
                }
            },
            "extended_config": {
                "host-override": {
                    "0b4d2629-bd01-4988-9a70-7d4325fdacb3": {
                        "esx": {
                            "system": {
                                "keyboard": {
                                    "layout": "MX Default"
                                }
                            }
                        }
                    },
                    "3a45346c-cab1-462c-ad9d-65c5fd9b1ea1": {
                        "esx": {
                            "advanced_options": {
                                "net": {
                                    "follow_hardware_mac": 4
                                }
                            }
                        }
                    }
                },
                "metadata": {
                    'reference_host': {
                        'uuid': '0a0d1544-2822-4108-86a2-4ffdeaf92b70'
                    }
                },
                "profile": {
                    "esx": {
                        "advanced_options": {
                            "VVOL": {
                                "vvol_lazy_unbind_timeout": 60
                            },
                            "mem": {
                                "VM_overhead_growth_limit": 0
                            },
                            "net": {
                                "follow_hardware_mac": 1
                            },
                            "user_vars": [
                                {
                                    "integer_value": 0,
                                    "option_name": "ESXiShellTimeOut"
                                }
                            ]
                        },
                        "system": {
                            "keyboard": {
                                "layout": "US Default"
                            }
                        }
                    }
                }
            }
        }

    def test_vlcm_formatter_no_reference_host(self):
        '''Tests formatter if no reference host is passed'''
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(self.hosts)
        assert vlcm_format == self.vlcm_expected_format

    def test_vlcm_formatter_reference_host(self):
        '''Tests formatter when reference host is passed'''
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(self.hosts,
                                                             reference_host_uuid="0a0d1544-2822-4108-86a2-4ffdeaf92b70")
        assert vlcm_format == self.vlcm_expected_format

    def test_vlcm_formatter_hosts_empty(self):
        '''Tests if formatter raises exception when no hosts are passed'''
        self.assertRaises(Exception, Formatters.VLCM_FORMATTER.value.format, {})

    def test_vlcm_formatter_one_host(self):
        '''Tests formatter when only one hos is passed'''
        one_host = self.hosts.copy()
        del one_host["0b4d2629-bd01-4988-9a70-7d4325fdacb3"]
        del one_host["3a45346c-cab1-462c-ad9d-65c5fd9b1ea1"]
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(one_host)
        expected_output = self.vlcm_expected_format.copy()
        del expected_output['config']['host-override']
        del expected_output['extended_config']['host-override']
        assert vlcm_format == expected_output

    def test_vlcm_formatter_no_overrides(self):
        '''Test formatter when there are no host overrides'''
        identical_hosts = self.hosts.copy()
        for host in identical_hosts:
            identical_hosts[host] = identical_hosts["0a0d1544-2822-4108-86a2-4ffdeaf92b70"]
        expected_output = self.vlcm_expected_format.copy()
        del expected_output['config']['host-override']
        del expected_output['extended_config']['host-override']
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(identical_hosts)
        assert vlcm_format == expected_output

    def test_vlcm_formatter_no_config(self):
        '''Tests formatter when no config is present'''
        hosts_no_config = self.hosts.copy()
        for host in hosts_no_config:
            del hosts_no_config[host]['config']
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(hosts_no_config)
        expected_output = self.vlcm_expected_format.copy()
        del expected_output['config']
        assert vlcm_format == expected_output

    def test_vlcm_formatter_no_extended_config(self):
        '''Tests formatter when no extended_config is present'''
        hosts_no_extended_config = self.hosts.copy()
        for host in hosts_no_extended_config:
            del hosts_no_extended_config[host]['extended_config']
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(hosts_no_extended_config)
        expected_output = self.vlcm_expected_format.copy()
        del expected_output['extended_config']
        assert vlcm_format == expected_output

    def test_vlcm_formatter_comparison_missing_property(self):
        '''Tests formatter when keys on reference host are different from keys in comparison hosts'''
        hosts_different_keys = self.hosts.copy()
        del hosts_different_keys['0b4d2629-bd01-4988-9a70-7d4325fdacb3']['config']['profile']['esx']['network'][
            'vmknics']
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(self.hosts)
        expected_output = self.vlcm_expected_format.copy()
        expected_output['config']['host-override']['0b4d2629-bd01-4988-9a70-7d4325fdacb3']['esx']['network'][
            'vmknics'] = 'DEFAULT'
        assert vlcm_format == self.vlcm_expected_format

    def test_vlcm_formatter_reference_missing_property(self):
        '''Tests formatter when the reference host is missing a property'''
        hosts_different_keys = self.hosts.copy()
        del hosts_different_keys['0a0d1544-2822-4108-86a2-4ffdeaf92b70']['config']['profile']['esx']['network'][
            'vmknics']
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(self.hosts,
                                                             reference_host_uuid="0a0d1544-2822-4108-86a2-4ffdeaf92b70")
        expected_output = self.vlcm_expected_format.copy()
        del expected_output['config']['profile']['esx']['network']['vmknics']
        assert vlcm_format == expected_output

    def test_vlcm_formatter_reference_group_missing(self):
        '''Tests formatter when the reference host is missing a group'''
        hosts_different_keys = self.hosts.copy()
        del hosts_different_keys['0a0d1544-2822-4108-86a2-4ffdeaf92b70']['config']['profile']['esx']['network']
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(self.hosts,
                                                             reference_host_uuid="0a0d1544-2822-4108-86a2-4ffdeaf92b70")
        expected_output = self.vlcm_expected_format.copy()
        expected_output['config']['profile']['esx'] = {}
        expected_output['config']['host-override']['3a45346c-cab1-462c-ad9d-65c5fd9b1ea1']['esx']['network']['net_stacks'] = self.hosts['3a45346c-cab1-462c-ad9d-65c5fd9b1ea1']['config']['profile']['esx']['network']['net_stacks']
        assert vlcm_format == expected_output

    def test_vlcm_formatter_comparison_group_missing(self):
        '''Tests formatter when the comparison host is missing a property group'''
        missing_group = self.hosts.copy()
        del missing_group['3a45346c-cab1-462c-ad9d-65c5fd9b1ea1']['config']['profile']['esx']['network']
        vlcm_format = Formatters.VLCM_FORMATTER.value.format(missing_group)
        expected_output = self.vlcm_expected_format.copy()
        expected_output['config']['host-override']['3a45346c-cab1-462c-ad9d-65c5fd9b1ea1']['esx']['network'] = 'DEFAULT'
        assert vlcm_format == expected_output
