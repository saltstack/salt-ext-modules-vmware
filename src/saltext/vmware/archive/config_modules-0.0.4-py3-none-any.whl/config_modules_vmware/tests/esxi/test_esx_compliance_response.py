# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from unittest.mock import patch, MagicMock
from config_modules_vmware.esxi.ouput_models.esx_compliance_response import EsxComplianceResponse
from config_modules_vmware.lib.common import consts

class TestEsxComplianceResponse:

    def test_update_with_vlcm_response_for_config_section(self):
        """
        Test the update_with_vlcm_response_for_config_section method.
        """
        esx_response = EsxComplianceResponse()

        vlcm_response = {
            consts.RESULT: {
                consts.CLUSTER_STATUS: "COMPLIANT",
                consts.NON_COMPLIANT_HOSTS: ["host-moid-1", "host-moid-2"],
                consts.COMPLIANT_HOSTS: ["host3", "host4"],
                consts.HOST_INFO: [
                    {"key": "host-moid-1", "value": {consts.NAME: "esx-host-1"}},
                    {"key": "host-moid-2", "value": {consts.NAME: "esx-host-2"}},
                ],
                consts.HOSTS: [
                    {"key": "host-moid-1"},
                    {"key": "host-moid-2"},
                ]
            }
        }

        esx_response.update_with_vlcm_response_for_config_section(vlcm_response)

        assert esx_response.reformatted_cluster_response[consts.CLUSTER_STATUS] == "COMPLIANT"
        assert esx_response.reformatted_cluster_response[consts.SUMMARY] == "2 hosts are out of compliance."

    def test_update_host_compliance(self):
        """
        Test the update_host_compliance method.
        """
        esx_response = EsxComplianceResponse()
        host_key = "host-moid-1"
        host_name = "esx-host-1"
        category = "sets"
        differences = {
            "path1": ("current1", "target1"),
            "path2": ("current2", "target2")
        }

        # Mock the update functions for add_to_non_compliant_hosts, update_compliance_summary,
        # and update_cluster_status
        with patch.object(esx_response, 'add_to_non_compliant_hosts'):
            with patch.object(esx_response, 'update_compliance_summary'):
                with patch.object(esx_response, 'update_cluster_status'):
                    esx_response.update_host_compliance(host_key, host_name, category, differences)

        assert host_key in esx_response.reformatted_cluster_response[consts.HOSTS]
        host_data = esx_response.reformatted_cluster_response[consts.HOSTS][host_key]
        assert host_data[consts.NAME] == host_name
        host_compliance = host_data[consts.HOST_COMPLIANCE]
        assert category in host_compliance
        compliance_info = host_compliance[category]
        assert len(compliance_info) == 2
        info1, info2 = compliance_info
        assert info1["path"] == "/path1"
        assert info1["current"] == "current1"
        assert info1["target"] == "target1"
        assert info2["path"] == "/path2"
        assert info2["current"] == "current2"
        assert info2["target"] == "target2"

    def test_update_compliance_summary(self):
        """
        Test the update_compliance_summary method.
        """
        esx_response = EsxComplianceResponse()

        # Mock the required data in reformatted_cluster_response
        esx_response.reformatted_cluster_response = {
            consts.NON_COMPLIANT_HOSTS: ["host-moid-1", "host-moid-2"]
        }

        esx_response.update_compliance_summary()

        assert esx_response.reformatted_cluster_response[consts.SUMMARY] == "2 hosts are out of compliance."

    def test_add_to_non_compliant_hosts(self):
        """
        Test the add_to_non_compliant_hosts method.
        """
        esx_response = EsxComplianceResponse()
        host_key = "host-moid-1"

        # Initialize the reformatted_cluster_response dictionary with the required keys
        esx_response.reformatted_cluster_response = {
            consts.SUMMARY: "",
            consts.CLUSTER_STATUS: "",
            consts.HOSTS: {},
            consts.COMPLIANT_HOSTS: [],
            consts.NON_COMPLIANT_HOSTS: []
        }

        with patch.object(esx_response, 'update_host_status'):
            with patch.object(esx_response, 'update_compliance_summary'):
                esx_response.add_to_non_compliant_hosts(host_key)

        assert host_key in esx_response.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS]

    def test_update_host_status(self):
        """
        Test the update_host_status method.
        """
        esx_response = EsxComplianceResponse()
        host_key = "host-moid-1"
        status = consts.NON_COMPLIANT

        esx_response.reformatted_cluster_response = {
            consts.HOSTS: {
                host_key: {
                    consts.STATUS: consts.COMPLIANT
                }
            }
        }

        esx_response.update_host_status(host_key, status)
        assert esx_response.reformatted_cluster_response[consts.HOSTS][host_key][consts.STATUS] == consts.NON_COMPLIANT

    def test_remove_from_non_compliant_hosts(self):
        """
        Test the remove_from_non_compliant_hosts method.
        """
        esx_response = EsxComplianceResponse()
        host_key = "host-moid-1"

        esx_response.reformatted_cluster_response = {
            consts.NON_COMPLIANT_HOSTS: ["host-moid-1", "host-moid-2"]
        }
        esx_response.remove_from_non_compliant_hosts(host_key)
        assert host_key not in esx_response.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS]

    def test_update_cluster_status(self):
        """
        Test the update_cluster_status method.
        """
        esx_response = EsxComplianceResponse()

        esx_response.reformatted_cluster_response = {
            consts.NON_COMPLIANT_HOSTS: [],
            consts.COMPLIANT_HOSTS: ["host-moid-1", "host-moid-2"],
            consts.HOSTS: {"host-moid-1": {}, "host-moid-2": {}}
        }

        esx_response.update_cluster_status()
        assert esx_response.reformatted_cluster_response[consts.CLUSTER_STATUS] == "COMPLIANT"

        esx_response.reformatted_cluster_response[consts.COMPLIANT_HOSTS] = []
        esx_response.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS] = ["host-moid-1", "host-moid-2"]
        esx_response.update_cluster_status()
        assert esx_response.reformatted_cluster_response[consts.CLUSTER_STATUS] == consts.NON_COMPLIANT

        esx_response.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS] = []
        esx_response.reformatted_cluster_response[consts.COMPLIANT_HOSTS] = ["host-moid-1", "host-moid-2"]
        esx_response.update_cluster_status()
        assert esx_response.reformatted_cluster_response[consts.CLUSTER_STATUS] == consts.COMPLIANT

    def test_get_reformatted_response(self):
        """
        Test the get_reformatted_response method.
        """
        esx_response = EsxComplianceResponse()

        esx_response.reformatted_cluster_response = {
            consts.SUMMARY: "2 hosts are out of compliance.",
            consts.CLUSTER_STATUS: "COMPLIANT",
            consts.HOSTS: {"host-moid-1": {"key": "value"}},
            consts.COMPLIANT_HOSTS: ["host-moid-1"],
            consts.NON_COMPLIANT_HOSTS: []
        }

        response = esx_response.get_reformatted_response()
        assert isinstance(response, dict)