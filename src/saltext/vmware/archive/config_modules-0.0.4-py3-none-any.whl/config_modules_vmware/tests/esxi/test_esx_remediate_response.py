# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from config_modules_vmware.esxi.output_models.esx_remediate_response import EsxRemediateResponse
from config_modules_vmware.lib.common import consts

class TestEsxRemediateResponse:

    def test_update_with_vlcm_response_for_config_section(self):

        remediate_response = EsxRemediateResponse()
        vlcm_response = {
            consts.RESULT: {
                consts.SUCCESSFUL_HOSTS: ["host-moid-1", "host-moid-2"],
                consts.FAILED_HOSTS: [],
                consts.SKIPPED_HOSTS: [],
                consts.HOST_INFO: [
                    {"key": "host-moid-1", "value": {consts.NAME: "esx-host-1"}},
                    {"key": "host-moid-2", "value": {consts.NAME: "esx-host-2"}}
                ],
                consts.HOST_STATUS: [
                    {
                        "key": "host-moid-1",
                        "value": {
                            consts.NOTIFICATIONS: {
                                consts.INFO: [
                                    {consts.MESSAGE: {consts.DEFAULT_MESSAGE: "Notification 1"}},
                                    {consts.MESSAGE: {consts.DEFAULT_MESSAGE: "Notification 2"}}
                                ]
                            }
                        }
                    },
                    {
                        "key": "host-moid-2",
                        "value": {
                            consts.NOTIFICATIONS: {
                                consts.INFO: []
                            }
                        }
                    }
                ]
            }
        }

        remediate_response.update_with_vlcm_response_for_config_section(vlcm_response)

        assert remediate_response.get_reformatted_response() == {
            consts.HOSTS: {
                "host-moid-1": {
                    consts.NAME: "esx-host-1",
                    consts.NOTIFICATION_INFO: ["Notification 1", "Notification 2"]
                },
                "host-moid-2": {
                    consts.NAME: "esx-host-2",
                    consts.NOTIFICATION_INFO:[]
                },
            },
            consts.SUCCESSFUL_HOSTS: ["host-moid-1", "host-moid-2"],
            consts.FAILED_HOSTS: [],
            consts.SKIPPED_HOSTS: []
        }

    def test_update_host_notification_info(self):

        remediate_response = EsxRemediateResponse()
        remediate_response.reformatted_cluster_response = {
            consts.HOSTS: {
                "host-moid-1": {
                    consts.NAME: "esx-host-1"
                }
            },
            consts.SUCCESSFUL_HOSTS: ["host-moid-1"],
            consts.FAILED_HOSTS: [],
            consts.SKIPPED_HOSTS: []
        }

        remediate_response.update_host_notification_info("host-moid-1", "esx-host-1", ["/path/to/config"])
        assert remediate_response.get_reformatted_response() == {
            consts.HOSTS: {
                "host-moid-1": {
                    consts.NAME: "esx-host-1",
                    consts.NOTIFICATION_INFO: [
                        "Configuration Apply task started for extended config on host 'esx-host-1'.",
                        "Configuration path/to/config remediated successfully.",
                        "Configuration Apply task finished for extended config on host 'esx-host-1'."
                    ]
                }
            },
            consts.SUCCESSFUL_HOSTS: ["host-moid-1"],
            consts.FAILED_HOSTS: [],
            consts.SKIPPED_HOSTS: []
        }