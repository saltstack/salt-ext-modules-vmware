# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import unittest
from unittest.mock import MagicMock

from pyVmomi import vim
from pyVmomi.VmomiSupport import Link

from config_modules_vmware.esxi.config_submodules.network_vss_config import NetworkVssConfig


class TestNetworkVssConfig(unittest.TestCase):

    def setUp(self) -> None:
        self.context = MagicMock()
        self.host_ref = MagicMock()
        self.switch_policy = vim.host.NetworkPolicy(
            security=vim.host.NetworkPolicy.SecurityPolicy(
                allowPromiscuous=False,
                macChanges=False,
                forgedTransmits=False
            ),
            nicTeaming=vim.host.NetworkPolicy.NicTeamingPolicy(
                policy='loadbalance_srcid',
                reversePolicy=True,
                notifySwitches=True,
                rollingOrder=False,
                failureCriteria=vim.host.NetworkPolicy.NicFailureCriteria(checkBeacon=False),
                nicOrder=vim.host.NetworkPolicy.NicOrderPolicy(
                    activeNic=['vmnic0']
                )
            ),
            shapingPolicy=vim.host.NetworkPolicy.TrafficShapingPolicy(enabled=False)
        )
        self.host_ref.configManager.networkSystem.networkInfo.portgroup = [
            vim.host.PortGroup(
                key='key-vim.host.PortGroup-VM Network',
                spec=vim.host.PortGroup.Specification(
                    name='VM Network',
                    vlanId=0,
                    policy=self.switch_policy,
                )
            )
        ]
        self.host_ref.configManager.networkSystem.networkInfo.vswitch = [
            vim.host.VirtualSwitch(
                name='vSwitch0',
                key='key',
                numPorts=2170,
                mtu=1500,
                portgroup=[
                    Link('key-vim.host.PortGroup-VM Network')
                ],
                spec=vim.host.VirtualSwitch.Specification(
                    bridge=vim.host.VirtualSwitch.BondBridge(
                        nicDevice=['vmnic0'],
                        linkDiscoveryProtocolConfig=vim.host.LinkDiscoveryProtocolConfig(
                            protocol="cdp",
                            operation="listen"
                        ),
                        beacon=vim.host.VirtualSwitch.BeaconConfig(interval=1)
                    ),
                    policy=self.switch_policy
                ),
            )
        ]
        self.network_config = NetworkVssConfig(self.context)

    def test_get_configuration(self):
        expected_data = {'switches': [{'bridge': {'beacon_interval': 1, 'link_discovery_protocol': {'operation': 'LISTEN', 'protocol': 'CDP'}, 'nics': ['vmnic0']}, 'mtu': 1500, 'name': 'vSwitch0', 'num_ports': 2170, 'policy': {'nic_teaming': {'active_nics': ['vmnic0'], 'link_criteria_beacon': 'IGNORE', 'notify_switches': True, 'policy': 'LOADBALANCE_SRCID', 'rolling_order': False}, 'security': {'allow_promiscuous': False, 'forged_transmits': False, 'mac_changes': False}, 'traffic_shaping': {'enabled': False}}, 'port_groups': [{'name': 'VM Network', 'policy': {'nic_teaming': {'active_nics': ['vmnic0'], 'link_criteria_beacon': 'IGNORE', 'notify_switches': True, 'policy': 'LOADBALANCE_SRCID', 'rolling_order': False}, 'security': {'allow_promiscuous': False, 'forged_transmits': False, 'mac_changes': False}, 'traffic_shaping': {'enabled': False}}, 'vlan_id': 0}]}]}
        data = self.network_config.get_configuration(self.host_ref)
        if data is None:
            self.assertEqual(data, None)
        else:
            self.assertEqual(data.to_dict(), expected_data)

    def test_module_name(self):
        self.assertEqual(self.network_config.module_name(), 'network_vss')
