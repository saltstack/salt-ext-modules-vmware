import unittest
from unittest.mock import MagicMock
from pyVmomi import vim
from config_modules_vmware.esxi.config_model.syslog_config_model import LoggerSettings, Logfilters
from config_modules_vmware.esxi.config_submodules.syslog_config import SyslogConfig
from config_modules_vmware.utils.utils import invoke_advanced_option_query

class TestSyslogConfig(unittest.TestCase):
    def setUp(self):
        self.context = MagicMock()
        self.host_ref = MagicMock()
        self.host_ref.name = "test_host"
        self.syslog_config = SyslogConfig(self.context)
        self.host_ref.configManager.advancedOption.QueryOptions.return_value = [
            vim.option.OptionValue(key='Syslog.global.auditRecord.storageEnable', value=True),
            vim.option.OptionValue(key='Syslog.global.auditRecord.storageCapacity', value=4),
            vim.option.OptionValue(key='Syslog.global.auditRecord.storageDirectory', value='/scratch/auditLog'),
            vim.option.OptionValue(key='Syslog.global.auditRecord.preventRecordDropping', value=True),
            vim.option.OptionValue(key='Syslog.global.certificate.checkCRL', value=False),
            vim.option.OptionValue(key='Syslog.global.certificate.checkSSLCerts', value=True),
            vim.option.OptionValue(key='Syslog.global.certificate.strictX509Compliance', value=False),
            vim.option.OptionValue(key='Syslog.global.defaultRotate', value=9),
            vim.option.OptionValue(key='Syslog.global.defaultSize', value=1036),
            vim.option.OptionValue(key='Syslog.global.droppedMsgs.fileRotate', value=10),
            vim.option.OptionValue(key='Syslog.global.droppedMsgs.fileSize', value=100),
            vim.option.OptionValue(key='Syslog.global.logCheckSSLCerts', value=True),
            vim.option.OptionValue(key='Syslog.global.logDir', value='/scratch/log'),
            vim.option.OptionValue(key='Syslog.global.logDirUnique', value=False),
            vim.option.OptionValue(key='Syslog.global.logFilters', value='10 | Hostd | mark||20 | Hostd | mark2'),
            vim.option.OptionValue(key='Syslog.global.logFiltersEnable', value=False),
            vim.option.OptionValue(key='Syslog.global.logHost', value=
                'udp://company.com:514?formatter=RFC_5424&framing=octet_counting,'
                'udp://127.0.0.1:1530,tcp://127.0.0.1:12345, tcp://[2001:db8:85a3:8d3:1319:8a2e:370:7348]:54321'),
            vim.option.OptionValue(key='Syslog.global.logLevel', value='error'),
            vim.option.OptionValue(key='Syslog.global.msgQueueDropMark', value=90),
            vim.option.OptionValue(key='Syslog.global.remoteHost.connectRetryDelay', value=180),
            vim.option.OptionValue(key='Syslog.global.remoteHost.maxMsgLen', value=1024),
            vim.option.OptionValue(key='Syslog.global.vsanBacking', value=False)]
        self.mock_esxcli_client = self.context.esxcli_client.return_value
        self.mock_esxcli_client.host.return_value.namespace.return_value.command.return_value.execute.return_value =\
            [{'Description': 'Moves LogEFI variables from EFI to disk', 'Destination': 'LogEFI.log', 'ID': 'LogEFI',
              'RotationSize': '1036', 'Rotations': '9', '': ''},
             {'Description': 'X.Org Xserver', 'Destination': 'Xorg.log', 'ID': 'Xorg', 'RotationSize': '1036',
              'Rotations': '9', '': ''}]

    def test_get_audit_record_config(self):
        syslog_response = invoke_advanced_option_query(self.host_ref, prefix='Syslog.global')
        syslog_response_dict = self.syslog_config._convert_dict(syslog_response)
        audit_record_config = self.syslog_config._get_audit_record_config(self.host_ref, syslog_response_dict)
        expected_audit_record_config = {
            'enable_local_audit_record_storage': True,
            'prevent_record_dropping': True,
            'local_storage_dir': '/scratch/auditLog',
            'local_storage_dir_capacity': 4
        }
        self.assertEqual(expected_audit_record_config, audit_record_config.to_dict())

    def test_get_logger_config(self):
        logger_config = self.syslog_config._get_logger_config(self.host_ref)
        logger_config[0] = logger_config[0].to_dict()
        logger_config[1] = logger_config[1].to_dict()

        expected_logger_config = [
            LoggerSettings(
                description="Moves LogEFI variables from EFI to disk",
                identifications="LogEFI",
                logger="LogEFI",
                log_file_name="LogEFI.log",
                rotation_size_in_kb=1036,
                rotations=9).to_dict(),
            LoggerSettings(
                description="X.Org Xserver",
                identifications="Xorg",
                logger="Xorg",
                log_file_name="Xorg.log",
                rotation_size_in_kb=1036,
                rotations=9).to_dict()]
        self.assertEqual(expected_logger_config, logger_config)

    def test_get_logger_filter_config(self):
        syslog_response = invoke_advanced_option_query(self.host_ref, prefix='Syslog.global')
        syslog_response_dict = self.syslog_config._convert_dict(syslog_response)
        logger_filter_config = self.syslog_config._get_logger_filter_config(self.host_ref, syslog_response_dict)
        expected_logger_filter_config = Logfilters(enable_logfilters=False, filters=[
            '10 | Hostd | mark', '20 | Hostd | mark2'])
        self.assertEqual(expected_logger_filter_config.to_dict(), logger_filter_config.to_dict())

    def test_get_global_config(self):
        syslog_response = invoke_advanced_option_query(self.host_ref, prefix='Syslog.global')
        syslog_response_dict = self.syslog_config._convert_dict(syslog_response)
        global_config = self.syslog_config._get_global_config(self.host_ref, syslog_response_dict).to_dict()

        expected_global_config = {
            'drop_log_rotate': 10,  'drop_log_size': 100,  'log_dir': '/scratch/log', 'log_dir_unique': False,
            'log_level': 'ERROR', 'queue_drop_mark': 90, 'remote_host_max_msg_len': 1024,
            'remote_logging': {'check_ssl_certs': True, 'crl_check': False, 'log_host': [
                {'address': 'company.com', 'port': 514, 'formatter': 'RFC_5424', 'framing': 'OCTET_COUNTING', 'protocol': 'UDP'},
                {'address': '127.0.0.1', 'port': 1530, 'formatter': 'RFC_3164', 'framing': 'NOT_SPECIFIED',
                 'protocol': 'UDP'},
                {'address': '127.0.0.1', 'port': 12345, 'formatter': 'RFC_3164', 'framing': 'NOT_SPECIFIED',
                 'protocol': 'TCP'},
                {'address': '2001:db8:85a3:8d3:1319:8a2e:370:7348', 'port': 54321, 'formatter': 'RFC_3164',
                 'framing': 'NOT_SPECIFIED', 'protocol': 'TCP'},
            ],
                'retry_timeout': 180, 'x509_strict': False}, 'rotation_size_in_kb': 1036, 'rotations': 9,
            'vsan_backing': False}

        self.assertEqual(expected_global_config, global_config)

    def test_get_configuration(self):
        mock_esxcli_client = self.context.esxcli_client.return_value
        mock_esxcli_client.host.return_value.namespace.return_value.command.return_value.execute.return_value =\
            [{'Description': 'Moves LogEFI variables from EFI to disk', 'Destination': 'LogEFI.log', 'ID': 'LogEFI',
              'RotationSize': '1036', 'Rotations': '9', '': ''},
             {'Description': 'X.Org Xserver', 'Destination': 'Xorg.log', 'ID': 'Xorg', 'RotationSize': '1036',
              'Rotations': '9', '': ''}]

        syslog_config_json = self.syslog_config.get_configuration(self.host_ref, include_defaults=False)

        expected_syslog_config = \
            {
                "audit_record_settings": {
                    "enable_local_audit_record_storage": True,
                    "local_storage_dir": "/scratch/auditLog",
                    "local_storage_dir_capacity": 4,
                    "prevent_record_dropping": True
                },
                "global_settings": {
                    "drop_log_rotate": 10,
                    "drop_log_size": 100,
                    "log_dir": "/scratch/log",
                    "log_dir_unique": False,
                    "log_level": "ERROR",
                    "queue_drop_mark": 90,
                    "remote_host_max_msg_len": 1024,
                    "remote_logging": {
                        "check_ssl_certs": True,
                        "crl_check": False,
                        "log_host": [
                            {'address': 'company.com', 'port': 514, 'formatter': 'RFC_5424', 'framing':
                                'OCTET_COUNTING', 'protocol': 'UDP'},
                            {'address': '127.0.0.1', 'port': 1530, 'formatter': 'RFC_3164',
                             'framing': 'NOT_SPECIFIED', 'protocol': 'UDP'},
                            {'address': '127.0.0.1', 'port': 12345, 'formatter': 'RFC_3164', 'framing': 'NOT_SPECIFIED',
                             'protocol': 'TCP'},
                            {'address': '2001:db8:85a3:8d3:1319:8a2e:370:7348', 'port': 54321, 'formatter': 'RFC_3164',
                                'framing': 'NOT_SPECIFIED', 'protocol': 'TCP'},
                            ],
                        "retry_timeout": 180,
                        "x509_strict": False
                    },
                    "rotation_size_in_kb": 1036,
                    "rotations": 9,
                    "vsan_backing": False
                },
                "logfilters": {
                    "enable_logfilters": False,
                    "filters": [
                        "10 | Hostd | mark",
                        "20 | Hostd | mark2"
                    ]
                },
                "logger_settings": [
                    {
                        "description": "Moves LogEFI variables from EFI to disk",
                        "identifications": "LogEFI",
                        "log_file_name": "LogEFI.log",
                        "logger": "LogEFI",
                        "rotation_size_in_kb": 1036,
                        "rotations": 9
                    },
                    {
                        "description": "X.Org Xserver",
                        "identifications": "Xorg",
                        "log_file_name": "Xorg.log",
                        "logger": "Xorg",
                        "rotation_size_in_kb": 1036,
                        "rotations": 9
                    }
                ]
            }
        if syslog_config_json is not None:
            self.assertEqual(expected_syslog_config, syslog_config_json)