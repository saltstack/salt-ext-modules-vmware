# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import unittest
from unittest.mock import MagicMock
from pyVmomi import vim
from config_modules_vmware.esxi.config_submodules.security_config import SecurityConfig


class TestSecurityConfig(unittest.TestCase):

    def setUp(self) -> None:
        """
        Setup mock
        """
        self.context = MagicMock()
        self.host_ref = MagicMock()
        self.advancedOptions = [vim.option.OptionValue(key="Security.AccountLockFailures", value=0),
                                vim.option.OptionValue(key="Security.AccountUnlockTime", value=900),
                                vim.option.OptionValue(key="Security.DefaultShellAccess", value=True),
                                vim.option.OptionValue(key="Security.PasswordHistory", value=5),
                                vim.option.OptionValue(key="Security.PasswordMaxDays", value=99999),
                                vim.option.OptionValue(key="Security.Ignore", value=-1),
                                vim.option.OptionValue(key="Security.PasswordQualityControl",
                                                       value='retry=3 min=disabled,disabled,disabled,7,7'),
                                vim.option.OptionValue(key="Security.SshSessionLimit", value=50)]

        def query_adv_options(*args):
            return self.advancedOptions

        self.host_ref.configManager.advancedOption.QueryOptions = MagicMock(side_effect=query_adv_options)
        self.security_config = SecurityConfig(self.context)

    def test_get_configuration(self):
        """
        Test case to validate get configuration for security
        """
        expected_data = {'settings': {'account_lock_failures': 0,
                                      'account_unlock_time': 900,
                                      'default_shell_access': True,
                                      'password_history': 5,
                                      'password_max_days': 99999,
                                      'password_quality_control': 'retry=3 '
                                                                  'min=disabled,disabled,disabled,7,7',
                                      'ssh_session_limit': 50}}
        data = self.security_config.get_configuration(self.host_ref)
        if data is None:
            self.assertEqual(data, None)
        else:
            self.assertEqual(data, expected_data)

    def test_module_name(self):
        self.assertEqual(self.security_config.module_name(), 'security')
