# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json
import unittest
from unittest.mock import MagicMock, patch

import mock
from pyVmomi import vim

from config_modules_vmware.esxi.config_submodules.storage_config import StorageConfig
from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.lib.esxcli.esxcli import EsxCli


class TestStorageConfig(unittest.TestCase):

    def setUp(self) -> None:
        self.context = MagicMock(spec=EsxContext)
        self.storage_config = StorageConfig(self.context)
        self.host_ref = MagicMock()
        self.host_ref.config.fileSystemVolume.mountInfo = [
            vim.host.FileSystemMountInfo(
                mountInfo=vim.host.MountInfo(
                    accessMode='readWrite',
                    vmknicName='vmknic_name',
                    vmknicActive=False,
                    numTcpConnections=1
                ),
                volume=vim.host.NasVolume(
                    type='NFS',
                    name='nfs1-1',
                    remotePath='/store1',
                    remoteHostNames=[
                        '10.186.133.30'
                    ]
                )
            ),
            vim.host.FileSystemMountInfo(
                mountInfo=vim.host.MountInfo(
                    accessMode='readWrite',
                    vmknicName='vmknic_name',
                    vmknicActive=False,
                    numTcpConnections=1
                ),
                volume=vim.host.NasVolume(
                    type='NFS41',
                    name='nfs0-1',
                    remotePath='/store1',
                    remoteHostNames=[
                        '10.186.136.213'
                    ],
                    securityType='AUTH_SYS'
                )
            ),
        ]

    @patch.object(EsxContext, "esxcli_client")
    @patch.object(EsxCli, "execute")
    def test_get_configuration(self, mock_context, mock_esx_cli):
        """
        Test case to validate get configuration for storage
        """
        mock_esx_cli = EsxCli()
        mock_esx_cli.installed = True
        mock_esx_cli.execute.return_value = json.loads('[{"MaxQueueDepth": "4294967295"}]')
        mock_context.esxcli_client.return_value = mock_esx_cli
        self.storage_config = StorageConfig(mock_context)
        expected_data = {'nfs_v3_datastores': [{'bind_to_vmknic': False, 'connections': 1, 'hostname': '10.186.133.30', 'maxq_depth': 4294967295, 'read_only': False, 'remote_share': '/store1', 'vmknic_name': 'vmknic_name', 'volume_name': 'nfs1-1'}], 'nfs_v41_datastores': [{'auth_type': 'AUTH_SYS', 'hostnames': ['10.186.136.213'], 'maxq_depth': 4294967295, 'read_only': False, 'remote_share': '/store1', 'volume_name': 'nfs0-1'}]}
        data = self.storage_config.get_configuration(self.host_ref)
        if data is None:
            self.assertEqual(data, None)
        else:
            self.assertEqual(data, expected_data)

    def test_module_name(self):
        self.assertEqual(self.storage_config.module_name(), 'storage')
