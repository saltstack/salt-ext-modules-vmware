# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from copy import deepcopy
import pytest
from unittest.mock import Mock

from config_modules_vmware.esxi.esx_config import EsxConfig
from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.lib.vcenter.vc_vmomi_client import VcVmomiClient
from config_modules_vmware.lib.vcenter.vc_vlcm_client import VcVlcmClient
from config_modules_vmware.esxi.esx_config_modules import EsxConfigModulesEnum


def get_esx_config(sub_config_list=None):
    esx = {
        "network": {},
        "advanced_options": {},
        "network_vss": {},
        "storage": {},
        "storage_iscsi": {},
        "authorization": {},
        "hardware" : {},
        "security": {},
        "graphics": {},
        "syslog": {}
    }
    config = {
        "profile": {
            "esx": {key.name.lower(): None for key in sub_config_list} if sub_config_list else esx
        }
    }
    return config


def get_esx_config_host(moid, name, sub_config_list=None):
    config = {
        "name": name,
        "moid": moid,
        "config": get_esx_config(sub_config_list)
    }
    return config


def get_esx_config_cluster(moid, name, host_info, config=None, extended_config=None):
    cluster = {
        "name": name,
        "moid": moid,
        "host_info": host_info,
        "config": config,
        "extended_config": extended_config
    }
    return cluster


def create_host_info(hosts):
    host_info = {}
    for host in hosts:
        host_info[host[0]] = {'name': host[1], 'moid': host[2]}
    return host_info


def create_config(submodules=None):
    if submodules is None:
        submodules = ['network', 'advanced_options', 'network_vss', 'storage', 'storage_iscsi', 'authorization',
                      'hardware', 'security', 'graphics', 'syslog']
    config = {
      'profile': {
        'esx': {}
      },
      'metadata': {
        'reference_host': {
          'uuid': 'reference-host-uuid'
        }
      }
    }
    for sub_mod in submodules:
        config['profile']['esx'][sub_mod] = {}

    return config


def create_extended_config():
    extended_config = {
        'profile': {
            'esx': {
                'services': {
                    'cim_service_enabled': True,
                    'shell_service_enabled': True,
                    'slp_service_enabled': True,
                    'snmp_service_enabled': True,
                    'ssh_service_enabled': True
                }#,
                # 'security': {
                #     'lockdown_mode': None,
                #     'lockdown_exception_users': [
                #         'user1'
                #     ]
                # }
            }
        },
        'metadata': {
            'reference_host': {
                'uuid': 'reference-host-uuid'
            }
        }
    }
    return extended_config


def mock_vc_vmomi_client():
    def make_service(name):
        service = Mock()
        service.key = name
        service.running = True
        return service

    def make_node(moid, name, uuid=None):
        mock = Mock()
        mock._GetMoId.return_value = moid
        mock.name = name
        cim_service = make_service('sfcbd-watchdog')
        shell_service = make_service('TSM')
        slp_service = make_service('slpd')
        snmp_service = make_service('snmpd')
        ssh_service = make_service('TSM-SSH')
        mock.configManager.serviceSystem.serviceInfo.service = [cim_service, shell_service, slp_service, snmp_service, ssh_service]
        access_manager = Mock()
        access_manager.QueryLockdownExceptions.return_value = ['user1']
        mock.configManager.hostAccessManager = access_manager
        mock.hardware.systemInfo.uuid = uuid
        return mock

    hosts = {
        "host-1": make_node("host-1", "Host-1", 'reference-host-uuid'),
        "host-2": make_node("host-2", "Host-2", 'host-2-uuid'),
        "host-3": make_node("host-3", "Host-3", 'reference-host-uuid'),
        "host-4": make_node("host-4", "Host-4", 'host-4-uuid'),
        "host-5": make_node("host-5", "Host-5", 'host-5-uuid'),
    }

    clusters = {
        "domain-c1": (make_node("domain-c1", "Cluster-1"), [hosts["host-1"], hosts["host-2"]]),
        "domain-c2": (make_node("domain-c2", "Cluster-2"), [hosts["host-3"], hosts["host-4"]])
    }

    cluster_path_moid_mapping = {
        'cluster-1-path': 'domain-c1',
        'cluster-2-path': 'domain-c2',
    }

    def mock_get_all_hosts_from_parent(cluster_ref):
        moid = cluster_ref._GetMoId()
        return clusters[moid][1]

    def mock_get_cluster_ref_for_moid(cluster_moid):
        return clusters[cluster_moid][0]

    def mock_get_host_ref_for_moid(host_moid):
        return hosts[host_moid]

    def mock_is_standalone_host(host_ref):
        return host_ref._GetMoId() in ["host-5"]

    def mock_get_cluster_for_host(host_ref):
        if host_ref._GetMoId() in ["host-1", "host-2"]:
            return clusters["domain-c1"][0]
        elif host_ref._GetMoId() in ["host-3", "host-4"]:
            return clusters["domain-c2"][0]

    mock = Mock(spec=VcVmomiClient)
    mock.get_all_clusters.return_value = [val[0] for _, val in clusters.items()]
    mock.get_all_standalone_esx_hosts_from_vc.return_value = [hosts["host-5"]]
    mock.get_all_hosts_from_parent.side_effect = mock_get_all_hosts_from_parent
    mock.get_cluster_ref_for_moid.side_effect = mock_get_cluster_ref_for_moid
    mock.is_standalone_host.side_effect = mock_is_standalone_host
    mock.get_host_ref_for_moid.side_effect = mock_get_host_ref_for_moid
    mock.get_cluster_for_host.side_effect = mock_get_cluster_for_host
    mock.retrieve_cluster_path_moid_mapping.return_value = cluster_path_moid_mapping
    return mock


def mock_vc_vlcm_client():
    def mock_extract_host_current_config(host_moid):
        config = {
            "profile": {
                "esx": {
                    "network": {},
                    "advanced_options": {},
                    "network_vss": {},
                    "storage": {},
                    "storage_iscsi": {},
                    "authorization": {},
                    "hardware" : {},
                    "security" : {},
                    "graphics": {},
                    "syslog": {}
                }
            }
        }
        return config

    def mock_export_desired_state_cluster_configuration(cluster_moid):
        desired_spec = deepcopy(sample_desired_spec)
        return desired_spec

    def mock_check_compliance_cluster_configuration(cluster_moid):
        compliance_response = deepcopy(sample_compliance_response)
        return compliance_response

    mock = Mock(spec=VcVlcmClient)
    mock.extract_host_current_config.side_effect = mock_extract_host_current_config
    mock.export_desired_state_cluster_configuration = mock_export_desired_state_cluster_configuration
    mock.check_compliance_cluster_configuration = mock_check_compliance_cluster_configuration
    mock.is_vlcm_config_manager_enabled_on_cluster.return_value = True
    mock.is_vlcm_config_manager_supported_in_vcsa.return_value = True
    mock.extract_cluster_desired_state_config.return_value = {'metadata': {'reference_host': {'uuid': 'reference-host-uuid'}}}
    return mock


def mock_esx_config_module_get_configuration(host_ref, include_defaults=True):
    return None


expected_esx_config_response_1 = {
    "cluster-1-path": get_esx_config_cluster("domain-c1", "Cluster-1",
                                             create_host_info([("reference-host-uuid", "Host-1", "host-1"),
                                                               ("host-2-uuid", "Host-2", "host-2")]),
                                             create_config(),
                                             create_extended_config()),
    "cluster-2-path": get_esx_config_cluster("domain-c2", "Cluster-2",
                                             create_host_info([("reference-host-uuid", "Host-3", "host-3"),
                                                               ("host-4-uuid", "Host-4", "host-4")]),
                                             create_config(),
                                             create_extended_config())
}

expected_esx_config_response_2 = {
    "cluster-1-path": get_esx_config_cluster("domain-c1", "Cluster-1",
                                             create_host_info([("reference-host-uuid", "Host-1", "host-1"),
                                                               ("host-2-uuid", "Host-2", "host-2")]),
                                             create_config(['advanced_options']),
                                             create_extended_config())
}

expected_esx_config_response_3 = {
    "cluster-1-path": get_esx_config_cluster("domain-c1", "Cluster-1",
                                             create_host_info([("reference-host-uuid", "Host-1", "host-1"),
                                                               ("host-2-uuid", "Host-2", "host-2")]),
                                             create_config(),
                                             create_extended_config()),
    "cluster-2-path": get_esx_config_cluster("domain-c2", "Cluster-2",
                                             create_host_info([("reference-host-uuid", "Host-3", "host-3")]),
                                             create_config(),
                                             create_extended_config())
}


@pytest.mark.patch_classes(class_paths={
    "config_modules_vmware.esxi.esx_context.VcVlcmClient": mock_vc_vlcm_client(),
    "config_modules_vmware.esxi.esx_context.VcVmomiClient": mock_vc_vmomi_client(),
})
@pytest.mark.patch_functions(function_paths={
    "config_modules_vmware.esxi.config_submodules.advanced_options_config.AdvancedOptionsConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.network_config.NetworkConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.network_vss_config.NetworkVssConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.storage_config.StorageConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.storage_iscsi_config.StorageIscsiConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.authorization_config.AuthorizationConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.hardware_config.HardwareConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.security_config.SecurityConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.graphics_config.GraphicsConfig.get_configuration":
        mock_esx_config_module_get_configuration,
    "config_modules_vmware.esxi.config_submodules.syslog_config.SyslogConfig.get_configuration":
        mock_esx_config_module_get_configuration
})
@pytest.mark.parametrize(
    "host_moids, cluster_moids, esx_config_modules, raises, expected_res",
    [
        (None, None, None, False, expected_esx_config_response_1),
        (["host-1", "host-2"], ["domain-c1"], [EsxConfigModulesEnum.ADVANCED_OPTIONS], False, expected_esx_config_response_2),
        (["host-3", "host-2", "host-5"], ["domain-c1"], None, False, expected_esx_config_response_3),
        (["host-6"], None, None, True, None)
    ]
)
def test_get_configuration(creds_fixture, host_moids, cluster_moids, esx_config_modules, raises, expected_res):

    esx_context = EsxContext(creds_fixture)
    esx_config = EsxConfig(esx_context)
    if raises:
        with pytest.raises(Exception):
            esx_config.get_configuration(host_moids, cluster_moids, esx_config_modules)
    else:
        esx_config_response = esx_config.get_configuration(host_moids, cluster_moids, esx_config_modules)
        assert expected_res == esx_config_response


sample_desired_spec = {
    "config": {
        "profile": {
            "esx": {
                "network": {
                    'dummy_prop': "dummy_abc"
                }
            }
        },
        "host-specific": {
            "uuid-1": {
                "esx": {}
            }
        },
        "host-override": {
            "uuid-2": {
                "esx": {}
            }
        },
        "metadata": {
            "reference_hosts": {}
        }

    }
}

mismatch_desired_spec = deepcopy(sample_desired_spec)
mismatch_desired_spec["config"]["profile"]["esx"]["network"]['dummy_prop'] = "dummy_xyz"

sample_compliance_response = {
    "status": "SUCCEEDED",
    "result": {
        "cluster_status": "COMPLIANT",
        "failed_hosts": [],
        "compliant_hosts":  [],
        "non_compliant_hosts": [],
        "skipped_hosts": [],
        "hosts": []
    }
}


@pytest.mark.patch_classes(class_paths={
    "config_modules_vmware.esxi.esx_context.VcVlcmClient": mock_vc_vlcm_client()
})
@pytest.mark.parametrize(
    "cluster_moid, desired_state_spec, raises, expected_res",
    [
        ("domain-c1", {}, True, None),
        ("domain-c1", {"abc": {}}, True, None),
        ("domain-c1", {"config": {}}, True, None),
        ("domain-c1", {"config": {"profile": {}}}, True, None),
        ("domain-c1", mismatch_desired_spec, True, None),
        ("domain-c1", sample_desired_spec, False, sample_compliance_response)
    ]
)
def test_get_desired_state_drifts_vlcm_flow(creds_fixture, cluster_moid, desired_state_spec, raises, expected_res):
    esx_context = EsxContext(creds_fixture)
    esx_config = EsxConfig(esx_context)
    if raises:
        with pytest.raises(Exception):
            esx_config.get_desired_state_drifts(cluster_moid, desired_state_spec)
    else:
        esx_config_response = esx_config.get_desired_state_drifts(cluster_moid, desired_state_spec)
        assert expected_res == esx_config_response
