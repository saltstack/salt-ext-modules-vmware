# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from config_modules_vmware.esxi.ouput_models.esx_precheck_response import EsxPrecheckResponse
from config_modules_vmware.lib.common import consts

class TestEsxPrecheckResponse:

    def test_update_with_vlcm_response_for_config_section(self):
        precheck_response = EsxPrecheckResponse()

        vlcm_response = {
            consts.RESULT: {
                consts.SUCCESSFUL_HOSTS: [  # Add this key to the response
                    "host-moid-1",
                    "host-moid-2"
                ],
                consts.FAILED_HOSTS: [],
                consts.SKIPPED_HOSTS: [],
                consts.STATUS: "OK",
                consts.SUMMARY: {
                    'default_message': 'Pre-check completed successfully.'
                },
                consts.HOST_INFO: [
                    {"key": "host-moid-1", "value": {consts.NAME: "esx-host-1"}},
                    {"key": "host-moid-2", "value": {consts.NAME: "esx-host-2"}}
                ],
                consts.HOST_PRECHECK: [
                    {
                        "key": "host-moid-1",
                        "value": {
                            consts.SUMMARY: {consts.DEFAULT_MESSAGE: "esx-host-1 summary message"},
                            consts.IMPACT: {
                                consts.IMPACT: "Impact message",
                                consts.INFO: [{"default_message": "Info 1"}, {"default_message": "Info 2"}]
                            }
                        }
                    },
                    {
                        "key": "host-moid-2",
                        "value": {
                            consts.SUMMARY: {consts.DEFAULT_MESSAGE: "esx-host-2 summary message"}
                        }
                    }
                ]
            }
        }

        precheck_response.update_with_vlcm_response_for_config_section(vlcm_response)
        assert precheck_response.get_reformatted_response() == {
            consts.SUCCESSFUL_HOSTS: [
                "host-moid-1",
                "host-moid-2"
            ],
            consts.STATUS: "OK",
            consts.FAILED_HOSTS: [],
            consts.SKIPPED_HOSTS: [],
            consts.SUMMARY: "Pre-check completed successfully.",
            consts.HOSTS: {
                "host-moid-1": {
                    consts.NAME: "esx-host-1",
                    consts.SUMMARY: "esx-host-1 summary message",
                    consts.IMPACT: "Impact message",
                    consts.IMPACT_INFO: ["Info 1", "Info 2"]
                },
                "host-moid-2": {
                    consts.NAME: "esx-host-2",
                    consts.SUMMARY: "esx-host-2 summary message"
                }
            }
        }

    def test_update_host_summary(self):
        """
        Test the update_host_summary method.
        """
        precheck_response = EsxPrecheckResponse()
        precheck_response.reformatted_cluster_response = {
            consts.SUMMARY: "Pre-check completed successfully.",
            consts.HOSTS: {
                "host-moid-1": {
                    consts.NAME: "esx-host-1",
                    consts.SUMMARY: "esx-host-1 summary message"
                }
            }
        }

        precheck_response.update_host_summary("host-moid-1")
        assert precheck_response.get_reformatted_response() == {
            consts.SUMMARY: "Pre-check completed successfully.",
            consts.HOSTS: {
                "host-moid-1": {
                    consts.NAME: "esx-host-1",
                    consts.SUMMARY: "All pre-checks passed on the host."
                }
            }
        }

    def test_update_host_impact_info(self):
        """
        Test the update_host_impact_info method.
        """
        precheck_response = EsxPrecheckResponse()
        precheck_response.reformatted_cluster_response = {
            consts.SUMMARY: "Pre-check completed successfully.",
            consts.HOSTS: {}
        }
        precheck_response.update_host_impact_info("host-moid-1", "esx-host-1", {"/path/to/config": ("current", "target")})

        assert precheck_response.get_reformatted_response() == {
            consts.SUMMARY: "Pre-check completed successfully.",
            consts.HOSTS: {
                "host-moid-1": {
                    consts.NAME: "esx-host-1",
                    consts.IMPACT_INFO: ["Configuration 'path/to/config' will be updated on the host."],
                    consts.SUMMARY: "All pre-checks passed on the host."
                }
            }
        }