# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import unittest
from unittest.mock import MagicMock

from pyVmomi import vim

from config_modules_vmware.esxi.config_submodules.network_config import NetworkConfig


class TestNetworkConfig(unittest.TestCase):

    def setUp(self) -> None:
        self.context = MagicMock()
        self.host_ref = MagicMock()
        self.vmknics_ref = [
            vim.host.VirtualNic(
                spec=vim.host.VirtualNic.Specification(
                    ip=vim.host.IpConfig(
                        dhcp=True,
                        ipV6Config=vim.host.IpConfig.IpV6AddressConfiguration(
                            dhcpV6Enabled=False,
                            autoConfigurationEnabled=True,
                            ipV6Address=[
                                vim.host.IpConfig.IpV6Address(
                                    ipAddress='fe80::bff:fe9c:efce',
                                    prefixLength=64
                                )
                            ]
                        ),
                        ipAddress='10.182.189.145',
                        subnetMask='255.255.240.0'
                    ),
                    mtu=1500,
                    netStackInstanceKey='defaultTcpipStack'),
                device='vmk0',
                portgroup='Management Network'
            )
        ]

        self.net_stack_instances = [
            vim.host.NetStackInstance(
                name=None,
                key='ops'
            )
        ]

        self.host_ref.configManager.networkSystem.networkInfo.vnic = self.vmknics_ref
        self.host_ref.configManager.networkSystem.networkInfo.ipV6Enabled = True
        self.host_ref.configManager.networkSystem.networkInfo.netStackInstance = self.net_stack_instances

        self.network_config = NetworkConfig(self.context)

    def test_get_configuration(self):
        expected_data = {'net_stacks': [{'key': 'ops'}],
                         'vmknics': [{'device': 'vmk0',
                                      'ip':
                                          {'dhcp': True,
                                           'ipv4_address': '10.182.189.145',
                                           'ipv4_subnet_mask': '255.255.240.0',
                                           'ipv6':
                                               {
                                                   'auto_configuration_enabled': True,
                                                   'dhcp': False,
                                                   'ipv6_address': [{
                                                       'address': 'fe80::bff:fe9c:efce',
                                                       'prefix_length': 64}]
                                               },
                                           'ipv6_enabled': True
                                           },
                                      'mtu': 1500,
                                      'net_stack_instance_key': 'defaultTcpipStack',
                                      'port_group': 'Management Network'}]}
        data = self.network_config.get_configuration(self.host_ref)
        if data is None:
            self.assertEqual(data, None)
        else:
            self.assertEqual(data.to_dict(), expected_data)

    def test_module_name(self):
        self.assertEqual(self.network_config.module_name(), 'network')
