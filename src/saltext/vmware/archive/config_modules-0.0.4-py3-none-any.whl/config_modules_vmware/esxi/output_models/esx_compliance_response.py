# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from config_modules_vmware.lib.common import consts

logger = logging.getLogger(__name__)

class EsxComplianceResponse:
    """
    Class for handling compliance response and status of hosts in a cluster.
    """

    def __init__(self):
        """
        Initialize a new EsxComplianceResponse instance.
        """
        self.reformatted_cluster_response = {
            consts.SUMMARY: "",
            consts.CLUSTER_STATUS: "",
            consts.HOSTS: {},
            consts.COMPLIANT_HOSTS: [],
            consts.NON_COMPLIANT_HOSTS: []
        }

    def update_with_vlcm_response_for_config_section(self, vlcm_response):
        """
        Update the response with VLCM response data for the configuration section.

        :param vlcm_response: dict, The original VLCM response data.
        """
        cluster_status = vlcm_response[consts.RESULT][consts.CLUSTER_STATUS]
        non_compliant_hosts = vlcm_response[consts.RESULT][consts.NON_COMPLIANT_HOSTS]
        compliant_hosts = vlcm_response[consts.RESULT][consts.COMPLIANT_HOSTS]

        self.reformatted_cluster_response[consts.CLUSTER_STATUS] = cluster_status

        compliance_summary = (
            f"{len(non_compliant_hosts)} hosts are out of compliance."
            if non_compliant_hosts
            else "All hosts in this cluster are compliant."
        )

        self.reformatted_cluster_response[consts.SUMMARY] = compliance_summary

        # Build a dictionary for host_moid to host_name mapping from the host_info of response
        hosts = {}
        host_info_dict = {info["key"]: info["value"][consts.NAME]
                          for info in vlcm_response[consts.RESULT][consts.HOST_INFO]}
        hosts_data = vlcm_response[consts.RESULT][consts.HOSTS]

        for host_data in hosts_data:
            host_moid = host_data["key"]
            host_status = consts.COMPLIANT if host_moid in compliant_hosts else consts.NON_COMPLIANT
            host_name = host_info_dict.get(host_moid, "")

            host_result = {
                consts.NAME: host_name,
                consts.STATUS: host_status
            }

            if "value" in host_data:
                host_compliance_info = \
                    host_data["value"].get(consts.HOST_COMPLIANCE, {}).get(consts.COMPLIANCE_INFO, None)
                if host_compliance_info:
                    host_result[consts.HOST_COMPLIANCE] = host_compliance_info

            hosts[host_moid] = host_result

        self.reformatted_cluster_response[consts.HOSTS] = hosts
        self.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS] = non_compliant_hosts
        self.reformatted_cluster_response[consts.COMPLIANT_HOSTS] = [
            host_moid for host_moid, host_data in hosts.items() if host_data[consts.STATUS] == consts.COMPLIANT
        ]

        logger.debug("Updated EsxComplianceResponse with VLCM response for config section.")

    def update_host_compliance(self, host_moid, host_name, category, differences):
        """
        Update host compliance information for a specific host.

        :param host_moid: str,The moid of the host.
        :param host_name: str, The name of the host.
        :param category: The compliance category.
        :param differences: Dictionary of differences containing path, current, and target values.
        """
        # Check if the host_moid exists in the response
        if host_moid in self.reformatted_cluster_response[consts.HOSTS]:
            host = self.reformatted_cluster_response[consts.HOSTS][host_moid]
            # Check if host_compliance section exists, and if not, create it
            if consts.HOST_COMPLIANCE not in host:
                host[consts.HOST_COMPLIANCE] = {}

            compliance_info = host[consts.HOST_COMPLIANCE].get(category, [])

            if not isinstance(compliance_info, list):
                compliance_info = []

            for path, (current, target) in differences.items():
                compliance_info.append({
                    "path": f"/{path}",
                    "current": str(current).lower(),
                    "target": str(target).lower()
                })

            # Store the updated compliance info in the category
            host[consts.HOST_COMPLIANCE][category] = compliance_info
        else:
            # Host doesn't exist in the response, create a new host entry
            host_data = {
                consts.NAME: host_name,
                consts.HOST_COMPLIANCE: {
                    category: [
                        {
                            "path": f"/{path}",
                            "current": str(current).lower(),
                            "target": str(target).lower()
                        }
                        for path, (current, target) in differences.items()]
                }
            }
            self.reformatted_cluster_response[consts.HOSTS][host_moid] = host_data
        # Update non-compliant hosts, compliance summary, cluster_status
        self.add_to_non_compliant_hosts(host_moid)
        self.update_compliance_summary()
        self.update_cluster_status()
        logger.debug(f"Updated host compliance information for host {host_name} ({host_moid}).")

    def update_compliance_summary(self):
        """
        Update the compliance summary based on non-compliant hosts count.
        """
        non_compliant_count = len(self.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS])
        self.reformatted_cluster_response[consts.SUMMARY] = \
            f"{non_compliant_count} hosts are out of compliance."

    def add_to_non_compliant_hosts(self, host_moid):
        """
        Add a host to the list of non-compliant hosts and update related information.

        :param host_moid: str
        """
        if host_moid not in self.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS]:
            self.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS].append(host_moid)
            # If a host becomes non-compliant, set its status to "NON_COMPLIANT"
            self.update_host_status(host_moid, consts.NON_COMPLIANT)
            # If host_moid is in compliant_hosts, remove it from there
            if host_moid in self.reformatted_cluster_response[consts.COMPLIANT_HOSTS]:
                self.reformatted_cluster_response[consts.COMPLIANT_HOSTS].remove(host_moid)
        self.update_compliance_summary()
        logger.debug(f"Added host {host_moid} to the list of non-compliant hosts.")

    def update_host_status(self, host_moid, status):
        """
        Update host_status to COMPLIANT or NOT_COMPLIANT
        :param host_moid:str
        :param status:
        """
        if host_moid in self.reformatted_cluster_response[consts.HOSTS]:
            self.reformatted_cluster_response[consts.HOSTS][host_moid][consts.STATUS] = status
        logger.debug(f"Updated host status for {host_moid}.")

    def remove_from_non_compliant_hosts(self, host_moid):
        """
        Remove host from non_complaint list
        :param host_moid:str
        """
        if host_moid in self.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS]:
            self.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS].remove(host_moid)
        logger.debug(f"Removed host {host_moid} from the list of non-compliant hosts.")

    def update_cluster_status(self):
        """
        update cluster status to COMPLIANT or NON_COMPLIANT
        """
        if self.reformatted_cluster_response[consts.NON_COMPLIANT_HOSTS]:
            self.reformatted_cluster_response[consts.CLUSTER_STATUS] = consts.NON_COMPLIANT
        elif len(self.reformatted_cluster_response[consts.COMPLIANT_HOSTS]) == \
                len(self.reformatted_cluster_response[consts.HOSTS]):
            self.reformatted_cluster_response[consts.CLUSTER_STATUS] = consts.COMPLIANT
        else:
            self.reformatted_cluster_response[consts.CLUSTER_STATUS] = "UNKNOWN"

    def get_reformatted_response(self):
        return self.reformatted_cluster_response