# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging

from config_modules_vmware.lib.common import consts

logger = logging.getLogger(__name__)

class EsxPrecheckResponse:
    """
    Class for handling precheck response and status of hosts in a cluster.
    """

    def __init__(self):
        self.reformatted_cluster_response = {
            consts.STATUS: "",
            consts.SUMMARY: "",
            consts.HOSTS: {},
            consts.SUCCESSFUL_HOSTS: [],
            consts.FAILED_HOSTS: [],
            consts.SKIPPED_HOSTS: []
        }

    def update_with_vlcm_response_for_config_section(self, vlcm_response):
        """
        Update precheck response with the response from the VLCM.

        :param vlcm_response: dict, The response from the VLCM.
        """
        self.reformatted_cluster_response[consts.SUCCESSFUL_HOSTS] = \
            vlcm_response[consts.RESULT][consts.SUCCESSFUL_HOSTS]
        self.reformatted_cluster_response[consts.FAILED_HOSTS] = \
            vlcm_response[consts.RESULT][consts.FAILED_HOSTS]
        self.reformatted_cluster_response[consts.SKIPPED_HOSTS] = \
            vlcm_response[consts.RESULT][consts.SKIPPED_HOSTS]

        self.reformatted_cluster_response[consts.SUMMARY] = \
            vlcm_response[consts.RESULT][consts.SUMMARY][consts.DEFAULT_MESSAGE]
        self.reformatted_cluster_response[consts.STATUS] = \
            vlcm_response[consts.RESULT][consts.STATUS]

        # Build a dictionary for host_moid to host_name mapping from the host_info of response
        host_info_dict = {info["key"]: info["value"][consts.NAME]
                          for info in vlcm_response[consts.RESULT][consts.HOST_INFO]}

        for host_precheck in vlcm_response[consts.RESULT][consts.HOST_PRECHECK]:
            host_moid = host_precheck["key"]
            host_name = host_info_dict.get(host_moid)

            if host_name is not None:
                host_summary = host_precheck["value"][consts.SUMMARY][consts.DEFAULT_MESSAGE]
                impact = host_precheck["value"].get(consts.IMPACT, None)
                impact_info = [item[consts.DEFAULT_MESSAGE] for item in impact.get(consts.INFO, [])] if impact else []

                host_data = {
                    consts.NAME: host_name,
                    consts.SUMMARY: host_summary,
                }

                if impact:
                    host_data[consts.IMPACT] = impact.get(consts.IMPACT)
                    host_data[consts.IMPACT_INFO] = impact_info

                self.reformatted_cluster_response[consts.HOSTS][host_moid] = host_data
                logger.debug(f"Updated host data for host {host_moid} with impact info.")

    def update_host_summary(self, host_moid):
        """
        Update host summary based on the host MOID.

        :param host_moid: str, The MOID of the host.
        """
        if host_moid in self.reformatted_cluster_response[consts.HOSTS]:
            host_data = self.reformatted_cluster_response[consts.HOSTS][host_moid]

            # If "impact" field is not present(extended config), then set new message
            # else keep the previous summary message intact. For now, impact of extended
            # configs change is not known, so not populating IMPACT
            if consts.IMPACT not in host_data:
                host_data[consts.SUMMARY] = "All pre-checks passed on the host."
                logger.debug(f"Updated summary for host {host_moid}.")

    def update_host_impact_info(self, host_moid, host_name, differences):
        """
        Update host impact information for a specific host.

        :param host_moid: str, The MOID of the host.
        :param host_name: str, The name of the host.
        :param differences: dict, Dictionary of differences containing path, current, and target values.
        """
        if host_moid in self.reformatted_cluster_response[consts.HOSTS]:
            host_data = self.reformatted_cluster_response[consts.HOSTS][host_moid]
        else:
            host_data = {
                consts.NAME: host_name
            }

        if consts.IMPACT_INFO not in host_data:
            host_data[consts.IMPACT_INFO] = []

        # In-line with existing VCP format, append impact_info with config to be updated
        for path, _ in differences.items():
            message = f"Configuration '{path.lstrip('/')}' will be updated on the host."
            host_data[consts.IMPACT_INFO].append(message)
            logger.debug(f"Added impact info for host {host_moid} - Configuration: {path}.")

        self.reformatted_cluster_response[consts.HOSTS][host_moid] = host_data
        self.update_host_summary(host_moid)

    def get_reformatted_response(self):
        """
        Get the reformatted precheck response.

        :return: dict, The reformatted precheck response.
        """
        return self.reformatted_cluster_response

    def get_precheck_status(self):
        """
        Get the precheck status.

        :return: str, The precheck status.
        """
        return self.reformatted_cluster_response[consts.STATUS]