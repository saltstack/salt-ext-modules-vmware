# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from config_modules_vmware.lib.common import consts

logger = logging.getLogger(__name__)

class EsxRemediateResponse:
    """
    Class for handling remediation response and status of hosts in a cluster.
    """

    def __init__(self):
        """
        Initialize the EsxRemediateResponse object.
        """
        self.reformatted_cluster_response = {
            consts.HOSTS: {},
            consts.SUCCESSFUL_HOSTS: [],
            consts.FAILED_HOSTS: [],
            consts.SKIPPED_HOSTS: []
        }

    def update_with_vlcm_response_for_config_section(self, vlcm_response):
        """
        Update the response with VLCM response data for the configuration section.

        :param vlcm_response: dict, The original VLCM response.
        """
        logger.debug("Updating response with VLCM response for the configuration section.")
        self.reformatted_cluster_response[consts.SUCCESSFUL_HOSTS] = \
            vlcm_response[consts.RESULT][consts.SUCCESSFUL_HOSTS]
        self.reformatted_cluster_response[consts.FAILED_HOSTS] = \
            vlcm_response[consts.RESULT][consts.FAILED_HOSTS]
        self.reformatted_cluster_response[consts.SKIPPED_HOSTS] = \
            vlcm_response[consts.RESULT][consts.SKIPPED_HOSTS]

        # Build a dictionary for host_moid to host_name mapping from the host_info of response
        host_info_dict = {info["key"]: info["value"][consts.NAME]
                          for info in vlcm_response[consts.RESULT][consts.HOST_INFO]}

        for host_status in vlcm_response[consts.RESULT][consts.HOST_STATUS]:
            host_moid = host_status["key"]
            host_name = host_info_dict.get(host_moid)

            notifications = host_status.get("value", {}).get(consts.NOTIFICATIONS)
            # If host_moid is already not present, then create entry with name

            if host_moid not in self.reformatted_cluster_response[consts.HOSTS]:
                host_data = {consts.NAME: host_name}
                self.reformatted_cluster_response[consts.HOSTS][host_moid] = host_data

            # If notifications is present in vlcm response then get the notification list
            # and add it to the host_data
            if notifications:
                notifications_info_list = [
                    info_item.get(consts.MESSAGE, {}).get(consts.DEFAULT_MESSAGE, "")
                    for info_item in notifications.get(consts.INFO, [])
                ]
                if host_moid in self.reformatted_cluster_response[consts.HOSTS]:
                    existing_host_data = self.reformatted_cluster_response[consts.HOSTS][host_moid]
                    if consts.NOTIFICATION_INFO in existing_host_data:
                        existing_notifications_info = existing_host_data[consts.NOTIFICATION_INFO]
                        for item in reversed(notifications_info_list):
                            existing_notifications_info.insert(0, item)
                        existing_host_data[consts.NOTIFICATION_INFO] = existing_notifications_info
                    else:
                        self.reformatted_cluster_response[consts.HOSTS][host_moid][consts.NOTIFICATION_INFO] = \
                            notifications_info_list

    def update_host_notification_info(self, host_moid, host_name, paths):
        """
        Update host notification information with multiple paths.

        :param host_moid: str, Host's Managed Object ID.
        :param host_name: str, Host's name.
        :param paths: list, The list of configuration paths.
        """
        logger.debug("Updating host notification information for %s", host_name)
        if host_moid in self.reformatted_cluster_response[consts.HOSTS]:
            host_data = self.reformatted_cluster_response[consts.HOSTS][host_moid]
        else:
            host_data = {
                consts.NAME: host_name
            }

        # Append to notification info as in-line with existing VCP format
        if consts.NOTIFICATION_INFO in host_data:
            for path in paths:
                path = path.lstrip("/")
                host_data[consts.NOTIFICATION_INFO].insert(
                    -1, "Configuration " + path.lstrip("/") + " remediated successfully.")
        elif paths:
            notification_messages = [
                "Configuration Apply task started for extended config on host '" + host_name + "'."
            ]
            notification_messages.extend(
                ["Configuration " + path.lstrip("/") + " remediated successfully." for path in paths])
            notification_messages.append(
                "Configuration Apply task finished for extended config on host '" + host_name + "'.")
            host_data[consts.NOTIFICATION_INFO] = notification_messages

        self.reformatted_cluster_response[consts.HOSTS][host_moid] = host_data

    def get_reformatted_response(self):
        """
        Get the reformatted response.

        :return: dict, The reformatted cluster response.
        """
        return self.reformatted_cluster_response

    def get_failed_hosts(self):
        """
        Get a list of failed hosts.

        :return: list, List of failed host names.
        """
        return self.reformatted_cluster_response[consts.FAILED_HOSTS]

    def get_skipped_hosts(self):
        """
        Get a list of skipped hosts.

        :return: list, List of skipped host names.
        """
        return self.reformatted_cluster_response[consts.SKIPPED_HOSTS]