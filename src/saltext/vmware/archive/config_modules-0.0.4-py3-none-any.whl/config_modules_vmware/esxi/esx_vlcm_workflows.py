# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from typing import List

from config_modules_vmware.base_config import BaseConfig
from config_modules_vmware.lib.common import consts
from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.esxi.esx_config_modules import EsxConfigModulesEnum
from config_modules_vmware.esxi.config_model.esx_config_response import EsxConfigResponse
from config_modules_vmware.esxi.config_model.esx_config_response import Cluster
from config_modules_vmware.esxi.config_model.esx_config_response import Host
from config_modules_vmware.esxi.config_model.esx_config_response import Config
from config_modules_vmware.esxi.config_model.esx_config_response import Profile
from config_modules_vmware.lib.common.drift_detection_algorithm import DriftDetectionAlgorithm
from config_modules_vmware.lib.dcli import dcli

logger = logging.getLogger(__name__)


# Desired Spec related keys
CONFIG = "config"
PROFILE = "profile"
HOST_SPECIFIC = "host-specific"
HOST_OVERRIDE = "host-override"
METADATA = "metadata"
REFERENCE_HOST = "reference_host"
ESX = "esx"


class EsxVlcmInterface(BaseConfig):

    def __init__(self, context: EsxContext):
        super().__init__(context)
        self._esx_config_module_objs = None
        self.esx_config_modules = None
        self.include_defaults = False
        self.follow_vlcm_flow = True

    def get_configuration(self, host_ref):
        logger.info(F"Fetching the Esx configuration for the host: <name: {host_ref.name} "
                    F"moid: {host_ref._GetMoId()}> using vlcm config manger APIs")
        vc_vlcm_client = self._context.vc_vlcm_client()
        esx_config = vc_vlcm_client.extract_host_current_config(host_ref._GetMoId())

        if self.esx_config_modules:
            expected_sub_module_list = set(module.name.lower() for module in self.esx_config_modules)
            available_sub_module_list = set(esx_config["profile"]["esx"].keys())
            remove_sub_module_list = available_sub_module_list - expected_sub_module_list
            for sub_module in remove_sub_module_list:
                del esx_config["profile"]["esx"][sub_module]
        return esx_config

    def _get_desired_state_drifts_vlcm_flow(self, cluster_moid, desired_state_spec=None):
        if desired_state_spec is not None:
            self._validate_desired_state_spec_for_vlcm_flow(cluster_moid, desired_state_spec)

        # Invoke the check compliance info API for the cluster to get the drifts of all the hosts in it.
        vc_vlcm_client = self._context.vc_vlcm_client()
        drifts_info = vc_vlcm_client.check_compliance_cluster_configuration(cluster_moid)
        return drifts_info

    def _validate_desired_state_spec_for_vlcm_flow(self, cluster_moid, desired_state_spec):
        if not self._is_desired_state_spec_valid(desired_state_spec):
            err_msg = F"Provided desired state spec is invalid for the cluster: {cluster_moid}"
            raise Exception(err_msg)

        vc_vlcm_client = self._context.vc_vlcm_client()
        desired_state_spec_at_vc = vc_vlcm_client.export_desired_state_cluster_configuration(cluster_moid)

        # Validate the desired spec, received in the input, matches with desired spec at vc for the given cluster.

        # 1. Prepare desired_state_spec_at_vc vc as desired_spec and user inputted desired_state_spec as the
        #    current_spec,this notion would help user understand the mismatch info. And in the spec consider only
        #    'profile', 'host-specific' and 'host-override' sections.
        desired_spec = {
            PROFILE: desired_state_spec_at_vc[CONFIG][PROFILE],
            HOST_SPECIFIC: desired_state_spec_at_vc[CONFIG].get(HOST_SPECIFIC),
            HOST_OVERRIDE: desired_state_spec_at_vc[CONFIG].get(HOST_OVERRIDE)
        }

        current_spec = {
            PROFILE: desired_state_spec[CONFIG][PROFILE],
            HOST_SPECIFIC: desired_state_spec[CONFIG].get(HOST_SPECIFIC),
            HOST_OVERRIDE: desired_state_spec[CONFIG].get(HOST_OVERRIDE)
        }

        # 2. Since we are doing the spec comparison at top level which includes all the sub-module sections, we need
        #    to prepare array_key_map which includes the keys of all the sub-module.
        #
        #    Each Sub-module maintains its own array_key_map and in which, for static_key_map, path would start from
        #    that sub-module section, so since we are doing the comparison at top level static_key_map from
        #    sub-module would not work as-is. And also considering that we have three different sections ('profile',
        #    'host-specific' and 'host-override') in a specs we want to compare, which all include sub-module sections,
        #    we could prepare consolidated regex_key_map using static_key_map of each sub-module with appending
        #    module_name to avoid any conflicts.
        #
        #    For example:
        #           sub-module's array key map :
        #                   advanced_options_array_key_map = {
        #                        "static_key_map": {"user_vars": ["option_name"]},
        #                        "regex_key_map": {}
        #                    }
        #                    network_key_MAP = {
        #                       "static_key_map": {"vmknics": ["device"]},
        #                       "regex_key_map": {}
        #                      }
        #
        #           Updated array_key_map at top level:
        #                    top_level_array_key_map = {
        #                       "static_key_map": {},
        #                       "regex_key_map": {".*.esx.advanced_options.user_vars": ["option_name"],
        #                                         ".*.esx.network.vmknics": ["device"]}
        #                    }
        regex_key_map = dict()
        for sub_module in EsxConfigModulesEnum:
            module_array_key_map = sub_module.value.array_key_map()
            if consts.STATIC_KEY_MAP in module_array_key_map:
                module_regex_key_map = dict()
                for key, value in module_array_key_map[consts.STATIC_KEY_MAP].items():
                    updated_key = ".*{}.{}.{}".format(ESX, sub_module.value.module_name(), key)
                    module_regex_key_map[updated_key] = value
                regex_key_map.update(module_regex_key_map)
            if consts.REGEX_KEY_MAP in module_array_key_map:
                regex_key_map.update(module_array_key_map[consts.REGEX_KEY_MAP])

        arrays_keys_map = {
            consts.REGEX_KEY_MAP: regex_key_map
        }

        # 3. Finally, invoke the get_drifts function of DriftDetectionAlgorithm to find the mismatch information.
        drift_detection_algortihm = DriftDetectionAlgorithm()
        compliance_result = drift_detection_algortihm.get_drifts(desired_spec=desired_spec,
                                                                 current_spec=current_spec,
                                                                 arrays_keys_map=arrays_keys_map)
        if compliance_result[consts.COMPLIANCE_STATUS] == consts.NON_COMPLIANT:
            err_msg = F"The desired state spec passed doesn't match with one set for the cluster " \
                      F"in vlcm config manager. The mismatch info: {compliance_result[consts.DRIFTS]}"
            raise Exception(err_msg)

    @staticmethod
    def _is_desired_state_spec_valid(desired_state_spec) -> bool:
        if CONFIG not in desired_state_spec:
            logger.error(F"Key '{CONFIG}' missing in desires state spec")
            return False
        config = desired_state_spec[CONFIG]
        required_keys = [PROFILE, METADATA]
        if not all(key in config for key in required_keys):
            logger.error(F"One of the key in the set:{required_keys} is missing in the "
                         F"'{CONFIG}' section of desires state spec")
            return False
        return True
