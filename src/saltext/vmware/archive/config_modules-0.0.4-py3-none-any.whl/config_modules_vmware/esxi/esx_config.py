# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from typing import List

from config_modules_vmware.base_config import BaseConfig
from config_modules_vmware.lib.common import consts
from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.esxi.esx_config_modules import EsxConfigModulesEnum
from config_modules_vmware.esxi.config_model.esx_config_response import EsxConfigResponse
from config_modules_vmware.esxi.config_model.esx_config_response import Cluster
from config_modules_vmware.esxi.config_model.esx_config_response import Host
from config_modules_vmware.esxi.config_model.esx_config_response import Config
from config_modules_vmware.esxi.config_model.esx_config_response import Profile
from config_modules_vmware.lib.common.drift_detection_algorithm import DriftDetectionAlgorithm

logger = logging.getLogger(__name__)

# Desired Spec related keys
CONFIG = "config"
PROFILE = "profile"
HOST_SPECIFIC = "host-specific"
HOST_OVERRIDE = "host-override"
METADATA = "metadata"
REFERENCE_HOST = "reference_host"
ESX = "esx"


class EsxConfig(BaseConfig):
    """
    Class to implement config management functionalities for ESXi module
    """
    def __init__(self, context: EsxContext):
        super().__init__(context)
        self._esx_config_module_objs = None
        self.esx_config_modules = None
        self.include_defaults = False
        self.follow_vlcm_flow = True

    def initialize_esx_config_module_objs(self):
        """
        Create objects for submodule, if esx_config_modules is empty then create objects for
        all sub-modules mentioned in Enum EsxConfigModulesEnum.
        """
        self._esx_config_module_objs = list()
        if not self.esx_config_modules:
            logger.info("Creating module object list for all modules ")
            for config_submodule in EsxConfigModulesEnum:
                self._esx_config_module_objs.append(config_submodule.value(self._context))
        else:
            for config_submodule in self.esx_config_modules:
                self._esx_config_module_objs.append(config_submodule.value(self._context))

    def get_configuration(self, host_moids: List[str] = None, cluster_moids: List[str] = None,
                          esx_config_modules: List[EsxConfigModulesEnum] = None, include_defaults=False,
                          enable_vlcm_flow=True):
        """
        Get configuration functionality for Esx Config

        :param host_moids: It is a list host moid of hosts for which esx config need to be fetched.
        :type host_moids: 'List['str']'
        :param cluster_moids: It is a list of cluster moids, esx config need to be fetched for all the
                              hosts belonging to each cluster.
        :type cluster_moids: 'List['str']'
        :param esx_config_modules: It is list of esx config modules for which esx config need to be fetched.
        :type esx_config_modules: 'List[EsxConfigModulesEnum]'
        :param include_defaults: For Advanced_Options submodules. Whether to include default values in the returned
                                 config.
        :type include_defaults: bool
        :param enable_vlcm_flow: Flag to enable/disable the VLCM flow if it is available.
        :type enable_vlcm_flow: bool
        :rtype: `dict`
        :return: Config info in the json type format.

        Handling of request parameters:

        1. If cluster_moids and hosts_moids are both None:
            then fetch config all the hosts in the SDDC (standalone hosts and hosts configured under cluster).

        2. If cluster_moids is not None:
            then host config needs to be fetched for all the hosts belonging to each cluster in the list.

        3. If hosts_moids is not None:
            then check if any of the host in the host_moids is already fetched as part of retrieving clusters if not
            fetch config for those hosts and plus check if it is a standalone host, if it is standalone host then
            append it to the 'standalone_host' array or else add it to the cluster it belongs to.

        Response structure should be as below for get_config functionality :

                {
                  "clusters": [
                    {
                      "name": "cluster-1",
                      "moid": "cluster-1-moid"
                      "hosts": [
                        {
                          "config": {...},
                          "name": "host-1"
                          "moid": "host-1-moid"
                        }
                     ]
                    }
                  ]
                  "standalone_hosts": [
                    {
                      "config": {...},
                      name": "standalone_host-1"
                      "moid": "standalone_host-1-moid"
                    }
                  ]
                }
        """
        self.esx_config_modules = esx_config_modules
        self.include_defaults = include_defaults
        self.enable_vlcm_flow = enable_vlcm_flow
        vc_vmomi_client = self._context.vc_vmomi_client()
        esx_config_response = EsxConfigResponse()
        if not host_moids and not cluster_moids:
            clusters = list()
            standalone_hosts = list()

            for cluster_ref in vc_vmomi_client.get_all_clusters():
                cluster = self._get_esx_config_cluster_object(cluster_ref)
                clusters.append(cluster)

            for standalone_host_ref in vc_vmomi_client.get_all_standalone_esx_hosts_from_vc():
                standalone_host = self._get_esx_config_host_object(standalone_host_ref)
                standalone_hosts.append(standalone_host)

            esx_config_response.clusters = clusters
            esx_config_response.standalone_hosts = standalone_hosts
        else:
            prepared_host_list = set()
            clusters = dict()
            standalone_hosts = list()

            if cluster_moids:
                for cluster_moid in cluster_moids:
                    cluster_ref = vc_vmomi_client.get_cluster_ref_for_moid(cluster_moid)
                    cluster = self._get_esx_config_cluster_object(cluster_ref)
                    clusters[cluster.moid] = cluster
                    for host in cluster.hosts:
                        prepared_host_list.add(host.moid)

            if host_moids:
                for host_moid in host_moids:
                    if host_moid in prepared_host_list:
                        continue
                    host_ref = vc_vmomi_client.get_host_ref_for_moid(host_moid)
                    if vc_vmomi_client.\
                            is_standalone_host(host_ref):
                        host = self._get_esx_config_host_object(host_ref)
                        standalone_hosts.append(host)
                    else:
                        parent_cluster_ref = vc_vmomi_client.\
                            get_cluster_for_host(host_ref)
                        parent_cluster_moid = parent_cluster_ref._GetMoId()
                        if parent_cluster_moid in clusters:
                            host = self._get_esx_config_host_object(host_ref)
                            clusters[parent_cluster_moid].hosts.append(host)
                        else:
                            clusters[parent_cluster_moid] = \
                                self._get_esx_config_cluster_object(parent_cluster_ref, [host_ref])

            esx_config_response.clusters = list(clusters.values())
            esx_config_response.standalone_hosts = standalone_hosts

        return esx_config_response.to_dict()

    def get_desired_state_drifts(self, cluster_moid, desired_state_spec=None):
        """
        Provides a get desired state drifts functionality for Esx Config.

        :param cluster_moid: It is a mob id of a cluster for which drifts need to be computed for all the hosts,
                             belonging to the that cluster, against the desired state spec mentioned for that cluster.
        :type cluster_moid: 'str'
        :param desired_state_spec: It is desired state spec for the given cluster.
        :type desired_state_spec: 'Dict'
        :rtype: `dict`
        :return: Desired state drifts in the json type format.

        Handling of request parameters:

        - Desired state spec is an optional parameter.
            - For vlcm config manager available and configured case:
                - If desired state spec provided then validate the spec against the one set at the cluster at vcenter
                    if there is mismatch then throw exception.
            - For vlcm config manager not available or not configured case:
                - If desired state spec provided then use that spec to compute the drifts for all the hosts against
                    spec.
                - If desired state spec not provided then throw the exception, as desred state spec is mandatory for
                    non vlcm config manager case.

        Structure of desired state spec:
                        {
                            "config": {
                                "profile": {
                                    "esx": {}
                                },
                                "host-specific": {
                                    "BIOS-UUID-1": {
                                        "esx": {}
                                    }
                                },
                                "host-override": {
                                    "BIOS-UUID-2": {
                                        "esx": {}
                                    }
                                },
                                "metadata": {
                                    "reference_host": {
                                    "uuid": "BIOS-UUID-1",
                                    "build": "Releasebuild-21495797",
                                    "patch": "0",
                                    "update": "1",
                                    "version": "8.0.1"
                                    }
                                }
                            }
                        }

            - Desired state spec has 4 sections under 'config' namely 'profile'(required), 'host-specific'(optional),
                'host-override'(optional) and 'metadata' (optional).
            - For any invalid desired state spec as input, a exception will be thrown.

        Response Structure of the payload for get drift functionality:
                        {
                          "status": "NON-COMPLIANT",
                          "result": {
                                "cluster_status": "NOT_COMPLIANT",
                                "failed_hosts": [],
                                "hosts": [
                                    {
                                        "value": {
                                            "host_compliance": {
                                                "compliance_info": {
                                                    "deletes": [],
                                                    "adds": [],
                                                    "sets": []
                                                },
                                                "status": "NON_COMPLIANT"
                                            }
                                        },
                                        "key": "host-23"
                                    },
                                    {
                                        "value": {
                                            "host_compliance": {
                                                "status": "COMPLIANT"
                                            }
                                        },
                                        "key": "host-29"
                                    }
                                ],
                                "non_compliant_hosts": ["host-23"],
                                "skipped_hosts": [],
                                "compliant_hosts": ["host-29"],
                                "host_info": []
                          }
                        }
        """
        # Trigger workflow based on the vlcm config manager configured on the cluster or not.
        if self._is_vlcm_config_manager_configured_on_cluster(cluster_moid):
            return self._get_desired_state_drifts_vlcm_flow(cluster_moid, desired_state_spec)
        return self._get_desired_state_drifts_non_vlcm_flow(cluster_moid, desired_state_spec)

    def _get_esx_config_vlcm_flow(self, host_ref):
        logger.info(F"Fetching the Esx configuration for the host: <name: {host_ref.name} "
                    F"moid: {host_ref._GetMoId()}> using vlcm config manger APIs")
        vc_vlcm_client = self._context.vc_vlcm_client()
        esx_config = vc_vlcm_client.extract_host_current_config(host_ref._GetMoId())

        if self.esx_config_modules:
            expected_sub_module_list = set(module.name.lower() for module in self.esx_config_modules)
            available_sub_module_list = set(esx_config["profile"]["esx"].keys())
            remove_sub_module_list = available_sub_module_list - expected_sub_module_list
            for sub_module in remove_sub_module_list:
                del esx_config["profile"]["esx"][sub_module]
        return esx_config

    def _get_esx_config_non_vlcm_flow(self, host_ref):
        if not self._esx_config_module_objs:
            self.initialize_esx_config_module_objs()
        esx_config_obj = Config(profile=Profile(esx=dict()))
        for submodule_obj in self._esx_config_module_objs:
            esx_config_obj.profile.esx[submodule_obj.module_name()] = submodule_obj.get_configuration(host_ref,
                                                                                include_defaults=self.include_defaults)
        return esx_config_obj

    def _get_esx_config(self, host_ref):
        vc_vlcm_client = self._context.vc_vlcm_client()
        if vc_vlcm_client.is_vlcm_config_manager_supported_in_vcsa() and self.enable_vlcm_flow:
            return self._get_esx_config_vlcm_flow(host_ref)
        return self._get_esx_config_non_vlcm_flow(host_ref)

    def _get_esx_config_host_object(self, host_ref):
        host = Host()
        host.name = host_ref.name
        host.moid = host_ref._GetMoId()
        host.config = self._get_esx_config(host_ref)

        logger.info(F"Finished fetching the Esx configuration for the host: "
                    F"<name: {host_ref.name} moid: {host_ref._GetMoId()}>")
        return host

    def _get_esx_config_cluster_object(self, cluster_ref, host_refs=None):
        logger.info(F"Fetching Esx configuration for the hosts in the cluster: "
                    F"<name:{cluster_ref.name}, moid:{cluster_ref._GetMoId()}>")

        vc_vmomi_client = self._context.vc_vmomi_client()
        hosts = list()
        cluster = Cluster()
        if not host_refs:
            host_refs = vc_vmomi_client.get_all_hosts_from_parent(cluster_ref)
        for host_ref in host_refs:
            host = self._get_esx_config_host_object(host_ref)
            hosts.append(host)
        cluster.name = cluster_ref.name
        cluster.moid = cluster_ref._GetMoId()
        cluster.hosts = hosts

        logger.info(F"Finished fetching Esx configuration for the hosts in the cluster: "
                    F"<name:{cluster_ref.name}, moid:{cluster_ref._GetMoId()}>")
        return cluster

    def _is_desired_state_spec_valid(self, desired_state_spec) -> bool:
        if CONFIG not in desired_state_spec:
            logger.error(F"Key '{CONFIG}' missing in desires state spec")
            return False
        config = desired_state_spec[CONFIG]
        required_keys = [PROFILE, METADATA]
        if not all(key in config for key in required_keys):
            logger.error(F"One of the key in the set:{required_keys} is missing in the "
                         F"'{CONFIG}' section of desires state spec")
            return False
        return True

    def _validate_desired_state_spec_for_vlcm_flow(self, cluster_moid, desired_state_spec):
        if not self._is_desired_state_spec_valid(desired_state_spec):
            err_msg = F"Provided desired state spec is invalid for the cluster: {cluster_moid}"
            raise Exception(err_msg)

        vc_vlcm_client = self._context.vc_vlcm_client()
        desired_state_spec_at_vc = vc_vlcm_client.export_desired_state_cluster_configuration(cluster_moid)

        # Validate the desired spec, received in the input, matches with desired spec at vc for the given cluster.

        # 1. Prepare desired_state_spec_at_vc vc as desired_spec and user inputted desired_state_spec as the
        #    current_spec,this notion would help user understand the mismatch info. And in the spec consider only
        #    'profile', 'host-specific' and 'host-override' sections.
        desired_spec = {
            PROFILE: desired_state_spec_at_vc[CONFIG][PROFILE],
            HOST_SPECIFIC: desired_state_spec_at_vc[CONFIG].get(HOST_SPECIFIC),
            HOST_OVERRIDE: desired_state_spec_at_vc[CONFIG].get(HOST_OVERRIDE)
        }

        current_spec = {
            PROFILE: desired_state_spec[CONFIG][PROFILE],
            HOST_SPECIFIC: desired_state_spec[CONFIG].get(HOST_SPECIFIC),
            HOST_OVERRIDE: desired_state_spec[CONFIG].get(HOST_OVERRIDE)
        }

        # 2. Since we are doing the spec comparison at top level which includes all the sub-module sections, we need
        #    to prepare array_key_map which includes the keys of all the sub-module.
        #
        #    Each Sub-module maintains its own array_key_map and in which, for static_key_map, path would start from
        #    that sub-module section, so since we are doing the comparison at top level static_key_map from
        #    sub-module would not work as-is. And also considering that we have three different sections ('profile',
        #    'host-specific' and 'host-override') in a specs we want to compare, which all include sub-module sections,
        #    we could prepare consolidated regex_key_map using static_key_map of each sub-module with appending
        #    module_name to avoid any conflicts.
        #
        #    For example:
        #           sub-module's array key map :
        #                   advanced_options_array_key_map = {
        #                        "static_key_map": {"user_vars": ["option_name"]},
        #                        "regex_key_map": {}
        #                    }
        #                    network_key_MAP = {
        #                       "static_key_map": {"vmknics": ["device"]},
        #                       "regex_key_map": {}
        #                      }
        #
        #           Updated array_key_map at top level:
        #                    top_level_array_key_map = {
        #                       "static_key_map": {},
        #                       "regex_key_map": {".*.esx.advanced_options.user_vars": ["option_name"],
        #                                         ".*.esx.network.vmknics": ["device"]}
        #                    }
        regex_key_map = dict()
        for sub_module in EsxConfigModulesEnum:
            module_array_key_map = sub_module.value.array_key_map()
            if consts.STATIC_KEY_MAP in module_array_key_map:
                module_regex_key_map = dict()
                for key, value in module_array_key_map[consts.STATIC_KEY_MAP].items():
                    updated_key = ".*{}.{}.{}".format(ESX, sub_module.value.module_name(), key)
                    module_regex_key_map[updated_key] = value
                regex_key_map.update(module_regex_key_map)
            if consts.REGEX_KEY_MAP in module_array_key_map:
                regex_key_map.update(module_array_key_map[consts.REGEX_KEY_MAP])

        arrays_keys_map = {
            consts.REGEX_KEY_MAP: regex_key_map
        }

        # 3. Finally, invoke the get_drifts function of DriftDetectionAlgorithm to find the mismatch information.
        drift_detection_algortihm = DriftDetectionAlgorithm()
        compliance_result = drift_detection_algortihm.get_drifts(desired_spec=desired_spec,
                                                                 current_spec=current_spec,
                                                                 arrays_keys_map=arrays_keys_map)
        if compliance_result[consts.COMPLIANCE_STATUS] == consts.NON_COMPLIANT:
            err_msg = F"The desired state spec passed doesn't match with one set for the cluster " \
                      F"in vlcm config manager. The mismatch info: {compliance_result[consts.DRIFTS]}"
            raise Exception(err_msg)

    def _get_desired_state_drifts_vlcm_flow(self, cluster_moid, desired_state_spec=None):
        if desired_state_spec is not None:
            self._validate_desired_state_spec_for_vlcm_flow(cluster_moid, desired_state_spec)

        # Invoke the check compliance info API for the cluster to get the drifts of all the hosts in it.
        vc_vlcm_client = self._context.vc_vlcm_client()
        drifts_info = vc_vlcm_client.check_compliance_cluster_configuration(cluster_moid)
        return drifts_info

    def _get_desired_state_drifts_non_vlcm_flow(self, cluster_moid, desired_state_spec):
        if not desired_state_spec:
            err_msg = F"Desired state spec is not provided, which is required when the" \
                      F" given cluster: {cluster_moid} has no vlcm config manager configured"
            raise Exception(err_msg)

        if not self._is_desired_state_spec_valid(desired_state_spec):
            err_msg = F"Provided desired state spec is invalid for the cluster: {cluster_moid}"
            raise Exception(err_msg)
        # TODO: This workflow yet to be implemented.

    def _is_vlcm_config_manager_configured_on_cluster(self, cluster_moid):
        vc_vlcm_client = self._context.vc_vlcm_client()
        return vc_vlcm_client.is_vlcm_config_manager_supported_in_vcsa() and \
                vc_vlcm_client.is_vlcm_config_manager_enabled_on_cluster(cluster_moid)

    def kwargs_for_get_configuration(self, **kwargs):
        return {"cluster_moids": kwargs['cluster'],
                "host_moids":  kwargs['host'],
                "esx_config_modules": kwargs['sub_module'],
                "include_defaults": kwargs['include_defaults'],
                "enable_vlcm_flow": kwargs['enable_vlcm_flow']}
