# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json
import logging
from typing import List

from config_modules_vmware.base_config import BaseConfig
from config_modules_vmware.lib.common import consts
from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.esxi.esx_config_modules import EsxConfigModulesEnum
from config_modules_vmware.esxi.config_model.esx_config_response import EsxConfigResponse
from config_modules_vmware.esxi.config_model.esx_config_response import Cluster
from config_modules_vmware.esxi.config_model.esx_config_response import Host
from config_modules_vmware.esxi.config_model.esx_config_response import Config
from config_modules_vmware.esxi.config_model.esx_config_response import Profile
from config_modules_vmware.lib.common.drift_detection_algorithm import DriftDetectionAlgorithm
from config_modules_vmware.lib.dcli import dcli
from config_modules_vmware.lib.dcli.dcli import Dcli

logger = logging.getLogger(__name__)


class EsxNonVlcmInterface(BaseConfig):

    def __init__(self, context: EsxContext):
        super().__init__(context)
        self._esx_config_module_objs = None
        self.esx_config_modules = None
        self.include_defaults = False
        self.follow_vlcm_flow = True

    def get_configuration(self, host_ref):
        if not self._esx_config_module_objs:
            self._initialize_esx_config_module_objs()
        command = Dcli().host_info(host_ref.esxCredentials).namespace(["com", "vmware", "esx", "settingsdaemon",
                                                              "configuration"]).command("export")
        esx_config_obj = command.execute()
        # todo: remove invalid submodules
        for submodule_obj in self._esx_config_module_objs:
            esx_config_obj.profile.esx[submodule_obj.module_name()] = submodule_obj.get_configuration(host_ref,
                                                                                                      include_defaults=self.include_defaults)
        return esx_config_obj

    def _initialize_esx_config_module_objs(self):
        """
        Create objects for submodule, if esx_config_modules is empty then create objects for
        all sub-modules mentioned in Enum EsxConfigModulesEnum.
        """
        self._esx_config_module_objs = list()
        if not self.esx_config_modules:
            logger.info("Creating module object list for all modules ")
            for config_submodule in EsxConfigModulesEnum:
                self._esx_config_module_objs.append(config_submodule.value(self._context))
        else:
            for config_submodule in self.esx_config_modules:
                self._esx_config_module_objs.append(config_submodule.value(self._context))

    def _get_desired_state_drifts_non_vlcm_flow(self, cluster_moid, desired_state_spec):
        if not desired_state_spec:
            err_msg = F"Desired state spec is not provided, which is required when the" \
                      F" given cluster: {cluster_moid} has no vlcm config manager configured"
            raise Exception(err_msg)

        if not self._is_desired_state_spec_valid(desired_state_spec):
            err_msg = F"Provided desired state spec is invalid for the cluster: {cluster_moid}"
            raise Exception(err_msg)
        # TODO: This workflow yet to be implemented.
