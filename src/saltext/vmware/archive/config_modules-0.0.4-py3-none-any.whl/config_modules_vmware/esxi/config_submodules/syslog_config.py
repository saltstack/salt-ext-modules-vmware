# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from typing import List
import logging
from pyVmomi import vim
from urllib.parse import urlparse, parse_qs

from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl
from config_modules_vmware.esxi.config_model.syslog_config_model import SyslogConfigModel, AuditRecordSettings, \
    GlobalSettings, Logfilters, LoggerSettings, RemoteLogging, LogHost, LogLevel, Protocol, Formatter, Framing
from config_modules_vmware.utils.utils import invoke_advanced_option_query, get_data_using_esxcli

logger = logging.getLogger(__name__)


class SyslogConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the syslog configs of ESXi host.
    """
    MODULE_NAME = 'syslog'

    _advanced_options_map = {
        "logfilters": {
            "enable_logfilters": {"key": "Syslog.global.logFiltersEnable"},
            "filters": {"key": "Syslog.global.logFilters"}},
        "audit_record_settings": {
            "enable_local_audit_record_storage": {"key": "Syslog.global.auditRecord.storageEnable"},
            "prevent_record_dropping": {"key": "Syslog.global.auditRecord.preventRecordDropping"},
            "local_storage_dir": {"key": "Syslog.global.auditRecord.storageDirectory"},
            "local_storage_dir_capacity": {"key": "Syslog.global.auditRecord.storageCapacity"}},
        "remote_logging": {
            "crl_check": {"key": "Syslog.global.certificate.checkCRL"},
            "x509_strict": {"key": "Syslog.global.certificate.strictX509Compliance"},
            "check_ssl_certs": {"key": "Syslog.global.certificate.checkSSLCerts"},
            "retry_timeout": {"key": "Syslog.global.remoteHost.connectRetryDelay"},
            "log_host": {"key": "Syslog.global.logHost"}},
        "global_settings": {
            "vsan_backing": {"key": "Syslog.global.vsanBacking"},
            "log_dir_unique": {"key": "Syslog.global.logDirUnique"},
            "rotations": {"key": "Syslog.global.defaultRotate"},
            "rotation_size_in_kb": {"key": "Syslog.global.defaultSize"},
            "drop_log_rotate": {"key": "Syslog.global.droppedMsgs.fileRotate"},
            "drop_log_size": {"key": "Syslog.global.droppedMsgs.fileSize"},
            "queue_drop_mark": {"key": "Syslog.global.msgQueueDropMark"},
            "log_dir": {"key": "Syslog.global.logDir"},
            "log_level": {"key": "Syslog.global.logLevel"},
            # remote_logging will be constructed from several fields defined in "remote_logging" mapping
            "remote_logging": {},
            "remote_host_max_msg_len": {"key": "Syslog.global.remoteHost.maxMsgLen"}}
    }

    def __init__(self, context):
        self._context = context

    @classmethod
    def module_name(cls):
        """
        Get submodule name
        :rtype: 'str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns syslog configuration for the ESXi host

        :param host_ref: Host reference
        :type host_ref: vim.HostSystem
        :param include_defaults: Include default config values
        :type include_defaults: bool
        :rtype: `dict`
        :return: Config info of the syslog module.
        """
        syslog_config = SyslogConfigModel()
        syslog_response = invoke_advanced_option_query(host_ref, prefix='Syslog.global')
        syslog_response_dict = self._convert_dict(syslog_response)
        syslog_config.audit_record_settings = self._get_audit_record_config(host_ref, syslog_response_dict)
        syslog_config.logger_settings = self._get_logger_config(host_ref)
        syslog_config.logfilters = self._get_logger_filter_config(host_ref, syslog_response_dict)
        syslog_config.global_settings = self._get_global_config(host_ref, syslog_response_dict)
        return syslog_config.to_dict()

    def _get_logger_filter_config(self, host_ref, syslog_response_dict) -> Logfilters:
        logger.info(F"Get system syslog config logfilter ' for host: {host_ref.name}")
        logger_filter_config = Logfilters()
        logger_filter_map = self._advanced_options_map['logfilters']
        for key in logger_filter_map:
            if logger_filter_map.get(key).get('key') in syslog_response_dict:
                if key == 'enable_logfilters':
                    setattr(logger_filter_config, key, syslog_response_dict.get(logger_filter_map.get(key).get('key')))
                elif key == 'filters':
                    logger_filters_values = syslog_response_dict.get(logger_filter_map.get(key).get('key'))
                    if logger_filters_values:
                        filters = []
                        filters.extend(logger_filters_values.split('||'))
                        logger_filter_config.filters = filters
        return logger_filter_config

    @staticmethod
    def _convert_dict(syslog_response):
        result = {}
        for entry in syslog_response:
            result[entry.key] = entry.value
        return result

    def _get_audit_record_config(self, host_ref, syslog_response_dict):
        logger.info(F"Get system auditrecords' for host: {host_ref.name}")
        audit_record_config = AuditRecordSettings()
        audit_record_map = self._advanced_options_map['audit_record_settings']
        for key in audit_record_map:
            if audit_record_map.get(key).get('key') in syslog_response_dict:
                setattr(audit_record_config, key, syslog_response_dict.get(audit_record_map.get(key).get('key')))
        return audit_record_config

    def _get_logger_config(self, host_ref) -> List[LoggerSettings]:
        logger.info(F"Get system syslog config logger list' for host: {host_ref.name}")
        logger_config_values = get_data_using_esxcli(context=self._context, host_ref=host_ref,
                                                           name_space=['system', 'syslog', 'config', 'logger'],
                                                           command='list')
        if logger_config_values:
            loggers_config = []
            for config_value in logger_config_values:
                logger_settings = LoggerSettings(logger=config_value['ID'])
                logger_settings.rotations = int(config_value['Rotations'])
                logger_settings.description = config_value['Description']
                logger_settings.log_file_name = config_value['Destination']
                logger_settings.identifications = config_value['ID']
                logger_settings.rotation_size_in_kb = int(config_value['RotationSize'])
                loggers_config.append(logger_settings)
            return loggers_config

    def _get_global_config(self, host_ref, syslog_response_dict) -> GlobalSettings:
        logger.info(F"Get system syslog config global settings' for host: {host_ref.name}")
        global_config = GlobalSettings()
        global_setting_map = self._advanced_options_map['global_settings']

        for key in global_setting_map:
            if global_setting_map.get(key).get('key') in syslog_response_dict:
                value = syslog_response_dict.get(global_setting_map.get(key).get('key'))
                if key == 'log_level':
                    value = LogLevel(value.upper())
                setattr(global_config, key, value)
            elif key == 'remote_logging':
                value = self._parse_remote_logging(syslog_response_dict)
                setattr(global_config, key, value)
        return global_config

    def _parse_remote_logging(self, syslog_response_dict) -> RemoteLogging:
        log_hosts = []
        remote_logging = RemoteLogging(log_host=log_hosts)
        remote_logging_map = self._advanced_options_map['remote_logging']
        for key in remote_logging_map:
            if remote_logging_map.get(key).get('key') in syslog_response_dict:
                value = syslog_response_dict.get(remote_logging_map.get(key).get('key'))
                if key == 'log_host' and value is not None:
                    for config_value in value.split(','):
                        log_hosts.append(self._parse_log_host(config_value.strip()))
                    value = log_hosts
                setattr(remote_logging, key, value)
        return remote_logging

    def _parse_log_host(self, config_value) -> LogHost:
        """
        Examples
        tcp://10.176.130.7:12345
            Transmits syslog messages to 10.176.130.7 using TCP/IP and port 12345. Formatting is RFC_3164; no framing.
        tcp://[2001:db8:85a3:8d3:1319:8a2e:370:7348]:54321
            Transmit syslog messages to an IPV6 address using port 54321. Formatting is RFC 3164; no framing.
        udp://company.com?formatter=RFC_5424&framing=octet_counting:
            Transmits syslog messages to company.com using UDP and port 514. Formatting is RFC_5424;
            the framing is octet_counting.
        udp://company.com,tcp://10.20.30.40:1050
            Transmits syslog messages to two remote hosts. The first remote host uses UDP to communicate with
            company.com using port 514. The second remote host uses TCP to communicate with the IPV4 address
            10.20.30.40 using port 1050. In both cases, formatting is RFC 3164; no framing.
        Dealt port is 514 for UDP, 1514 for TCP and 1514 for SSL
        """

        uri_parts = urlparse(config_value)
        query_parameters = parse_qs(uri_parts.query) if uri_parts.query is not None else None
        formatter = Formatter(query_parameters['formatter'][0].upper())\
            if 'formatter' in query_parameters else Formatter.RFC_3164
        framing = Framing(query_parameters['framing'][0].upper())\
            if 'framing' in query_parameters else Framing.NOT_SPECIFIED

        log_host = LogHost(address=uri_parts.hostname, protocol=Protocol(uri_parts.scheme.upper()),
                       port=uri_parts.port if uri_parts.port is not None else None,
                       formatter=formatter, framing=framing)

        return log_host