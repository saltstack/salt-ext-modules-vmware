# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl
from config_modules_vmware.esxi.config_model.authorization_config_model import DcuiAccess, Permissions, SystemUsers, AuthorizationData

logger = logging.getLogger(__name__)

class AuthorizationConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the autorization configs of ESXi host.
    """
    MODULE_NAME = 'authorization'

    def __init__(self, context):
        self._context = context

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns authorization configuration for the ESXi host
        """
        dcui_obj = self._get_dcui_access(host_ref)
        permission_obj = self._get_permissions(host_ref)
        sys_usr_obj = self._get_system_users(host_ref)
        esx_auth_obj = AuthorizationData(dcui_obj,
                                         permission_obj,
                                         sys_usr_obj)

        return esx_auth_obj.to_dict()

    def _get_dcui_access(self, host_ref):
        """
        Fetch details of DCUI users of the esxi host
        """
        logger.info(
            F"Populating the  DCUI user details for host: {host_ref.name}")
        users = []
        for option_data in host_ref.config.option:
            if option_data.key == "DCUI.Access":
                users.append(option_data.value)

        dcui_obj = DcuiAccess(users)
        return dcui_obj

    def _get_permissions(self, host_ref):
        """
        Fetch details of  permissions on the esxi host
        """
        logger.info(
            F"Populating the  permissions user details for host: {host_ref.name}")
        permission_data = []
        resp_data = self._context.esxcli_client().host(host_ref.name). \
            namespace(["system", "permission"]).command("list").execute()
        for item in resp_data:
            permission_obj = Permissions(item['Role'],
                                         item["IsGroup"],
                                         item["Principal"])
            permission_data.append(permission_obj)
        return permission_data

    def _get_system_users(self, host_ref):
        """
        Get system users id from the esxi host
        """
        logger.info(
            F"Populating the  system user details for host: {host_ref.name}")
        users = []
        resp_data = self._context.esxcli_client().host(host_ref.name).namespace(
            ["system", "account"]).command("list").execute()
        for xitem in resp_data:
            users.append(xitem["UserID"])
        sys_user_obj = SystemUsers(users)
        return sys_user_obj

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME