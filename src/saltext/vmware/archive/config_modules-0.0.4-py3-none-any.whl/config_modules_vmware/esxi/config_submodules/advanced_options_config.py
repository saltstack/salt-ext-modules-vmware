# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
import os
from pyVmomi import vim

from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl
from config_modules_vmware.esxi.config_model.advanced_options_config_model import AdvancedOptionsConfigModel, \
    AdvancedOptionsUserVars
from config_modules_vmware.utils.utils import get_template_json
from config_modules_vmware.lib.esxcli.esxcli import EsxCli
from config_modules_vmware.utils.utils import invoke_advanced_option_query

logger = logging.getLogger(__name__)

ADVANCED_OPTIONS_MAPPING_SCHEMA = '../config_model/advanced_options_mapping.json'

# Entries listed in the follwing link with OPT_EXCLUDE_FROM_CM tag should be excluded from output
# https://opengrok2.eng.vmware.com/xref/main.perforce.1666/bora/vmkernel/private/config_opts.h?r=11498147
exclude_list = ['HostName', 'HostIPAddr', 'HordeEnabled', 'FindLongCLIs', 'VsanIsEnabled',
                'TcpipDefaultStackCCAlgo', 'TcpipTxDispatchQuota', 'ManagementIface',
                'ManagementAddr', 'ProvisioningVmknics', 'HostLocalSwapDir',
                'HostLocalSwapDirEnabled', 'Vmknic', 'UserMemASRandomSeed', 'VsanPeriodicTimerInterrupt',
                'PersistVnuma']

# Esxcli is case sensitive. query map is required to have mapping between search string and final output.

class AdvancedOptionsConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the advanced options configs of ESXi host.
    """

    MODULE_NAME = 'advanced_options'

    def __init__(self, context):
        self.host_ref = None
        self.user_vars = None
        self._context = context
        self.advanced_options_mapping = None
        self._esx_cli_installed = self._context.esxcli_client().installed
        self._query_map = {
            'COW': 'COW',
            'CBRC': 'CBRC',
            'FDS': 'FDS',
            'FSS': 'FSS',
            'FT': 'FT',
            'HBR': 'HBR',
            'LVM': 'LVM',
            'NFSv3': 'NFSv3',
            'NFS41': 'NFSv41',
            'RCU': 'RCU',
            'SE': 'SE',
            'USB': 'USB',
            'VFLASH': 'VFLASH',
            'VMFS3': 'VMFS3',
            'VMKTRACING': 'VMKTRACING',
            'VSCSIStats': 'VSCSI_stats',
            'VVOL': 'VVOL',
            'BufferCache2': 'buffer_cache2',
            'Cpu': 'cpu',
            'DataMover': 'data_mover',
            'Digest': 'digest',
            'DirentryCache': 'direntry_cache',
            'Disk': 'disk',
            'FileSystem': 'file_system',
            'Hpp': 'hpp',
            'Irq': 'irq',
            'LoadESX': 'loadESX',
            'LPage': 'lpage',
            'Mem': 'mem',
            'Migrate': 'migrate',
            'Misc': 'misc',
            'Net': 'net',
            'Nmp': 'nmp',
            'Numa': 'numa',
            'PageRetire': 'page_retire',
            'PMem': 'pmem',
            'Power': 'power',
            'Scsi': 'scsi',
            'SunRPC': 'sunRPC',
            'SvMotion': 'svmotion',
            'User': 'user',
            'UserMem': 'userMem',
            'UserObj': 'userObj',
            'VisorFS': 'visorFS',
            'VmkAccess': 'vmkAccess',
            'VProbes': 'vprobes',
            'World': 'world',
            'XvMotion': 'xvmotion'
        }
        #TODO: The below option 'context.config_agent_parity' is temporary
        # and should be removed upon completing the Advanced Options submodule performance improvements.
        # https://jira.eng.vmware.com/browse/SDDCCONFIG-705.

        if hasattr(context, 'config_agent_parity') and context.config_agent_parity:
            self._query_map = {'Net': 'net'}

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    @staticmethod
    def array_key_map():
        """
        Returns the array key map for Advanced_options module, that's used in the json spec comparison of array objects
        present in Advanced_options module's config.

        :rtype: `dict`
        :return: Array key map of the Advanced_options config module.
        """
        return AdvancedOptionsConfigModel.array_key_map()

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns advanced options configuration for the ESXi host

        :param host_ref: Host reference
        :type host_ref: vim.HostSystem
        :rtype: `dict`
        :return: Config info of the  Advanced_options module.
        """
        self.host_ref = host_ref
        advanced_options_config_obj = AdvancedOptionsConfigModel()
        advanced_options_config_obj.user_vars = self._get_user_vars_config()
        curr_dir = os.path.dirname(__file__)
        self.advanced_options_mapping = get_template_json(os.path.join(curr_dir, ADVANCED_OPTIONS_MAPPING_SCHEMA))
        if not include_defaults:
            advanced_options_config_obj = self.get_non_default_advanced_options_config()
            return advanced_options_config_obj.to_dict()

        for option_key in self._query_map.keys():
            config = {}
            self._get_dict_options_config(option_key, config)
            self._get_hidden_options_config(option_key, config)
            if config:
                setattr(advanced_options_config_obj, self._query_map[option_key], config)
        return advanced_options_config_obj.to_dict()

    def _get_user_vars_config(self):
        logger.info(F"Populating the advanced options config for 'user_vars' for host: {self.host_ref.name}")
        option_values = self._invoke_advanced_option_query(query='UserVars.')
        if option_values:
            user_vars_config = list()
            for option_value in option_values:
                user_vars_item = AdvancedOptionsUserVars()
                user_vars_item.option_name = option_value.key.split('.')[-1]
                if isinstance(option_value.value, int):
                    user_vars_item.integer_value = option_value.value
                else:
                    user_vars_item.string_value = option_value.value
                user_vars_config.append(user_vars_item)
            return user_vars_config

    def _invoke_advanced_option_query(self, query):
        return invoke_advanced_option_query(self.host_ref, query)

    def _get_dict_options_config(self, query_root_option_name, config):
        """
        :param query_root_option_name: Advanced option query
        :param config: o/p dictionary to populate
        """
        # To make search case insensitive append . at the end of string for example net.
        query_string = f'{query_root_option_name}.'
        query_response = self._invoke_advanced_option_query(query=query_string)
        if query_response:
            mapping_dict = self.advanced_options_mapping[self._query_map[query_root_option_name]]
            for query_value in query_response:
                option_key_name = query_value.key.split('.')[-1]
                mapping_key = mapping_dict.get(option_key_name)
                if mapping_key:
                    if option_key_name in exclude_list:
                        continue
                    config[mapping_key['name']] = query_value.value
                else:
                    logger.info(f'Could not find mapping for {option_key_name}')
                    config[option_key_name] = query_value.value

    def _get_hidden_options_config(self, query_root_option_name, config):
        """
        :param query_root_option_name: Advanced option query
        :param config: o/p dictionary to populate
        example command:
        /usr/bin/esxcli -s <host_name> -u <username> -p <pwd> -d <thumbprint> --formatter csv system settings advanced list -o=/COW/COWAllowVMFSSparseCoalesce
        Returns:
        [{'DefaultIntValue': '0', 'DefaultStringValue': '', 'Description': 'Desc', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '0', 'MaxValue': '1', 'MinValue': '0', 'Path': '/COW/COWAllowVMFSSparseCoalesce', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''}]
        Is parsed and config is populated
        config['COW_allow_VMFS_sparse_coalesce'] = 0
        """
        if self._esx_cli_installed:
            logger.info(f'Fetch hidden config for {query_root_option_name}')
            option_dict = self.advanced_options_mapping[self._query_map[query_root_option_name]]
            for key, val in option_dict.items():
                if val['hidden'] and key not in exclude_list:
                    query_string = f'-o=/{query_root_option_name}/{key}'
                    try:
                        result = self._get_data_using_esxcli(query_string)
                        config[val['name']] = result[0]['IntValue']
                    except Exception as e:
                        pass
            logger.info(f'Successfully fetched hidden config {query_root_option_name}')

    def _get_data_using_esxcli(self, query_string):
        """Fetch data using esxcli for advanced options"""
        try:
            result = {}
            if self._esx_cli_installed:
                result = self._context.esxcli_client().host(self.host_ref.name). \
                    namespace(["system", "settings", "advanced"]).command("list").command_options(query_string).execute()
            return result
        except Exception as e:
            logger.info(f'Error while fetching data for {query_string} using esxcli, exception {str(e)}')
            raise e

    def get_non_default_advanced_options_config(self):
        """
        Function to fetch advanced options config for ESXi host. This function should return only fields are not default
        return : Advanced options config object
        """
        delta_dict = self._get_updated_config_dict()
        advanced_options_config_obj = AdvancedOptionsConfigModel()
        for option_key in delta_dict.keys():
            option_val = delta_dict[option_key]
            config = {}
            if option_key == 'UserVars':
                user_vars_config = list()
                for i in range(len(option_val)):
                    for key, val in option_val[i].items():
                        user_vars_item = AdvancedOptionsUserVars()
                        user_vars_item.option_name = key
                        if isinstance(val, int):
                            user_vars_item.integer_value = val
                        else:
                            user_vars_item.string_value = val
                        user_vars_config.append(user_vars_item)
                if len(user_vars_config) > 0:
                    advanced_options_config_obj.user_vars = user_vars_config
            else:
                mapping_dict = self.advanced_options_mapping[self._query_map[option_key]]
                for i in range(len(option_val)):
                    for key, val in option_val[i].items():
                        mapping_key = mapping_dict[key]['name']
                        config[mapping_key] = val
                if config:
                    setattr(advanced_options_config_obj, self._query_map[option_key], config)
        return advanced_options_config_obj

    def _get_updated_config_dict(self):
        """
        This function runs esxcli -d command and result and converts to dictionary.
        Result of esxcli command with -d option
        command:
        /usr/bin/esxcli -s <host_name> -u <username> -p <password> -d <thumbprint> --formatter csv system settings advanced list -d
        Result:
        [{'DefaultIntValue': '5', 'DefaultStringValue': '', 'Description': 'Desc1', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '90', 'MaxValue': '86400', 'MinValue': '1', 'Path': '/Misc/HeartbeatTimeout', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''},
        {'DefaultIntValue': '10', 'DefaultStringValue': '', 'Description': 'Desc2', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '900', 'MaxValue': '86400', 'MinValue': '1', 'Path': '/Misc/HeartbeatPanicTimeout', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''}
        {'DefaultIntValue': '0', 'DefaultStringValue': '', 'Description': 'Desc3', 'HostSpecific': 'false', 'Impact': 'none', 'IntValue': '1', 'MaxValue': '1', 'MinValue': '0', 'Path': '/Net/FollowHardwareMac', 'StringValue': '', 'Type': 'integer', 'ValidCharacters': '', '': ''}]
        Is converted to following dictionary:
        {'Misc': [{'HeartbeatTimeout': '90'}, {'HeartbeatPanicTimeout': '900'}], 'Net': [{'FollowHardwareMac': '1'}]}
        """
        config = {}
        result = self._get_data_using_esxcli("-d")
        for item in result:
            path, value = item['Path'], item['IntValue']
            option_list = path.split('/')
            category, option = option_list[1], option_list[-1]
            if option in exclude_list:
                continue
            config[category] = config.get(category, [])
            config[category].append({option: value})
        return config
