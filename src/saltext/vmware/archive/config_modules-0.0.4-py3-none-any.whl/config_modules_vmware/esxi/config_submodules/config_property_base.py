# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from abc import ABC, abstractmethod


class ConfigProperty(ABC):
    @abstractmethod
    def get(self, context, host_ref):
        pass

    @abstractmethod
    def set(self, context, host_ref, value):
        pass

    @abstractmethod
    def precheck(self, context, host_ref, value):
        pass

    def remediate(self, context, host_ref, value):
        return self.set(context, host_ref, value)
