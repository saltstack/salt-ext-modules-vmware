# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import logging
from enum import Enum

from config_modules_vmware.esxi.config_model.storage_config_model import StorageConfigModel, NfsV3Datastore, \
    NfsV41Datastore, BaseNfsDatastore, AuthType
from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl

logger = logging.getLogger(__name__)


class FileSystemVolumeType(Enum):
    """
    Enumeration for file system volume types
    """
    NFS = "NFS"
    NFS41 = "NFS41"


class StorageConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the storage configs of ESXi host.
    """

    MODULE_NAME = 'storage'

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def __init__(self, context):
        self.host_ref = None
        self.user_vars = None
        self._context = context
        self.storage_config_obj = None

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns storage configuration for the ESXi host.
        """
        self.host_ref = host_ref
        self.storage_config_obj = self._get_host_storage_info()
        logger.info(F"Finished populating the storage_iscsi config for host: {self.host_ref.name}")
        return self.storage_config_obj.to_dict()

    def _get_host_storage_info(self):
        """
        Populate the storage info.
        @return: storage config model object.
        @rtype: StorageConfigModel
        """
        storage_iscsi_config = StorageConfigModel()
        storage_iscsi_config.nfs_v3_datastores = list()
        storage_iscsi_config.nfs_v41_datastores = list()
        if self.host_ref.config and self.host_ref.config.fileSystemVolume and \
                self.host_ref.config.fileSystemVolume.mountInfo:
            for volume_info in self.host_ref.config.fileSystemVolume.mountInfo:
                if volume_info.volume.type == FileSystemVolumeType.NFS.value:
                    storage_iscsi_config.nfs_v3_datastores.append(
                        self._get_nfs_v3_datastores_config(volume_info=volume_info))
                elif volume_info.volume.type == FileSystemVolumeType.NFS41.value:
                    storage_iscsi_config.nfs_v41_datastores.append(
                        self._get_nfs_v41_datastores_config(volume_info=volume_info))
                else:
                    pass

        return storage_iscsi_config

    def _get_nfs_v3_datastores_config(self, volume_info):
        """
        Populate the nfs v3 datastore config.
        """
        logger.info(F"Populating the Storage: nfs_v3_datastores config for host: {self.host_ref.name}")
        nfs_v3_datastore_config = NfsV3Datastore()
        self._set_nfs_base_config(volume_info, nfs_v3_datastore_config, "nfs")
        nfs_v3_datastore_config.hostname = volume_info.volume.remoteHostNames[0]
        nfs_v3_datastore_config.connections = volume_info.mountInfo.numTcpConnections
        nfs_v3_datastore_config.vmknic_name = volume_info.mountInfo.vmknicName
        nfs_v3_datastore_config.bind_to_vmknic = volume_info.mountInfo.vmknicActive
        return nfs_v3_datastore_config

    def _get_nfs_v41_datastores_config(self, volume_info):
        """
        Populate the nfs v41 datastore config.
        """
        logger.info(F"Populating the Storage: nfs_v41_datastores config for host: {self.host_ref.name}")
        nfs_v41_datastore_config = NfsV41Datastore()
        self._set_nfs_base_config(volume_info, nfs_v41_datastore_config, "nfs41")
        nfs_v41_datastore_config.hostnames = volume_info.volume.remoteHostNames
        if volume_info.volume.securityType is not None:
            nfs_v41_datastore_config.auth_type = AuthType(volume_info.volume.securityType)
        return nfs_v41_datastore_config

    def _set_nfs_base_config(self, volume_info, nfs_base_config: BaseNfsDatastore, nfs_type):
        nfs_base_config.volume_name = volume_info.volume.name
        nfs_base_config.remote_share = volume_info.volume.remotePath
        nfs_base_config.read_only = volume_info.mountInfo.accessMode == "readOnly"
        try:

            if self._context.esxcli_client().installed:
                maxq_depth = self._context.esxcli_client().host(self.host_ref.name)\
                    .namespace(["storage", nfs_type, "param"]).command("get")\
                    .command_options("-v={}".format(volume_info.volume.name)).execute()
                if maxq_depth is not None and len(maxq_depth) > 0:
                    nfs_base_config.maxq_depth = int(maxq_depth[0]["MaxQueueDepth"])
        except Exception:
            logger.exception(f"Exception invoking esxcli for retrieving maxq_depth for host {self.host_ref.name}")
