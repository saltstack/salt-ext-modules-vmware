# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import logging
from typing import List

from config_modules_vmware.esxi.config_model.graphics_config_model import GraphicsConfigModel, Policy, Device, DefaultType, SharedPassthruAssignmentPolicy

from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl

logger = logging.getLogger(__name__)

class GraphicsConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the storage iscsi configs of ESXi host.
    """
    MODULE_NAME = 'graphics'

    def __init__(self, context = None):
        self.host_ref = None
        self.user_vars = None
        self._context = context
        self.graphics_config_obj = None

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns graphics config for the ESXi host.
        :param host_ref: the host reference object.
        :return: graphics config of ESXi host.
        """
        self.host_ref = host_ref
        self.graphics_config_obj = GraphicsConfigModel()
        graphics_config = self.host_ref.config.graphicsConfig
        device_info_list = self.host_ref.configManager.graphicsManager.graphicsInfo
        self.graphics_config_obj.policy = self._get_policy(graphics_config)
        self.graphics_config_obj.devices = self._get_graphics_devices(device_info_list)
        return self.graphics_config_obj.to_dict()

    def _get_policy(self, graphics_config) -> Policy:
        policy = Policy()
        policy.default_type = DefaultType(graphics_config.hostDefaultGraphicsType)
        policy.shared_passthru_assignment_policy = SharedPassthruAssignmentPolicy(graphics_config.sharedPassthruAssignmentPolicy)
        return policy

    def _get_graphics_devices(self, device_info_list) -> List[Device]:
        graphics_devices = []
        for device_info in device_info_list:
            device = Device()
            device.type = DefaultType(device_info.graphics_type)
            device.device = device_info.deviceName
            graphics_devices.append(device)
        return graphics_devices
