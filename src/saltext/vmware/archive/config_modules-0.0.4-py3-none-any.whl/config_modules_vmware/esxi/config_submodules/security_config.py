# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import logging

from config_modules_vmware.esxi.config_model.security_config_model import Security, SecuritySettings
from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl
from config_modules_vmware.utils.utils import invoke_advanced_option_query

logger = logging.getLogger(__name__)
ADVANCED_OPTIONS_QUERY_SECURITY_PREFIX = 'Security.'
advanced_options_map = {
    "Security.AccountLockFailures": "account_lock_failures",
    "Security.AccountUnlockTime": "account_unlock_time",
    "Security.DefaultShellAccess": "default_shell_access",
    "Security.PasswordHistory": "password_history",
    "Security.PasswordMaxDays": "password_max_days",
    "Security.PasswordQualityControl": "password_quality_control",
    "Security.SshSessionLimit": "ssh_session_limit"
}


class SecurityConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the security configs of ESXi host.
    """

    MODULE_NAME = 'security'

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def __init__(self, context):
        self.host_ref = None
        self.user_vars = None
        self._context = context

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns security configuration for the ESXi host.
        """
        logger.info(F"Populating the security config for host: {host_ref.name}")
        self.host_ref = host_ref
        security = self._get_security_settings()
        logger.info(F"Finished populating the security config for host: {host_ref.name}")
        return security.to_dict()

    def _get_security_settings(self):
        security_settings = SecuritySettings()
        options = invoke_advanced_option_query(self.host_ref, ADVANCED_OPTIONS_QUERY_SECURITY_PREFIX)
        if options:
            for option in options:
                if advanced_options_map.__contains__(option.key):
                    setattr(security_settings, advanced_options_map.get(option.key), option.value)
        security = Security()
        security.settings = security_settings
        return security
