# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from config_modules_vmware.esxi.config_submodules.config_property_base import ConfigProperty

logger = logging.getLogger(__name__)


class Cim(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting CIM for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting CIM for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Shell(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Shell for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Shell for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Slp(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Slp for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Slp for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Snmp(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Snmp for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Snmp for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Ssh(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Ssh for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Ssh for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Firewall(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Firewall for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Firewall for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class LockdownExceptionUsers(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting LockdownExceptionUsers for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting LockdownExceptionUsers for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class LockdownMode(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting LockdownMode for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting LockdownMode for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Switches(ConfigProperty):
    def get(self, context, host_ref):
        # return list of switches
        logger.debug(f"Getting Switches for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Switches for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Vmknics(ConfigProperty):
    def get(self, context, host_ref):
        # return list of switches
        logger.debug(f"Getting Vmknics for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Vmknics for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None
