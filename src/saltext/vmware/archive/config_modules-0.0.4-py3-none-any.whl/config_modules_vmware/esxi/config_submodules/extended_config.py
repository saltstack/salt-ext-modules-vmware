# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from config_modules_vmware.esxi.config_submodules.config_property_base import ConfigProperty

logger = logging.getLogger(__name__)

lockdownModeMapping = {
    "lockdownDisabled": "disabled",
    "lockdownNormal": "normal",
    "lockdownStrict": "strict"
}

def get_service_config(host_ref, key):
    services = host_ref.configManager.serviceSystem.serviceInfo.service
    if not services:
        return None
    service = next(filter(lambda s: s.key==key, services), None)
    return service.running

class Cim(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting CIM for host {host_ref.name}")
        return get_service_config(host_ref, "sfcbd-watchdog")

    def set(self, context, host_ref, value):
        logger.debug(f"Setting CIM for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Shell(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Shell for host {host_ref.name}")
        return get_service_config(host_ref, "TSM")

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Shell for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Slp(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Slp for host {host_ref.name}")
        return get_service_config(host_ref, "slpd")

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Slp for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Snmp(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Snmp for host {host_ref.name}")
        return get_service_config(host_ref, "snmpd")

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Snmp for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Ssh(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Ssh for host {host_ref.name}")
        return get_service_config(host_ref, "TSM-SSH")

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Ssh for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Firewall(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Firewall for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Firewall for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class LockdownExceptionUsers(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting LockdownExceptionUsers for host {host_ref.name}")
        access_manager = host_ref.configManager.hostAccessManager
        if not access_manager:
            return None
        return access_manager.QueryLockdownExceptions()

    def set(self, context, host_ref, value):
        logger.debug(f"Setting LockdownExceptionUsers for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class LockdownMode(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting LockdownMode for host {host_ref.name}")
        config = host_ref.config
        if not config:
            return None
        return lockdownModeMapping.get(config.lockdownMode)

    def set(self, context, host_ref, value):
        logger.debug(f"Setting LockdownMode for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Switches(ConfigProperty):
    def get(self, context, host_ref):
        # return list of switches
        logger.debug(f"Getting Switches for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Switches for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Vmknics(ConfigProperty):
    def get(self, context, host_ref):
        # return list of switches
        logger.debug(f"Getting Vmknics for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Vmknics for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None
