# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
from config_modules_vmware.esxi.config_submodules.config_property_base import ConfigProperty

logger = logging.getLogger(__name__)

lockdownModeMapping = {
    "lockdownDisabled": "disabled",
    "lockdownNormal": "normal",
    "lockdownStrict": "strict"
}

def get_service_config(host_ref, key):
    services = host_ref.configManager.serviceSystem.serviceInfo.service
    if not services:
        return None
    service = next(filter(lambda s: s.key==key, services), None)
    return service.running

class ServiceConfig(ConfigProperty):
    
    @classmethod
    def _toggle_service(cls, host_ref, service_name, value):
        logger.debug("Setting %s for host %s", service_name, host_ref.name)
        host_service = host_ref.configManager.serviceSystem
        service = cls._get_service(host_service, service_name)
        
        if service:
            if value:
                if not service.running:
                    return cls._start_service(host_service, service.key)
                else:
                    return True  # The service is already running.
            else:
                if service.running:
                    return cls._stop_service(host_service, service.key)
                else:
                    return True  # The service is already stopped.
        else:
            # Log a debug message if the service is missing
            logger.debug("Service %s not found on host %s", service_name, host_ref.name)
        return False
    
    @classmethod
    def _get_service(cls, host_service, service_name):
        if not host_service:
            return None
        services = host_service.serviceInfo.service
        if not services:
            return None
        service = next((service for service in services if service.key == service_name), None)
        
        if service is None:
            # Log a debug message if the service is missing
            logger.debug(f"Service {service_name} not found")
        
        return service

    @classmethod
    def _start_service(cls, host_service, service_key):
        try:
            host_service.StartService(id=service_key)
            return True
        except Exception as e:
            logger.error(f"Error starting service {service_key}: {str(e)}")
            return False

    @classmethod
    def _stop_service(cls, host_service, service_key):
        try:
            host_service.StopService(id=service_key)
            return True
        except Exception as e:
            logger.error(f"Error stopping service {service_key}: {str(e)}")
            return False

class Cim(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting CIM for host {host_ref.name}")
        return get_service_config(host_ref, "sfcbd-watchdog")

    def set(self, context, host_ref, value):
        logger.debug(f"Set CIM for host {host_ref.name} for value {value}")             
        return ServiceConfig._toggle_service(host_ref, "sfcbd-watchdog", value)
    

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Shell(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Shell for host {host_ref.name}")
        return get_service_config(host_ref, "TSM")

    def set(self, context, host_ref, value):
        logger.debug(f"Set Shell for host {host_ref.name} for value {value}")             
        return ServiceConfig._toggle_service(host_ref, "TSM", value)

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Slp(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Slp for host {host_ref.name}")
        return get_service_config(host_ref, "slpd")

    def set(self, context, host_ref, value):
        logger.debug(f"Set Slp for host {host_ref.name} for value {value}")             
        return ServiceConfig._toggle_service(host_ref, "slpd", value)


    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Snmp(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Snmp for host {host_ref.name}")
        return get_service_config(host_ref, "snmpd")

    def set(self, context, host_ref, value):
        logger.debug(f"Set snmpd for host {host_ref.name} for value {value}")       
        return ServiceConfig._toggle_service(host_ref, "snmpd", value)


    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Ssh(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Ssh for host {host_ref.name}")
        return get_service_config(host_ref, "TSM-SSH")

    def set(self, context, host_ref, value):
        logger.debug(f"Set Ssh for host {host_ref.name} for value {value}")          
        return ServiceConfig._toggle_service(host_ref, "TSM-SSH", value)


    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Firewall(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting Firewall for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Firewall for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class LockdownExceptionUsers(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting LockdownExceptionUsers for host {host_ref.name}")
        access_manager = host_ref.configManager.hostAccessManager
        if not access_manager:
            return None
        return access_manager.QueryLockdownExceptions()

    def set(self, context, host_ref, value):
        logger.debug(f"Set LockdownExceptionUsers for host {host_ref.name} for value {value}")       

        # Check if value is a valid array of users
        if not isinstance(value, list):
           logger.debug("Invalid value. Expected a list of users.")
           return False

        try:
           # Get the current LockdownExceptionUsers
           access_manager = host_ref.configManager.hostAccessManager                    

           # Set the updated LockdownExceptionUsers
           access_manager.UpdateLockdownExceptions(value)

           logger.debug("LockdownExceptionUsers updated successfully.")
           return True

        except Exception as e:
            logger.debug(f"Failed to update LockdownExceptionUsers: {str(e)}")
            return False


    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class LockdownMode(ConfigProperty):
    def get(self, context, host_ref):
        logger.debug(f"Getting LockdownMode for host {host_ref.name}")
        config = host_ref.config
        if not config:
            return None
        return lockdownModeMapping.get(config.lockdownMode)

    def set(self, context, host_ref, value):
        logger.debug(f"Set LockdownMode for host {host_ref.name} for value {value}")       
        config = host_ref.config
        if not config:
            return None
        host_config_manager = host_ref.configManager
        if not host_config_manager:
             return False
         
        # Validate that the provided value is a valid Lockdown Mode
        if value not in lockdownModeMapping.values():
             logger.error("Invalid Lockdown Mode value provided.")
             return False

        # Reverse the mapping to get the corresponding key for the given value
        lockdown_mode_key = next((k for k, v in lockdownModeMapping.items() if v == value), None)

        if lockdown_mode_key:
             try:
                host_config_manager.hostAccessManager.ChangeLockdownMode(lockdown_mode_key)
                logger.debug(f"LockdownMode altered for host {host_ref.name}")
                return True
             except Exception as e:
                 logger.error(f"Error updating Lockdown Mode: {str(e)}")
                 return False

        return False


    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Switches(ConfigProperty):
    def get(self, context, host_ref):
        # return list of switches
        logger.debug(f"Getting Switches for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Switches for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None


class Vmknics(ConfigProperty):
    def get(self, context, host_ref):
        # return list of switches
        logger.debug(f"Getting Vmknics for host {host_ref.name}")
        # config_value = pyvmomi or esxcli get logic
        # return config_value
        return None

    def set(self, context, host_ref, value):
        logger.debug(f"Setting Vmknics for host {host_ref.name}")
        # pyvmomi or esxcli set logic
        # return True if successful and False otherwise
        return True

    def precheck(self, context, host_ref, value):
        # precheck logic
        # returns TBD
        return None
