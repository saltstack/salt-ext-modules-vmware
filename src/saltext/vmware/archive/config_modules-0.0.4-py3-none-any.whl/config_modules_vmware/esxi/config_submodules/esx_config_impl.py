# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from abc import ABC, abstractmethod


class EsxConfigImpl(ABC):
    """EsxBaseModule class defines the interface each ESX config module should implement."""

    @classmethod
    def module_name(cls):
        """
        Get submodule name, each sub module implement this method and return their module name.
        """
        return ""

    @abstractmethod
    def get_configuration(self, host_ref):
        """
        Returns the configuration for the ESXi host. Sub-modules should implement this method to return the config
        info of their module.
        """
        pass

    @staticmethod
    def array_key_map():
        """
        Returns the array key map, that's used in the json spec comparison of array objects. All the sub module should
        implement this method to provide their own array key map. If it's not implemented then it will be empty as
        implemented below.
        Sub-module provides the static_key_map with path starting from their section, if anybody using this information
        to compare spec at different path level then it's their responsibility modify the array_key_map accordingly.
        """
        return {}
