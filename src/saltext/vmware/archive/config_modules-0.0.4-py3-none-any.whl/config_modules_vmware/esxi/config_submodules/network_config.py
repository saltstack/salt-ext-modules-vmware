# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import logging
from typing import List

from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl
from config_modules_vmware.esxi.config_model.network_model import Network, Vmknic, NetStack, Ip, Ipv6, Ipv6Address


logger = logging.getLogger(__name__)


class NetworkConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the network configs of ESXi host.
    """

    MODULE_NAME = 'network'

    def __init__(self, context):
        pass

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns network configuration for the ESXi host.
        """
        configuration = Network()
        configuration.vmknics = self._get_vmknics_config(host_ref)
        configuration.net_stacks = self._get_net_stack_config(host_ref)
        return configuration


    def _get_vmknics_config(self, host_ref):
        logger.info(F"Populating the Network vmknics config for host: {host_ref.name}")
        vmknics = list()
        if host_ref.configManager.networkSystem.networkInfo:
            vmknics_ref = host_ref.configManager.networkSystem.networkInfo.vnic
            for vmknic_ref in vmknics_ref:
                vmknic = Vmknic()
                vmknic.ip = self._get_vmknic_ip_config(host_ref, vmknic_ref.spec.ip)
                vmknic.mtu = vmknic_ref.spec.mtu
                vmknic.device = vmknic_ref.device
                vmknic.port_group = vmknic_ref.portgroup
                vmknic.net_stack_instance_key = vmknic_ref.spec.netStackInstanceKey
                vmknics.append(vmknic)
        logger.info(F"Finished populating the Network vmknics config for "
                    F"vmknics: {[x.device for x in vmknics]} for host: {host_ref.name}")
        return vmknics

    def _get_net_stack_config(self, host_ref):
        logger.info(F"Populating the Network net_stack config for host: {host_ref.name}")
        net_stack_instances = list()
        if host_ref.configManager.networkSystem.networkInfo:
            net_stack_instances_ref = host_ref.configManager.networkSystem.networkInfo.netStackInstance
            for net_stack_instance_ref in net_stack_instances_ref:
                net_stack_instance = NetStack()
                net_stack_instance.name = net_stack_instance_ref.name
                net_stack_instance.key = net_stack_instance_ref.key
                net_stack_instances.append(net_stack_instance)
        logger.info(F"Finished populating the Network net_stack config for "
                    F"instances:{[x.key for x in net_stack_instances]} for host: {host_ref.name}")
        return net_stack_instances

    def _get_vmknic_ip_config(self, host_ref, ip_config_ref):
        ip_config = Ip()
        ip_config.dhcp = ip_config_ref.dhcp
        ip_config.ipv6_enabled = host_ref.configManager.networkSystem.networkInfo.ipV6Enabled
        ip_config.ipv6 = self._get_vmknic_ipv6_config(ip_config_ref.ipV6Config) if ip_config.ipv6_enabled else None
        ip_config.ipv4_address = ip_config_ref.ipAddress
        ip_config.ipv4_subnet_mask = ip_config_ref.subnetMask
        return ip_config

    def _get_vmknic_ipv6_config(self, ipv6_config_ref):
        ipv6_config = Ipv6()
        ipv6_config.dhcp = ipv6_config_ref.dhcpV6Enabled
        ipv6_config.auto_configuration_enabled = ipv6_config_ref.autoConfigurationEnabled
        ipv6_addresses = list()
        for ipv6_address_ref in ipv6_config_ref.ipV6Address:
            ipv6_address = Ipv6Address()
            ipv6_address.address = ipv6_address_ref.ipAddress
            ipv6_address.prefix_length = ipv6_address_ref.prefixLength
            ipv6_addresses.append(ipv6_address)
        ipv6_config.ipv6_address = ipv6_addresses
        return ipv6_config
