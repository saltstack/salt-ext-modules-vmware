# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import logging
from typing import List

from pyVmomi import vim

from config_modules_vmware.esxi.config_model.storage_iscsi_config_model import StorageISCSISoftwareAdapter, Target, \
    StorageISCSIConfigModel, ChapAuthenticationType, ChapAuthentication, MutualChapAuth, Credentials, DigestLevel, \
    ErrorRecoveryLevel, StorageISCSIHardwareAdapter, IndependentNetworking, IpV4Option, IpV6Option, IpV4, IpV6, \
    TargetType, IpAddress, AdapterType, BaseAdapter
from config_modules_vmware.esxi.config_submodules.esx_config_impl import EsxConfigImpl

logger = logging.getLogger(__name__)

SUPPORTED_HARDWARE_ADAPTER_DRIVERS = ['qfle3i', 'elxiscsi']
SUPPORTED_SOFTWARE_ADAPTER_DRIVER = 'iscsi_vmk'
# below map provides mappging between the advanced options key value to the required output property in the model class.
advanced_options_map = {
    "ErrorRecoveryLevel": "error_recovery_level",
    "LoginRetryMax": "login_retry_max",
    "MaxOutstandingR2T": "max_outstanding_r2t",
    "FirstBurstLength": "first_burst_length",
    "MaxBurstLength": "max_burst_length",
    "MaxRecvDataSegLen": "max_recv_data_segment_length",
    "MaxCommands": "max_commands",
    "DefaultTimeToWait": "default_time_to_wait",
    "DefaultTimeToRetain": "default_time_to_retain",
    "LoginTimeout": "login_timeout",
    "LogoutTimeout": "logout_timeout",
    "RecoveryTimeout": "recovery_timeout",
    "NoopTimeout": "noop_out_timeout",
    "NoopInterval": "noop_out_interval",
    "InitR2T": "initial_r2t",
    "ImmediateData": "immediate_data",
    "DelayedAck": "delayed_ack"
}


class StorageIscsiConfig(EsxConfigImpl):
    """
    This class provides the methods to populate the storage iscsi configs of ESXi host.
    """
    MODULE_NAME = 'storage_iscsi'

    def __init__(self, context=None):
        self.host_ref = None
        self.user_vars = None
        self._context = context
        self.storage_iscsi_config_obj = None

    @classmethod
    def module_name(cls):
        """
        Get submodule name

        :rtype: `str`
        :return: Module name.
        """
        return cls.MODULE_NAME

    def get_configuration(self, host_ref, include_defaults=False):
        """
        Returns storage iscsi config for the ESXi host.
        :param host_ref: the host reference object.
        :return: storage iscsi config of ESXi host.
        """
        self.host_ref = host_ref
        self.storage_iscsi_config_obj = self._get_host_storage_device_info()
        logger.info(F"Finished populating the storage_iscsi config for host: {self.host_ref.name}")
        return self.storage_iscsi_config_obj.to_dict()

    def _get_host_storage_device_info(self) -> StorageISCSIConfigModel:
        """
        Retrieve host storage device information.
        :return: storage iscsi config model.
        :rtype: 'StorageISCSIConfigModel'
        """
        storage_iscsi_config = StorageISCSIConfigModel()
        if self.host_ref.config and self.host_ref.config.storageDevice and \
                self.host_ref.config.storageDevice.hostBusAdapter:
            storage_iscsi_config.software_adapter = self._get_software_adapter()
            storage_iscsi_config.hardware_adapters = self._get_hardware_adapters()
        return storage_iscsi_config

    def _get_hardware_adapters(self) -> List[StorageISCSIHardwareAdapter]:
        """
        Retrieve the hardware adapters information.
        :return: list of hardware adapters.
        :rtype: :class:'list(:class:'StorageISCSIHardwareAdapter')'
        """
        logger.info(F"Populating the storage_iscsi config: hardware_adapters for host: {self.host_ref.name}")
        get_hardware_adapters = list()
        for host_adapter in self.host_ref.config.storageDevice.hostBusAdapter:
            if host_adapter.driver in SUPPORTED_HARDWARE_ADAPTER_DRIVERS:
                hardware_adapter_info = StorageISCSIHardwareAdapter()
                self._set_host_adapter_config(host_adapter, hardware_adapter_info)
                if host_adapter.isSoftwareBased:
                    hardware_adapter_info.type = AdapterType.DEPENDENT
                else:
                    hardware_adapter_info.type = AdapterType.INDEPENDENT
                    hardware_adapter_info.independent_networking = \
                        self._get_independent_networking(host_adapter.ipProperties)
                hardware_adapter_info.vmhba = host_adapter.device
                get_hardware_adapters.append(hardware_adapter_info)
        return get_hardware_adapters

    def _get_software_adapter(self) -> StorageISCSISoftwareAdapter:
        """
        Retrieve the software adapter information.
        :return: the software adapter
        :rtype: 'StorageISCSISoftwareAdapter'
        """
        logger.info(F"Populating the storage_iscsi config: software_adapter for host: {self.host_ref.name}")
        software_adapter_info = StorageISCSISoftwareAdapter()
        software_adapter_info.enabled = self.host_ref.config.storageDevice.softwareInternetScsiEnabled
        if self.host_ref.config.storageDevice.softwareInternetScsiEnabled:
            for host_adapter in self.host_ref.config.storageDevice.hostBusAdapter:
                if host_adapter.driver == SUPPORTED_SOFTWARE_ADAPTER_DRIVER:
                    self._set_host_adapter_config(host_adapter, software_adapter_info)
        return software_adapter_info

    def _set_host_adapter_config(self, host_adapter: vim.host.HostBusAdapter, adapter_info: BaseAdapter):
        """
        Sets the host adapter config on adapter info.
        :param host_adapter: the host adapter from Mob
        :type host_adapter: 'vim.host.HostBusAdapter'
        :param adapter_info: the host adapter information
        :type adapter_info: 'BaseAdapter' properties of software or hardware adapter.
        """
        adapter_info.iqn = host_adapter.iScsiName
        adapter_info.alias = host_adapter.iScsiAlias
        try:
            vnics = self.host_ref.configManager.iscsiManager.QueryBoundVnics(host_adapter.device)
            if len(vnics) > 0:
                adapter_info.vmknics = list()
                for vnic in vnics:
                    adapter_info.vmknics.append(vnic.vnicDevice)
        except Exception as e:
            logger.error(F"Exception retrieving bound vcnics for host: {self.host_ref.name} with error msg: {e}")
        if host_adapter.authenticationProperties and host_adapter.authenticationProperties.chapAuthEnabled:
            adapter_info.chap_authentication = self._get_chap_authentication(host_adapter.authenticationProperties)
        if len(host_adapter.configuredSendTarget) > 0:
            adapter_info.discovery_send_targets = list()
            for configured_send_targets in host_adapter.configuredSendTarget:
                adapter_info.discovery_send_targets.append(
                    self._get_discovery_targets(configured_send_targets, TargetType.SENDTARGET))
        if len(host_adapter.configuredStaticTarget) > 0:
            adapter_info.targets = list()
            for configured_static_targets in host_adapter.configuredStaticTarget:
                adapter_info.targets.append(
                    self._get_discovery_targets(configured_static_targets, TargetType.STATIC))
        self._set_digest_properties(host_adapter.digestProperties, adapter_info)
        self._set_advanced_options(host_adapter.advancedOptions, adapter_info)

    def _get_independent_networking(self,
                                    ip_properties: vim.host.InternetScsiHba.IPProperties) -> IndependentNetworking:
        """
        Gets the networking properties for independent hardware adapter.
        :param ip_properties: The IP properties of the hardware adapter.
        :type ip_properties: 'vim.host.InternetScsiHba.IPProperties'
        :return: the ip properties in Independent networking object.
        :rtype: 'IndependentNetworking'
        """
        independent_networking = IndependentNetworking()
        if not ip_properties.ipv4Enabled:
            independent_networking.ipv4_option = IpV4Option.NO_IPV4
        else:
            if ip_properties.dhcpConfigurationEnabled:
                independent_networking.ipv4_option = IpV4Option.DHCP
            elif ip_properties.address:
                independent_networking.ipv4_option = IpV4Option.STATIC
            ipv4 = IpV4()
            ipv4.address = ip_properties.address
            ipv4.subnet_mask = ip_properties.subnetMask
            ipv4.gateway = ip_properties.defaultGateway
            independent_networking.ipv4 = ipv4

        if not ip_properties.ipv6Enabled or not ip_properties.ipv6properties:
            independent_networking.ipv6_option = IpV6Option.NO_IPV6
        else:
            ipv6properties = ip_properties.ipv6properties
            if ipv6properties.ipv6DhcpConfigurationEnabled:
                independent_networking.ipv6_option = IpV6Option.DHCPV6
            elif ipv6properties.ipv6RouterAdvertisementConfigurationEnabled:
                independent_networking.ipv6_option = IpV6Option.RA
            else:
                independent_networking.ipv6_option = IpV6Option.STATIC

            ipv6 = IpV6()
            if ipv6properties.ipv6DefaultGateway:
                ipv6.gateway = ipv6properties.ipv6DefaultGateway
            elif ip_properties.ipv6DefaultGateway:
                ipv6.gateway = ip_properties.ipv6DefaultGateway

            iscsi_ipv6_address: vim.host.InternetScsiHba.IscsiIpv6Address
            for iscsi_ipv6_address in ipv6properties.iscsiIpv6Address:
                ipv6_address = IpAddress()
                ipv6_address.address = iscsi_ipv6_address.address
                ipv6_address.prefix_length = iscsi_ipv6_address.prefixLength
                if iscsi_ipv6_address.origin != "Other" and self._is_link_local_address(ipv6_address):
                    independent_networking.link_local_address = ipv6_address
                else:
                    if not ipv6.addresses:
                        ipv6.addresses = list()
                    ipv6.addresses.append(ipv6_address)
            independent_networking.ipv6 = ipv6

        independent_networking.primary_dns = ip_properties.primaryDnsServerAddress
        independent_networking.secondary_dns = ip_properties.alternateDnsServerAddress
        independent_networking.mtu = ip_properties.mtu
        independent_networking.arp_redirect = ip_properties.arpRedirectEnabled
        return independent_networking

    def _get_discovery_targets(self, configured_targets, target_type: TargetType) -> Target:
        """
        Retrieve the discovery targets.
        :param configured_targets: the configured targets.
        :type configured_targets: 'InternetScsiHba.SendTarget' or 'InternetScsiHba.StaticTarget'
        :param target_type: STATIC or SENDTARGET
        :type target_type: 'TargetType
        :return: static or send target.
        :rtype: 'Target'
        """
        discovery_send_targets_info = Target()
        discovery_send_targets_info.type = target_type
        discovery_send_targets_info.address = configured_targets.address
        discovery_send_targets_info.port = configured_targets.port
        if configured_targets.authenticationProperties and \
                configured_targets.authenticationProperties.chapAuthEnabled:
            discovery_send_targets_info.chap_authentication = self._get_chap_authentication(
                configured_targets.authenticationProperties)
        self._set_digest_properties(configured_targets.digestProperties, discovery_send_targets_info)
        self._set_advanced_options(configured_targets.advancedOptions, discovery_send_targets_info)
        return discovery_send_targets_info

    @staticmethod
    def _get_chap_authentication(
            authentication_properties: vim.host.InternetScsiHba.AuthenticationProperties) -> ChapAuthentication:
        """
        Retrieve the chap authentication properties.
        :param authentication_properties: the authentication properties.
        :type authentication_properties: 'vim.host.InternetScsiHba.AuthenticationProperties'
        :return: the chap authentication.
        :rtype: 'ChapAuthentication'
        """
        chap_authentication = ChapAuthentication()
        chap_authentication.uni_chap_level = ChapAuthenticationType(authentication_properties.chapAuthenticationType)
        credentials = Credentials()
        credentials.username = authentication_properties.chapName
        credentials.password = authentication_properties.chapSecret
        chap_authentication.uni_chap_auth_credentials = credentials
        mutual_chap_auth = MutualChapAuth()
        mutual_chap_auth.level = ChapAuthenticationType(authentication_properties.mutualChapAuthenticationType)
        mutual_chap_auth.credentials = Credentials()
        mutual_chap_auth.credentials.username = authentication_properties.mutualChapName
        mutual_chap_auth.credentials.password = authentication_properties.mutualChapSecret
        chap_authentication.mutual_chap_auth = mutual_chap_auth
        return chap_authentication

    @staticmethod
    def _set_digest_properties(digest_properties: vim.host.InternetScsiHba.DigestProperties, info):
        """
        Sets the digest properties.
        :param digest_properties: the digest properties.
        :type digest_properties: 'vim.host.InternetScsiHba.DigestProperties'
        :param info: 'BaseAdapter' properties of software or hardware adapter.
        :type info: 'BaseAdapter'
        """
        info.header_digest_level = DigestLevel(digest_properties.headerDigestType)
        info.data_digest_level = DigestLevel(digest_properties.dataDigestType)

    @staticmethod
    def _set_advanced_options(advanced_options: List[vim.host.InternetScsiHba.ParamValue], info):
        """
        Sets the advanced options.
        :param advanced_options: the advanced options.
        :type advanced_options: :class:'List[vim.host.InternetScsiHba.ParamValue]'
        :param info: 'BaseAdapter' properties of software or hardware adapter.
        :type info: 'BaseAdapter'
        """
        for option in advanced_options:
            if option.key == "ErrorRecoveryLevel":
                setattr(info, advanced_options_map.get(option.key, option.key), ErrorRecoveryLevel(option.value))
            else:
                setattr(info, advanced_options_map.get(option.key, option.key), option.value)

    @staticmethod
    def _is_link_local_address(ipv6_address: IpAddress) -> bool:
        """
        Checks if IPv6 address is a link local address i.e. of the type fe80::/10 (fe80:: through febf::)
        Link local address always has prefix of 64.
        :param ipv6_address: the address to check.
        :type ipv6_address: IpAddress
        :return: true if address is a link local one.
        :rtype: :class:'bool'
        """
        if not ipv6_address.address or ipv6_address.prefix_length != 64 or len(ipv6_address.address) < 4:
            return False
        address_start = int(ipv6_address.address[:4], 16)
        return address_start & 0xffc0 == 0xfe80

