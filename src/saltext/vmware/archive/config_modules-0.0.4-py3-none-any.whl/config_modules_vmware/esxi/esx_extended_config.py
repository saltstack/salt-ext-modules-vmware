# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging

from config_modules_vmware.lib.common import consts
from config_modules_vmware.utils.json_spec_utils import JSONSpecUtils
from config_modules_vmware.utils.config_manipulation import Operations, SetStatus, ConfigManipulation
from config_modules_vmware.esxi.ouput_models.esx_compliance_response import EsxComplianceResponse
from config_modules_vmware.esxi.ouput_models.esx_precheck_response import EsxPrecheckResponse
from config_modules_vmware.esxi.ouput_models.esx_remediate_response import EsxRemediateResponse
from config_modules_vmware.esxi.esx_config_utility import Action, EsxConfigUtility

logger = logging.getLogger(__name__)

class EsxExtendedConfig:

    @staticmethod
    def _process_extended_config(host_moids, context, extended_config, response_obj, operation):
        """
        Process extended configuration for a list of hosts.

        :param host_moids: List of host moids (string)
        :param context: The context object.
        :param extended_config: dict, Extended configuration data
        :param response_obj: Response object to update.
        :param operation: The operation type (Action.CHECK_COMPLIANCE, Action.PRECHECK, Action.SET).

        :return: response_obj: Updated response object of the input class
        """

        host_configs_map = EsxConfigUtility.flatten_config_by_host(data={consts.EXTENDED_CONFIG: extended_config})
        vc_vmomi_client = context.vc_vmomi_client()
        for host_moid in host_moids:
            host_ref = vc_vmomi_client.get_host_ref_for_moid(host_moid)
            host_uuid = host_ref.hardware.systemInfo.uuid
            config_mapping = EsxConfigUtility.create_config_mapping(
                {consts.EXTENDED_CONFIG: host_configs_map[host_uuid]})
            host_desired_extended_config = {consts.EXTENDED_CONFIG: host_configs_map[host_uuid]}

            # For remediation we dont need to get and find differences and then apply
            # This will be taken care by ConfigManipulation.SET

            if operation == Action.SET:
                logger.debug("Remediating host_moid: %s", host_moid)
                host_remediate_ext_config_response = ConfigManipulation.operate(
                    context, host_ref, config_mapping, Operations.SET, apply_values=host_desired_extended_config)

                # Mapping template should maintain three list SUCCESS, FAILED, SKIPPED
                # For unchanged it should put under SKIPPED
                if 'SUCCESS' in host_remediate_ext_config_response:
                    success_paths = host_remediate_ext_config_response['SUCCESS']
                    response_obj.update_host_notification_info(host_moid, host_ref.name, success_paths)
                else:
                    # Create a host entry in failure or skip case as well
                    response_obj.update_host_notification_info(host_moid, host_ref.name, [])

                    # TODO: Handle failure/skip cases and manipulating response accordingly
                    # Need to update errors, warnings

            else:
                host_current_extended_config = ConfigManipulation.operate(context, host_ref,
                                                                          config_mapping, Operations.GET)
                differences = JSONSpecUtils.compare_specs_and_report_differences(host_current_extended_config,
                                                                                 host_desired_extended_config)
                if differences:
                    if operation == Action.CHECK_COMPLIANCE:
                        logger.debug("Differences found for host_moid: %s", host_moid)
                        # All the extended configs are of set category so adding it to set list
                        response_obj.add_to_non_compliant_hosts(host_moid)
                        response_obj.update_host_compliance(host_moid, host_ref.name, "sets", differences)
                    elif operation == Action.PRECHECK:
                        # host_precheck_response_configs = ConfigManipulation.operate(context, host_ref, config_mapping,
                        #                               Operations.PRECHECK, apply_values=host_desired_extended_config)
                        # Currently precheck is not performed for extended configs and is considered a pass
                        # Update host impact info section in the Precheck Response
                        response_obj.update_host_impact_info(host_moid, host_ref.name, differences)
                        # TODO: Precheck on the extended configs and handling the response
                    else:
                        logger.error("Unknown operation for the host %s", host_moid)

        return response_obj

    @staticmethod
    def check_compliance_extended_config(host_moids, context,
                                         extended_config, response_obj: EsxComplianceResponse):
        """
        Check compliance for a list of hosts for extended configs.

        :param host_moids: List of host moids (string)
        :param context: The context object.
        :param extended_config: dict, Extended configuration data.
        :param response_obj: EsxComplianceResponse to update.

        :return: response_obj: Updated EsxComplianceResponse.
        """

        logger.debug("Checking compliance for hosts: %s", host_moids)
        return EsxExtendedConfig._process_extended_config(host_moids, context, extended_config,
                                                          response_obj, Action.CHECK_COMPLIANCE)

    @staticmethod
    def precheck_extended_config(host_moids, context,
                                 extended_config, response_obj: EsxPrecheckResponse):
        """
        Perform precheck for a list of hosts for extended configs.

        :param host_moids: List of host moids (string)
        :param context:
        :param extended_config:dict, Extended configuration data.
        :param response_obj: EsxPrecheckResponse to update.

        :return: response_obj: Updated EsxPrecheckResponse.
        """

        logger.debug("Performing precheck for hosts: %s", host_moids)
        return EsxExtendedConfig._process_extended_config(host_moids, context,
                                                          extended_config, response_obj, Action.PRECHECK)

    @staticmethod
    def remediate_extended_config(host_moids, context,
                                  extended_config, response_obj: EsxRemediateResponse):
        """
        Remediate a list of hosts for extended configs

        :param host_moids: List of host moids (string)
        :param context:
        :param extended_config: dict, Extended configuration data.
        :param response_obj: EsxRemediateResponse to update.

        :return: response_obj: Updated EsxRemediateResponse.
        """
        logger.debug("Remediating for hosts: %s", host_moids)
        return EsxExtendedConfig._process_extended_config(host_moids, context,
                                                          extended_config, response_obj, Action.SET)