# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum

from config_modules_vmware.esxi.utils.formatters.vlcm_formatter import VlcmFormatter


class Formatters(Enum):
    '''
    Enum Class to define config formatters
    '''
    VLCM_FORMATTER = VlcmFormatter

