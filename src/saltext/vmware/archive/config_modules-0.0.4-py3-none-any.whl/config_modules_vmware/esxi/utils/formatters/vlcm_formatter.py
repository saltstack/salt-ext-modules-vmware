from config_modules_vmware.interfaces.formatter_interface import FormatterInterface


class VlcmFormatter(FormatterInterface):

    @staticmethod
    def format(host_configs: dict, reference_host_uuid: str = None) -> dict:
        '''
        Takes in a dictionary of hosts and a reference host uuid and returns the config in a format that is
        in line with vlcm
        '''
        if reference_host_uuid is None:
            reference_host_uuid = VlcmFormatter._get_reference_host(host_configs)
        vlcm_format = {}
        if host_configs[reference_host_uuid].get("config") is not None:
            vlcm_format['config'] = VlcmFormatter._get_config(host_configs, reference_host_uuid=reference_host_uuid)
        if host_configs[reference_host_uuid].get('extended_config') is not None:
            vlcm_format['extended_config'] = VlcmFormatter._get_extended_config(host_configs,
                                                                                reference_host_uuid=reference_host_uuid)
        return vlcm_format


    @staticmethod
    def _get_overrides(reference_properties: dict, comparison_properties: dict) -> dict:
        '''
        Takes in a reference host and a host to compare it to and returns the properties from the comparison host
        that are different from the reference host
        '''
        override_properties = {}
        groups = list(set(list(reference_properties.keys()) + list(comparison_properties.keys())))
        for group in groups:
            overrides = {}
            if group not in comparison_properties:
                override_properties[group] = 'DEFAULT'
            elif group not in reference_properties:
                override_properties[group] = comparison_properties[group]
            else:
                props = list(set(list(reference_properties[group].keys()) + list(comparison_properties[group].keys())))
                for prop in props:
                    if prop not in comparison_properties[group]:
                        overrides[prop] = 'DEFAULT'
                    elif prop not in reference_properties[group]:
                        overrides[prop] = comparison_properties[group][prop]
                    elif reference_properties[group][prop] != comparison_properties[group][prop]:
                        overrides[prop] = comparison_properties[group][prop]

            if len(overrides) > 0:
                override_properties[group] = overrides

        # If there aren't any differences we can just return the empty object
        return override_properties


    @staticmethod
    def _get_config(host_configs: dict, reference_host_uuid: str) -> dict:
        '''
        Takes in the hosts and the reference host uuid and returns the config section of the vlcm format
        '''
        host_overrides = {}
        config = {
            'profile': host_configs[reference_host_uuid]['config']['profile'],
            'metadata': {
                'reference_host': {
                    "uuid": reference_host_uuid
                }}
        }
        for host_uuid in host_configs:
            if host_uuid != reference_host_uuid:
                overrides = VlcmFormatter._get_overrides(
                    host_configs[reference_host_uuid]['config']['profile']['esx'],
                    host_configs[host_uuid]['config']['profile']['esx'])
                if len(overrides) > 0:
                    esx_overrides = {'esx': overrides}
                    host_overrides[host_uuid] = esx_overrides
        if len(host_overrides) > 0:
            config['host-override'] = host_overrides

        return config

    @staticmethod
    def _get_extended_config(host_configs: dict, reference_host_uuid: str) -> dict:
        '''
        Takes in the hosts and a reference host and returns the extended_config section of the vlcm format
        '''
        host_overrides = {}
        extended_config = {
            'profile': host_configs[reference_host_uuid]['extended_config']['profile'],
            'metadata': {
                'reference_host': {
                    "uuid": reference_host_uuid
                }
            }
        }
        for host_uuid in host_configs:
            if host_uuid != reference_host_uuid:
                overrides = VlcmFormatter._get_overrides(
                    host_configs[reference_host_uuid]['extended_config']['profile']['esx'],
                    host_configs[host_uuid]['extended_config']['profile']['esx'])
                if len(overrides) > 0:
                    esx_overrides = {'esx': overrides}
                    host_overrides[host_uuid] = esx_overrides

        if len(host_overrides) > 0:
            extended_config['host-override'] = host_overrides
        return extended_config

    @staticmethod
    def _get_reference_host(hosts: dict) -> dict:
        '''
        Takes in the hosts and returns a reference host to be used for comparisons
        '''
        hosts_uuids = sorted(hosts.keys())
        return hosts_uuids[0]

