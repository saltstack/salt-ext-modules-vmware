# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import copy
from config_modules_vmware.lib.common import consts
from config_modules_vmware.utils.config_manipulation import ConfigManipulation
from enum import Enum

class Action(Enum):
    """
    Enum Class to define operation to be
    performed on extended configs
    """
    CHECK_COMPLIANCE = "check_compliance"
    PRECHECK = "precheck"
    SET = "set"

class EsxConfigUtility:

    @staticmethod
    def flatten_config_by_host(data):
        """
        Flatten configuration data by host.

        :param data: dict, The input configuration data.
        :return: dict, Flattened configuration data.
        """
        if data is None:
            return {}

        def get_uuids(data):
            uuids = set()
            reference_host_uuid = data[consts.EXTENDED_CONFIG][consts.METADATA]["reference_host"]["uuid"]
            uuids.add(reference_host_uuid)

            if consts.HOST_OVERRIDE in data[consts.EXTENDED_CONFIG]:
                host_override = data[consts.EXTENDED_CONFIG][consts.HOST_OVERRIDE]
                uuids.update(host_override.keys())

            return uuids

        def update_dict(source, overrides):
            for key, value in overrides.items():
                if isinstance(value, dict):
                    source[key] = update_dict(source.get(key, {}), value)
                else:
                    source[key] = value
            return source

        def create_uuid_profiles(data, uuids):
            common_profile = data[consts.EXTENDED_CONFIG][consts.PROFILE][consts.ESX]
            uuid_profiles = {uuid: copy.deepcopy(common_profile) for uuid in uuids}
            return uuid_profiles

        def update_uuid_profiles(uuid_profiles, host_override):
            for uuid, profile in uuid_profiles.items():
                if host_override and uuid in host_override:
                    esx_profile = host_override[uuid].get(consts.ESX, {})
                    update_dict(profile, esx_profile)
            return uuid_profiles

        uuids = get_uuids(data)
        uuid_profiles = create_uuid_profiles(data, uuids)

        if consts.HOST_OVERRIDE in data[consts.EXTENDED_CONFIG]:
            update_uuid_profiles(uuid_profiles, data[consts.EXTENDED_CONFIG][consts.HOST_OVERRIDE])

        flattened_config = {}
        for uuid, profile in uuid_profiles.items():
            flattened_config[uuid] = {consts.PROFILE: {consts.ESX: profile}}

        return flattened_config

    @staticmethod
    def merge_config(reference, subset):
        """
        Merge a subset of configuration data into a reference configuration.

        :param reference: dict, The reference configuration data.
        :param subset: dict, The subset of configuration data to merge.
        :return: dict, Merged configuration data.
        """
        result = {}
        for key, value in subset.items():
            if isinstance(value, dict) and key in reference:
                result[key] = EsxConfigUtility.merge_config(reference[key], value)
            elif key in reference:
                result[key] = reference[key]
        return result

    @staticmethod
    def create_config_mapping(subset_config):
        """
        Create a configuration mapping by merging a subset configuration into a template.

        :param subset_config: dict, The subset of configuration data to merge.
        :return: dict, Merged configuration mapping.
        """
        reference_config_template = ConfigManipulation.get_config_mapping_template()
        return EsxConfigUtility.merge_config(reference_config_template, subset_config)

class VLCMResponseValidator:
    """
    Class for basic validations on response from VLCM APIs
    """
    @staticmethod
    def _check_basic_response(response_json, response_type: Action) -> bool:
        """
        Check if a basic response JSON object contains the expected structure.
        This function checks whether the provided JSON response has the expected structure,
        which includes the presence of a "result" field. It is used to validate responses
        from various sources and log errors if the structure is not as expected.
        :param response_json: dict
        :param response_type: Action enum value
        :return: bool
        """
        if response_json is None:
            logger.error(f"Empty response from {response_type.value}")
            return False
        result = response_json.get(consts.RESULT)
        if result is None:
            logger.error(f"Result is missing from {response_type.value} response")
            return False
        return True

    @staticmethod
    def is_check_compliance_response_vlcm_valid(compliance_vlcm_response) -> bool:
        """
        This function checks whether the provided JSON response from a cluster compliance check
        has the expected structure, including the presence of required keys such as "summary"
        and "cluster_status".
        :param compliance_vlcm_response: dict
        :return: bool
        """
        if not VLCMResponseValidator._check_basic_response(compliance_vlcm_response, Action.CHECK_COMPLIANCE):
            return False
        required_keys = [consts.SUMMARY, consts.CLUSTER_STATUS]
        if not all(key in compliance_vlcm_response[consts.RESULT] for key in required_keys):
            missing_keys = [key for key in required_keys
                            if key not in compliance_vlcm_response[consts.RESULT]]
            logger.error(f"One or more keys in the set: "
                         f"{missing_keys} is missing in the 'result' section of check compliance response")
            return False
        return True

    @staticmethod
    def is_precheck_vlcm_response_valid(precheck_vlcm_response) -> bool:
        """
        This function checks whether the provided JSON response from a cluster precheck
        has the expected structure, including the presence of required keys such as "summary"
        and "host_precheck".
        :param precheck_vlcm_response: dict
        :return: bool
        """
        if not VLCMResponseValidator._check_basic_response(precheck_vlcm_response, Action.PRECHECK):
            return False
        required_keys = [consts.SUMMARY, consts.HOST_PRECHECK]
        if not all(key in precheck_vlcm_response[consts.RESULT] for key in required_keys):
            missing_keys = [key for key in required_keys if key not in precheck_vlcm_response[consts.RESULT]]
            logger.error(f"One or more keys in the set: "
                         f"{missing_keys} is missing in the 'result' section of precheck response")
            return False
        return True

    @staticmethod
    def is_remediate_vlcm_response_valid(remediate_vlcm_response) -> bool:
        """
        This function checks whether the provided JSON response from a cluster remediate
        has the expected structure, including the presence of required keys such as "host_status"
        :param remediate_vlcm_response: dict
        :return: bool
        """
        if not VLCMResponseValidator._check_basic_response(remediate_vlcm_response, Action.SET):
            return False
        required_keys = [consts.HOST_STATUS]
        if not all(key in remediate_vlcm_response[consts.RESULT] for key in required_keys):
            missing_keys = [key for key in required_keys if key not in remediate_vlcm_response[consts.RESULT]]
            logger.error(f"One or more keys in the set: "
                         f"{missing_keys} is missing in the 'result' section of remediate response")
            return False
        return True