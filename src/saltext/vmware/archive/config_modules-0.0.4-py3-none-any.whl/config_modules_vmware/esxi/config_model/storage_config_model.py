# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum
from typing import List

from config_modules_vmware.esxi.config_model.base_model import BaseModel


class AuthType(BaseModel, Enum):
    AUTH_SYS = 'AUTH_SYS'
    SEC_KRB5 = 'SEC_KRB5'
    SEC_KRB5I = 'SEC_KRB5I'


class State(BaseModel, Enum):
    ACTIVE = 'ACTIVE'
    OFF = 'OFF'


class Policy(BaseModel, Enum):
    DEFAULT = 'DEFAULT'
    BYTES = 'BYTES'
    IOPS = 'IOPS'
    LATENCY = 'LATENCY'


class Plugin(BaseModel, Enum):
    NMP = 'NMP'
    HPP = 'HPP'
    MASK_PATH = 'MASK_PATH'
    THIRD_PARTY_MPP = 'THIRD_PARTY_MPP'


class Scheme(BaseModel, Enum):
    LB_RR = 'LB_RR'
    LB_IOPS = 'LB_IOPS'
    LB_BYTES = 'LB_BYTES'
    LB_LATENCY = 'LB_LATENCY'
    FIXED = 'FIXED'


class CriteriaType(BaseModel, Enum):
    DEVICE = 'DEVICE'
    VENDOR = 'VENDOR'
    LOCATION = 'LOCATION'
    DRIVER = 'DRIVER'
    TRANSPORT = 'TRANSPORT'
    TARGET = 'TARGET'


class BlockDeviceState(BaseModel, Enum):
    ON = 'ON'
    OFF = 'OFF'


class PspType(BaseModel, Enum):
    VMW_PSP_RR = 'VMW_PSP_RR'
    VMW_PSP_FIXED = 'VMW_PSP_FIXED'
    VMW_PSP_MRU = 'VMW_PSP_MRU'
    THIRD_PARTY_PSP = 'THIRD_PARTY_PSP'


class SatpType(BaseModel, Enum):
    VMW_SATP_ALUA_CX = 'VMW_SATP_ALUA_CX'
    VMW_SATP_CX = 'VMW_SATP_CX'
    VMW_SATP_ALUA = 'VMW_SATP_ALUA'
    VMW_SATP_MSA = 'VMW_SATP_MSA'
    VMW_SATP_DEFAULT_AP = 'VMW_SATP_DEFAULT_AP'
    VMW_SATP_SVC = 'VMW_SATP_SVC'
    VMW_SATP_EQL = 'VMW_SATP_EQL'
    VMW_SATP_INV = 'VMW_SATP_INV'
    VMW_SATP_EVA = 'VMW_SATP_EVA'
    VMW_SATP_SYMM = 'VMW_SATP_SYMM'
    VMW_SATP_LSI = 'VMW_SATP_LSI'
    VMW_SATP_DEFAULT_AA = 'VMW_SATP_DEFAULT_AA'
    VMW_SATP_LOCAL = 'VMW_SATP_LOCAL'
    THIRD_PARTY_SATP = 'THIRD_PARTY_SATP'


class TargetType(BaseModel, Enum):
    FC = 'FC'
    ISCSI = 'ISCSI'


class Transport(BaseModel, Enum):
    BLOCK = 'BLOCK'
    FC = 'FC'
    ISCSI = 'ISCSI'
    ISCSIVENDOR = 'ISCSIVENDOR'
    IDE = 'IDE'
    SAS = 'SAS'
    SATA = 'SATA'
    USB = 'USB'
    PARALLEL = 'PARALLEL'
    FCOE = 'FCOE'
    PCIE = 'PCIE'
    RDMA = 'RDMA'
    TCP = 'TCP'
    UNKNOWN = 'UNKNOWN'


class Target(BaseModel):

    def __init__(self, target: TargetType = None, iqn: str = None, lun: int = None, wwnn: str = None, wwpn: str = None):
        self._target: TargetType = target
        self._iqn: str = iqn
        self._lun: int = lun
        self._wwnn: str = wwnn
        self._wwpn: str = wwpn

    @property
    def target(self) -> TargetType:
        """
        Return the target.
        :return: target
        :rtype: TargetType
        """
        return self._target

    @target.setter
    def target(self, target: TargetType):
        """
        Set the target.
        :param target: target
        :type target: TargetType
        """
        self._target = target

    @property
    def iqn(self) -> str:
        """
        Return the iqn.
        :return: iqn
        :rtype: str
        """
        return self._iqn

    @iqn.setter
    def iqn(self, iqn: str):
        """
        Set the iqn.
        :param iqn: iqn
        :type iqn: str
        """
        self._iqn = iqn

    @property
    def lun(self) -> int:
        """
        Return the lun.
        :return: lun
        :rtype: int
        """
        return self._lun

    @lun.setter
    def lun(self, lun: int):
        """
        Set the lun.
        :param lun: lun
        :type lun: int
        """
        self._lun = lun

    @property
    def wwnn(self) -> str:
        """
        Return the wwnn.
        :return: wwnn
        :rtype: str
        """
        return self._wwnn

    @wwnn.setter
    def wwnn(self, wwnn: str):
        """
        Set the wwnn.
        :param wwnn: wwnn
        :type wwnn: str
        """
        self._wwnn = wwnn

    @property
    def wwpn(self) -> str:
        """
        Return the wwpn.
        :return: wwpn
        :rtype: str
        """
        return self._wwpn

    @wwpn.setter
    def wwpn(self, wwpn: str):
        """
        Set the wwpn.
        :param wwpn: wwpn
        :type wwpn: str
        """
        self._wwpn = wwpn


class Location(BaseModel):

    def __init__(self, lun: int = None, target: int = None, adapter: str = None, channel: int = None):
        self._lun: int = lun
        self._target: int = target
        self._adapter: str = adapter
        self._channel: int = channel

    @property
    def lun(self) -> int:
        """
        Return the lun.
        :return: lun
        :rtype: int
        """
        return self._lun

    @lun.setter
    def lun(self, lun: int):
        """
        Set the lun.
        :param lun: lun
        :type lun: int
        """
        self._lun = lun

    @property
    def target(self) -> int:
        """
        Return the target.
        :return: target
        :rtype: int
        """
        return self._target

    @target.setter
    def target(self, target: int):
        """
        Set the target.
        :param target: target
        :type target: int
        """
        self._target = target

    @property
    def adapter(self) -> str:
        """
        Return the adapter.
        :return: adapter
        :rtype: str
        """
        return self._adapter

    @adapter.setter
    def adapter(self, adapter: str):
        """
        Set the adapter.
        :param adapter: adapter
        :type adapter: str
        """
        self._adapter = adapter

    @property
    def channel(self) -> int:
        """
        Return the channel.
        :return: channel
        :rtype: int
        """
        return self._channel

    @channel.setter
    def channel(self, channel: int):
        """
        Set the channel.
        :param channel: channel
        :type channel: int
        """
        self._channel = channel


class Vendor(BaseModel):

    def __init__(self, model: str = None, vendor: str = None, pci_vendor_id: str = None, pci_sub_vendor_id: str = None,
                 nvme_controller_model: str = None):
        self._model: str = model
        self._vendor: str = vendor
        self._pci_vendor_id: str = pci_vendor_id
        self._pci_sub_vendor_id: str = pci_sub_vendor_id
        self._nvme_controller_model: str = nvme_controller_model

    @property
    def model(self) -> str:
        """
        Return the model.
        :return: model
        :rtype: str
        """
        return self._model

    @model.setter
    def model(self, model: str):
        """
        Set the model.
        :param model: model
        :type model: str
        """
        self._model = model

    @property
    def vendor(self) -> str:
        """
        Return the vendor.
        :return: vendor
        :rtype: str
        """
        return self._vendor

    @vendor.setter
    def vendor(self, vendor: str):
        """
        Set the vendor.
        :param vendor: vendor
        :type vendor: str
        """
        self._vendor = vendor

    @property
    def pci_vendor_id(self) -> str:
        """
        Return the pci_vendor_id.
        :return: pci_vendor_id
        :rtype: str
        """
        return self._pci_vendor_id

    @pci_vendor_id.setter
    def pci_vendor_id(self, pci_vendor_id: str):
        """
        Set the pci_vendor_id.
        :param pci_vendor_id: pci_vendor_id
        :type pci_vendor_id: str
        """
        self._pci_vendor_id = pci_vendor_id

    @property
    def pci_sub_vendor_id(self) -> str:
        """
        Return the pci_sub_vendor_id.
        :return: pci_sub_vendor_id
        :rtype: str
        """
        return self._pci_sub_vendor_id

    @pci_sub_vendor_id.setter
    def pci_sub_vendor_id(self, pci_sub_vendor_id: str):
        """
        Set the pci_sub_vendor_id.
        :param pci_sub_vendor_id: pci_sub_vendor_id
        :type pci_sub_vendor_id: str
        """
        self._pci_sub_vendor_id = pci_sub_vendor_id

    @property
    def nvme_controller_model(self) -> str:
        """
        Return the nvme_controller_model.
        :return: nvme_controller_model
        :rtype: str
        """
        return self._nvme_controller_model

    @nvme_controller_model.setter
    def nvme_controller_model(self, nvme_controller_model: str):
        """
        Set the nvme_controller_model.
        :param nvme_controller_model: nvme_controller_model
        :type nvme_controller_model: str
        """
        self._nvme_controller_model = nvme_controller_model


class Criteria(BaseModel):

    def __init__(self, type: CriteriaType = None, device: str = None, driver: str = None, vendor: Vendor = None,
                 options: str = None, target: Target = None, location: Location = None):
        self._type: CriteriaType = type
        self._device: str = device
        self._driver: str = driver
        self._vendor: Vendor = vendor
        self._options: str = options
        self._target: Target = target
        self._location: Location = location

    @property
    def type(self) -> CriteriaType:
        """
        Return the type.
        :return: type
        :rtype: CriteriaType
        """
        return self._type

    @type.setter
    def type(self, type: CriteriaType):
        """
        Set the type.
        :param type: type
        :type type: CriteriaType
        """
        self._type = type

    @property
    def device(self) -> str:
        """
        Return the device.
        :return: device
        :rtype: str
        """
        return self._device

    @device.setter
    def device(self, device: str):
        """
        Set the device.
        :param device: device
        :type device: str
        """
        self._device = device

    @property
    def driver(self) -> str:
        """
        Return the driver.
        :return: driver
        :rtype: str
        """
        return self._driver

    @driver.setter
    def driver(self, driver: str):
        """
        Set the driver.
        :param driver: driver
        :type driver: str
        """
        self._driver = driver

    @property
    def vendor(self) -> Vendor:
        """
        Return the vendor.
        :return: vendor
        :rtype: Vendor
        """
        return self._vendor

    @vendor.setter
    def vendor(self, vendor: Vendor):
        """
        Set the vendor.
        :param vendor: vendor
        :type vendor: Vendor
        """
        self._vendor = vendor

    @property
    def options(self) -> str:
        """
        Return the options.
        :return: options
        :rtype: str
        """
        return self._options

    @options.setter
    def options(self, options: str):
        """
        Set the options.
        :param options: options
        :type options: str
        """
        self._options = options

    @property
    def target(self) -> Target:
        """
        Return the target.
        :return: target
        :rtype: Target
        """
        return self._target

    @target.setter
    def target(self, target: Target):
        """
        Set the target.
        :param target: target
        :type target: Target
        """
        self._target = target

    @property
    def location(self) -> Location:
        """
        Return the location.
        :return: location
        :rtype: Location
        """
        return self._location

    @location.setter
    def location(self, location: Location):
        """
        Set the location.
        :param location: location
        :type location: Location
        """
        self._location = location


class NmpCriteria(Criteria):

    def __init__(self, transport: str = None):
        super().__init__()
        self._transport: str = transport

    @property
    def transport(self) -> str:
        """
        Return the transport.
        :return: transport
        :rtype: str
        """
        return self._transport

    @transport.setter
    def transport(self, transport: str):
        """
        Set the transport.
        :param transport: transport
        :type transport: str
        """
        self._transport = transport


class PsaMppClaimRuleCriteria(Criteria):

    def __init__(self, transport: Transport = None):
        super().__init__()
        self._transport: Transport = transport

    @property
    def transport(self) -> Transport:
        """
        Return the transport.
        :return: transport
        :rtype: Transport
        """
        return self._transport

    @transport.setter
    def transport(self, transport: Transport):
        """
        Set the transport.
        :param transport: transport
        :type transport: Transport
        """
        self._transport = transport


class Hpp(BaseModel):

    def __init__(self, iops: int = None, bytes: int = None, scheme: Scheme = None, use_ano: bool = None,
                 mark_ssd: bool = None, mark_local: bool = None, preferred_path: str = None,
                 latency_eval_time: int = None, num_sampling_cycles: int = None, policy: Policy = None):
        self._iops: int = iops
        self._bytes: int = bytes
        self._scheme: Scheme = scheme
        self._use_ano: bool = use_ano
        self._mark_ssd: bool = mark_ssd
        self._mark_local: bool = mark_local
        self._preferred_path: str = preferred_path
        self._latency_eval_time: int = latency_eval_time
        self._num_sampling_cycles: int = num_sampling_cycles
        self._policy: Policy = policy

    @property
    def iops(self) -> int:
        """
        Return the iops.
        :return: iops
        :rtype: int
        """
        return self._iops

    @iops.setter
    def iops(self, iops: int):
        """
        Set the iops.
        :param iops: iops
        :type iops: int
        """
        self._iops = iops

    @property
    def bytes(self) -> int:
        """
        Return the bytes.
        :return: bytes
        :rtype: int
        """
        return self._bytes

    @bytes.setter
    def bytes(self, bytes: int):
        """
        Set the bytes.
        :param bytes: bytes
        :type bytes: int
        """
        self._bytes = bytes

    @property
    def scheme(self) -> Scheme:
        """
        Return the scheme.
        :return: scheme
        :rtype: Scheme
        """
        return self._scheme

    @scheme.setter
    def scheme(self, scheme: Scheme):
        """
        Set the scheme.
        :param scheme: scheme
        :type scheme: Scheme
        """
        self._scheme = scheme

    @property
    def use_ano(self) -> bool:
        """
        Return the use_ano.
        :return: use_ano
        :rtype: bool
        """
        return self._use_ano

    @use_ano.setter
    def use_ano(self, use_ano: bool):
        """
        Set the use_ano.
        :param use_ano: use_ano
        :type use_ano: bool
        """
        self._use_ano = use_ano

    @property
    def mark_ssd(self) -> bool:
        """
        Return the mark_ssd.
        :return: mark_ssd
        :rtype: bool
        """
        return self._mark_ssd

    @mark_ssd.setter
    def mark_ssd(self, mark_ssd: bool):
        """
        Set the mark_ssd.
        :param mark_ssd: mark_ssd
        :type mark_ssd: bool
        """
        self._mark_ssd = mark_ssd

    @property
    def mark_local(self) -> bool:
        """
        Return the mark_local.
        :return: mark_local
        :rtype: bool
        """
        return self._mark_local

    @mark_local.setter
    def mark_local(self, mark_local: bool):
        """
        Set the mark_local.
        :param mark_local: mark_local
        :type mark_local: bool
        """
        self._mark_local = mark_local

    @property
    def preferred_path(self) -> str:
        """
        Return the preferred_path.
        :return: preferred_path
        :rtype: str
        """
        return self._preferred_path

    @preferred_path.setter
    def preferred_path(self, preferred_path: str):
        """
        Set the preferred_path.
        :param preferred_path: preferred_path
        :type preferred_path: str
        """
        self._preferred_path = preferred_path

    @property
    def latency_eval_time(self) -> int:
        """
        Return the latency_eval_time.
        :return: latency_eval_time
        :rtype: int
        """
        return self._latency_eval_time

    @latency_eval_time.setter
    def latency_eval_time(self, latency_eval_time: int):
        """
        Set the latency_eval_time.
        :param latency_eval_time: latency_eval_time
        :type latency_eval_time: int
        """
        self._latency_eval_time = latency_eval_time

    @property
    def num_sampling_cycles(self) -> int:
        """
        Return the num_sampling_cycles.
        :return: num_sampling_cycles
        :rtype: int
        """
        return self._num_sampling_cycles

    @num_sampling_cycles.setter
    def num_sampling_cycles(self, num_sampling_cycles: int):
        """
        Set the num_sampling_cycles.
        :param num_sampling_cycles: num_sampling_cycles
        :type num_sampling_cycles: int
        """
        self._num_sampling_cycles = num_sampling_cycles

    @property
    def policy(self) -> Policy:
        """
        Return the policy.
        :return: policy
        :rtype: Policy
        """
        return self._policy

    @policy.setter
    def policy(self, policy: Policy):
        """
        Set the policy.
        :param policy: policy
        :type policy: Policy
        """
        self._policy = policy


class ClaimRuleSettings(BaseModel):

    def __init__(self, plugin: str = None, force: bool = None, extended_xcopy_support: bool = None,
                 xcopy_use_array_values: bool = None, xcopy_max_transfer_size_kib: int = None,
                 xcopy_max_transfer_size_mib: int = None, xcopy_use_multiple_segments: bool = None):
        self._plugin: str = plugin
        self._force: bool = force
        self._extended_xcopy_support: bool = extended_xcopy_support
        self._xcopy_use_array_values: bool = xcopy_use_array_values
        self._xcopy_max_transfer_size_kib: int = xcopy_max_transfer_size_kib
        self._xcopy_max_transfer_size_mib: int = xcopy_max_transfer_size_mib
        self._xcopy_use_multiple_segments: bool = xcopy_use_multiple_segments

    @property
    def plugin(self) -> str:
        """
        Return the plugin.
        :return: plugin
        :rtype: str
        """
        return self._plugin

    @plugin.setter
    def plugin(self, plugin: str):
        """
        Set the plugin.
        :param plugin: plugin
        :type plugin: str
        """
        self._plugin = plugin

    @property
    def force(self) -> bool:
        """
        Return the force.
        :return: force
        :rtype: bool
        """
        return self._force

    @force.setter
    def force(self, force: bool):
        """
        Set the force.
        :param force: force
        :type force: bool
        """
        self._force = force

    @property
    def extended_xcopy_support(self) -> bool:
        """
        Return the extended_xcopy_support.
        :return: extended_xcopy_support
        :rtype: bool
        """
        return self._extended_xcopy_support

    @extended_xcopy_support.setter
    def extended_xcopy_support(self, extended_xcopy_support: bool):
        """
        Set the extended_xcopy_support.
        :param extended_xcopy_support: extended_xcopy_support
        :type extended_xcopy_support: bool
        """
        self._extended_xcopy_support = extended_xcopy_support

    @property
    def xcopy_use_array_values(self) -> bool:
        """
        Return the xcopy_use_array_values.
        :return: xcopy_use_array_values
        :rtype: bool
        """
        return self._xcopy_use_array_values

    @xcopy_use_array_values.setter
    def xcopy_use_array_values(self, xcopy_use_array_values: bool):
        """
        Set the xcopy_use_array_values.
        :param xcopy_use_array_values: xcopy_use_array_values
        :type xcopy_use_array_values: bool
        """
        self._xcopy_use_array_values = xcopy_use_array_values

    @property
    def xcopy_max_transfer_size_kib(self) -> int:
        """
        Return the xcopy_max_transfer_size_kib.
        :return: xcopy_max_transfer_size_kib
        :rtype: int
        """
        return self._xcopy_max_transfer_size_kib

    @xcopy_max_transfer_size_kib.setter
    def xcopy_max_transfer_size_kib(self, xcopy_max_transfer_size_kib: int):
        """
        Set the xcopy_max_transfer_size_kib.
        :param xcopy_max_transfer_size_kib: xcopy_max_transfer_size_kib
        :type xcopy_max_transfer_size_kib: int
        """
        self._xcopy_max_transfer_size_kib = xcopy_max_transfer_size_kib

    @property
    def xcopy_max_transfer_size_mib(self) -> int:
        """
        Return the xcopy_max_transfer_size_mib.
        :return: xcopy_max_transfer_size_mib
        :rtype: int
        """
        return self._xcopy_max_transfer_size_mib

    @xcopy_max_transfer_size_mib.setter
    def xcopy_max_transfer_size_mib(self, xcopy_max_transfer_size_mib: int):
        """
        Set the xcopy_max_transfer_size_mib.
        :param xcopy_max_transfer_size_mib: xcopy_max_transfer_size_mib
        :type xcopy_max_transfer_size_mib: int
        """
        self._xcopy_max_transfer_size_mib = xcopy_max_transfer_size_mib

    @property
    def xcopy_use_multiple_segments(self) -> bool:
        """
        Return the xcopy_use_multiple_segments.
        :return: xcopy_use_multiple_segments
        :rtype: bool
        """
        return self._xcopy_use_multiple_segments

    @xcopy_use_multiple_segments.setter
    def xcopy_use_multiple_segments(self, xcopy_use_multiple_segments: bool):
        """
        Set the xcopy_use_multiple_segments.
        :param xcopy_use_multiple_segments: xcopy_use_multiple_segments
        :type xcopy_use_multiple_segments: bool
        """
        self._xcopy_use_multiple_segments = xcopy_use_multiple_segments


class PsaMppClaimRulesSettings(BaseModel):

    def __init__(self, plugin: Plugin = None, hpp: Hpp = None, name: str = None, force: bool = None,
                 mark_local: bool = None, mark_remote: bool = None, third_party_config: str = None):
        self._plugin: Plugin = plugin
        self._hpp: Hpp = hpp
        self._name: str = name
        self._force: bool = force
        self._mark_local: bool = mark_local
        self._mark_remote: bool = mark_remote
        self._third_party_config: str = third_party_config

    @property
    def plugin(self) -> Plugin:
        """
        Return the plugin.
        :return: plugin
        :rtype: Plugin
        """
        return self._plugin

    @plugin.setter
    def plugin(self, plugin: Plugin):
        """
        Set the plugin.
        :param plugin: plugin
        :type plugin: Plugin
        """
        self._plugin = plugin

    @property
    def hpp(self) -> Hpp:
        """
        Return the hpp.
        :return: hpp
        :rtype: Hpp
        """
        return self._hpp

    @hpp.setter
    def hpp(self, hpp: Hpp):
        """
        Set the hpp.
        :param hpp: hpp
        :type hpp: Hpp
        """
        self._hpp = hpp

    @property
    def name(self) -> str:
        """
        Return the name.
        :return: name
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name: str):
        """
        Set the name.
        :param name: name
        :type name: str
        """
        self._name = name

    @property
    def force(self) -> bool:
        """
        Return the force.
        :return: force
        :rtype: bool
        """
        return self._force

    @force.setter
    def force(self, force: bool):
        """
        Set the force.
        :param force: force
        :type force: bool
        """
        self._force = force

    @property
    def mark_local(self) -> bool:
        """
        Return the mark_local.
        :return: mark_local
        :rtype: bool
        """
        return self._mark_local

    @mark_local.setter
    def mark_local(self, mark_local: bool):
        """
        Set the mark_local.
        :param mark_local: mark_local
        :type mark_local: bool
        """
        self._mark_local = mark_local

    @property
    def mark_remote(self) -> bool:
        """
        Return the mark_remote.
        :return: mark_remote
        :rtype: bool
        """
        return self._mark_remote

    @mark_remote.setter
    def mark_remote(self, mark_remote: bool):
        """
        Set the mark_remote.
        :param mark_remote: mark_remote
        :type mark_remote: bool
        """
        self._mark_remote = mark_remote

    @property
    def third_party_config(self) -> str:
        """
        Return the third_party_config.
        :return: third_party_config
        :rtype: str
        """
        return self._third_party_config

    @third_party_config.setter
    def third_party_config(self, third_party_config: str):
        """
        Set the third_party_config.
        :param third_party_config: third_party_config
        :type third_party_config: str
        """
        self._third_party_config = third_party_config


class Options(BaseModel):

    def __init__(self, enable_ssd: bool = None, enable_local: bool = None, throttle_sll: bool = None,
                 reset_on_attempted_reserve: bool = None):
        self._enable_ssd: bool = enable_ssd
        self._enable_local: bool = enable_local
        self._throttle_sll: bool = throttle_sll
        self._reset_on_attempted_reserve: bool = reset_on_attempted_reserve

    @property
    def enable_ssd(self) -> bool:
        """
        Return the enable_ssd.
        :return: enable_ssd
        :rtype: bool
        """
        return self._enable_ssd

    @enable_ssd.setter
    def enable_ssd(self, enable_ssd: bool):
        """
        Set the enable_ssd.
        :param enable_ssd: enable_ssd
        :type enable_ssd: bool
        """
        self._enable_ssd = enable_ssd

    @property
    def enable_local(self) -> bool:
        """
        Return the enable_local.
        :return: enable_local
        :rtype: bool
        """
        return self._enable_local

    @enable_local.setter
    def enable_local(self, enable_local: bool):
        """
        Set the enable_local.
        :param enable_local: enable_local
        :type enable_local: bool
        """
        self._enable_local = enable_local

    @property
    def throttle_sll(self) -> bool:
        """
        Return the throttle_sll.
        :return: throttle_sll
        :rtype: bool
        """
        return self._throttle_sll

    @throttle_sll.setter
    def throttle_sll(self, throttle_sll: bool):
        """
        Set the throttle_sll.
        :param throttle_sll: throttle_sll
        :type throttle_sll: bool
        """
        self._throttle_sll = throttle_sll

    @property
    def reset_on_attempted_reserve(self) -> bool:
        """
        Return the reset_on_attempted_reserve.
        :return: reset_on_attempted_reserve
        :rtype: bool
        """
        return self._reset_on_attempted_reserve

    @reset_on_attempted_reserve.setter
    def reset_on_attempted_reserve(self, reset_on_attempted_reserve: bool):
        """
        Set the reset_on_attempted_reserve.
        :param reset_on_attempted_reserve: reset_on_attempted_reserve
        :type reset_on_attempted_reserve: bool
        """
        self._reset_on_attempted_reserve = reset_on_attempted_reserve


class Satp(BaseModel):

    def __init__(self, type: SatpType = None, name: str = None, options: str = None, navi_reg: bool = None,
                 ip_filter: bool = None, explicit_alua: bool = None, action_on_retry: bool = None,
                 alua_follow_over: bool = None, enable_capacity_flash: bool = None):
        self._type: SatpType = type
        self._name: str = name
        self._options: str = options
        self._navi_reg: bool = navi_reg
        self._ip_filter: bool = ip_filter
        self._explicit_alua: bool = explicit_alua
        self._action_on_retry: bool = action_on_retry
        self._alua_follow_over: bool = alua_follow_over
        self._enable_capacity_flash: bool = enable_capacity_flash

    @property
    def type(self) -> SatpType:
        """
        Return the type.
        :return: type
        :rtype: SatpType
        """
        return self._type

    @type.setter
    def type(self, type: SatpType):
        """
        Set the type.
        :param type: type
        :type type: SatpType
        """
        self._type = type

    @property
    def name(self) -> str:
        """
        Return the name.
        :return: name
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name: str):
        """
        Set the name.
        :param name: name
        :type name: str
        """
        self._name = name

    @property
    def options(self) -> str:
        """
        Return the options.
        :return: options
        :rtype: str
        """
        return self._options

    @options.setter
    def options(self, options: str):
        """
        Set the options.
        :param options: options
        :type options: str
        """
        self._options = options

    @property
    def navi_reg(self) -> bool:
        """
        Return the navi_reg.
        :return: navi_reg
        :rtype: bool
        """
        return self._navi_reg

    @navi_reg.setter
    def navi_reg(self, navi_reg: bool):
        """
        Set the navi_reg.
        :param navi_reg: navi_reg
        :type navi_reg: bool
        """
        self._navi_reg = navi_reg

    @property
    def ip_filter(self) -> bool:
        """
        Return the ip_filter.
        :return: ip_filter
        :rtype: bool
        """
        return self._ip_filter

    @ip_filter.setter
    def ip_filter(self, ip_filter: bool):
        """
        Set the ip_filter.
        :param ip_filter: ip_filter
        :type ip_filter: bool
        """
        self._ip_filter = ip_filter

    @property
    def explicit_alua(self) -> bool:
        """
        Return the explicit_alua.
        :return: explicit_alua
        :rtype: bool
        """
        return self._explicit_alua

    @explicit_alua.setter
    def explicit_alua(self, explicit_alua: bool):
        """
        Set the explicit_alua.
        :param explicit_alua: explicit_alua
        :type explicit_alua: bool
        """
        self._explicit_alua = explicit_alua

    @property
    def action_on_retry(self) -> bool:
        """
        Return the action_on_retry.
        :return: action_on_retry
        :rtype: bool
        """
        return self._action_on_retry

    @action_on_retry.setter
    def action_on_retry(self, action_on_retry: bool):
        """
        Set the action_on_retry.
        :param action_on_retry: action_on_retry
        :type action_on_retry: bool
        """
        self._action_on_retry = action_on_retry

    @property
    def alua_follow_over(self) -> bool:
        """
        Return the alua_follow_over.
        :return: alua_follow_over
        :rtype: bool
        """
        return self._alua_follow_over

    @alua_follow_over.setter
    def alua_follow_over(self, alua_follow_over: bool):
        """
        Set the alua_follow_over.
        :param alua_follow_over: alua_follow_over
        :type alua_follow_over: bool
        """
        self._alua_follow_over = alua_follow_over

    @property
    def enable_capacity_flash(self) -> bool:
        """
        Return the enable_capacity_flash.
        :return: enable_capacity_flash
        :rtype: bool
        """
        return self._enable_capacity_flash

    @enable_capacity_flash.setter
    def enable_capacity_flash(self, enable_capacity_flash: bool):
        """
        Set the enable_capacity_flash.
        :param enable_capacity_flash: enable_capacity_flash
        :type enable_capacity_flash: bool
        """
        self._enable_capacity_flash = enable_capacity_flash


class Psp(BaseModel):

    def __init__(self, type: PspType = None, name: str = None, options: str = None, round_robin: Hpp = None,
                 preferred_path: str = None):
        self._type: PspType = type
        self._name: str = name
        self._options: str = options
        self._round_robin: Hpp = round_robin
        self._preferred_path: str = preferred_path

    @property
    def type(self) -> PspType:
        """
        Return the type.
        :return: type
        :rtype: PspType
        """
        return self._type

    @type.setter
    def type(self, type: PspType):
        """
        Set the type.
        :param type: type
        :type type: PspType
        """
        self._type = type

    @property
    def name(self) -> str:
        """
        Return the name.
        :return: name
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name: str):
        """
        Set the name.
        :param name: name
        :type name: str
        """
        self._name = name

    @property
    def options(self) -> str:
        """
        Return the options.
        :return: options
        :rtype: str
        """
        return self._options

    @options.setter
    def options(self, options: str):
        """
        Set the options.
        :param options: options
        :type options: str
        """
        self._options = options

    @property
    def round_robin(self) -> Hpp:
        """
        Return the round_robin.
        :return: round_robin
        :rtype: Hpp
        """
        return self._round_robin

    @round_robin.setter
    def round_robin(self, round_robin: Hpp):
        """
        Set the round_robin.
        :param round_robin: round_robin
        :type round_robin: Hpp
        """
        self._round_robin = round_robin

    @property
    def preferred_path(self) -> str:
        """
        Return the preferred_path.
        :return: preferred_path
        :rtype: str
        """
        return self._preferred_path

    @preferred_path.setter
    def preferred_path(self, preferred_path: str):
        """
        Set the preferred_path.
        :param preferred_path: preferred_path
        :type preferred_path: str
        """
        self._preferred_path = preferred_path


class Settings(BaseModel):

    def __init__(self, satp: Satp = None, psp: Psp = None, force: bool = None, options: Options = None,
                 description: str = None):
        self._satp: Satp = satp
        self._psp: Psp = psp
        self._force: bool = force
        self._options: Options = options
        self._description: str = description

    @property
    def satp(self) -> Satp:
        """
        Return the satp.
        :return: satp
        :rtype: Satp
        """
        return self._satp

    @satp.setter
    def satp(self, satp: Satp):
        """
        Set the satp.
        :param satp: satp
        :type satp: Satp
        """
        self._satp = satp

    @property
    def psp(self) -> Psp:
        """
        Return the psp.
        :return: psp
        :rtype: Psp
        """
        return self._psp

    @psp.setter
    def psp(self, psp: Psp):
        """
        Set the psp.
        :param psp: psp
        :type psp: Psp
        """
        self._psp = psp

    @property
    def force(self) -> bool:
        """
        Return the force.
        :return: force
        :rtype: bool
        """
        return self._force

    @force.setter
    def force(self, force: bool):
        """
        Set the force.
        :param force: force
        :type force: bool
        """
        self._force = force

    @property
    def options(self) -> Options:
        """
        Return the options.
        :return: options
        :rtype: Options
        """
        return self._options

    @options.setter
    def options(self, options: Options):
        """
        Set the options.
        :param options: options
        :type options: Options
        """
        self._options = options

    @property
    def description(self) -> str:
        """
        Return the description.
        :return: description
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description: str):
        """
        Set the description.
        :param description: description
        :type description: str
        """
        self._description = description


class Nmp(BaseModel):

    def __init__(self, psp: Psp = None, satp: Satp = None):
        self._psp: Psp = psp
        self._satp: Satp = satp

    @property
    def psp(self) -> Psp:
        """
        Return the psp.
        :return: psp
        :rtype: Psp
        """
        return self._psp

    @psp.setter
    def psp(self, psp: Psp):
        """
        Set the psp.
        :param psp: psp
        :type psp: Psp
        """
        self._psp = psp

    @property
    def satp(self) -> Satp:
        """
        Return the satp.
        :return: satp
        :rtype: Satp
        """
        return self._satp

    @satp.setter
    def satp(self, satp: Satp):
        """
        Set the satp.
        :param satp: satp
        :type satp: Satp
        """
        self._satp = satp


class Path(BaseModel):

    def __init__(self, path: str = None, psp: str = None, satp: str = None, state: State = None):
        self._path: str = path
        self._psp: str = psp
        self._satp: str = satp
        self._state: State = state

    @property
    def path(self) -> str:
        """
        Return the path.
        :return: path
        :rtype: str
        """
        return self._path

    @path.setter
    def path(self, path: str):
        """
        Set the path.
        :param path: path
        :type path: str
        """
        self._path = path

    @property
    def psp(self) -> str:
        """
        Return the psp.
        :return: psp
        :rtype: str
        """
        return self._psp

    @psp.setter
    def psp(self, psp: str):
        """
        Set the psp.
        :param psp: psp
        :type psp: str
        """
        self._psp = psp

    @property
    def satp(self) -> str:
        """
        Return the satp.
        :return: satp
        :rtype: str
        """
        return self._satp

    @satp.setter
    def satp(self, satp: str):
        """
        Set the satp.
        :param satp: satp
        :type satp: str
        """
        self._satp = satp

    @property
    def state(self) -> State:
        """
        Return the state.
        :return: state
        :rtype: State
        """
        return self._state

    @state.setter
    def state(self, state: State):
        """
        Set the state.
        :param state: state
        :type state: State
        """
        self._state = state


class BlockDevice(BaseModel):

    def __init__(self, device: str = None, hpp: Hpp = None, nmp: Nmp = None, state: BlockDeviceState = None,
                 plugin: str = None, not_shared: bool = None, display_name: str = None, ats_supported: bool = None,
                 zero_supported: bool = None, clone_supported: bool = None, max_queue_depth: int = None,
                 delete_supported: bool = None, perennial_reserved: bool = None, queue_full_threshold: int = None,
                 queue_full_sample_size: int = None, is_inquiry_cache_ignored: bool = None,
                 sched_num_req_outstanding: int = None, latency_sensitive_threshold: int = None):
        self._device: str = device
        self._hpp: Hpp = hpp
        self._nmp: Nmp = nmp
        self._state: BlockDeviceState = state
        self._plugin: str = plugin
        self._not_shared: bool = not_shared
        self._display_name: str = display_name
        self._ats_supported: bool = ats_supported
        self._zero_supported: bool = zero_supported
        self._clone_supported: bool = clone_supported
        self._max_queue_depth: int = max_queue_depth
        self._delete_supported: bool = delete_supported
        self._perennial_reserved: bool = perennial_reserved
        self._queue_full_threshold: int = queue_full_threshold
        self._queue_full_sample_size: int = queue_full_sample_size
        self._is_inquiry_cache_ignored: bool = is_inquiry_cache_ignored
        self._sched_num_req_outstanding: int = sched_num_req_outstanding
        self._latency_sensitive_threshold: int = latency_sensitive_threshold

    @property
    def device(self) -> str:
        """
        Return the device.
        :return: device
        :rtype: str
        """
        return self._device

    @device.setter
    def device(self, device: str):
        """
        Set the device.
        :param device: device
        :type device: str
        """
        self._device = device

    @property
    def hpp(self) -> Hpp:
        """
        Return the hpp.
        :return: hpp
        :rtype: Hpp
        """
        return self._hpp

    @hpp.setter
    def hpp(self, hpp: Hpp):
        """
        Set the hpp.
        :param hpp: hpp
        :type hpp: Hpp
        """
        self._hpp = hpp

    @property
    def nmp(self) -> Nmp:
        """
        Return the nmp.
        :return: nmp
        :rtype: Nmp
        """
        return self._nmp

    @nmp.setter
    def nmp(self, nmp: Nmp):
        """
        Set the nmp.
        :param nmp: nmp
        :type nmp: Nmp
        """
        self._nmp = nmp

    @property
    def state(self) -> BlockDeviceState:
        """
        Return the state.
        :return: state
        :rtype: BlockDeviceState
        """
        return self._state

    @state.setter
    def state(self, state: BlockDeviceState):
        """
        Set the state.
        :param state: state
        :type state: BlockDeviceState
        """
        self._state = state

    @property
    def plugin(self) -> str:
        """
        Return the plugin.
        :return: plugin
        :rtype: str
        """
        return self._plugin

    @plugin.setter
    def plugin(self, plugin: str):
        """
        Set the plugin.
        :param plugin: plugin
        :type plugin: str
        """
        self._plugin = plugin

    @property
    def not_shared(self) -> bool:
        """
        Return the not_shared.
        :return: not_shared
        :rtype: bool
        """
        return self._not_shared

    @not_shared.setter
    def not_shared(self, not_shared: bool):
        """
        Set the not_shared.
        :param not_shared: not_shared
        :type not_shared: bool
        """
        self._not_shared = not_shared

    @property
    def display_name(self) -> str:
        """
        Return the display_name.
        :return: display_name
        :rtype: str
        """
        return self._display_name

    @display_name.setter
    def display_name(self, display_name: str):
        """
        Set the display_name.
        :param display_name: display_name
        :type display_name: str
        """
        self._display_name = display_name

    @property
    def ats_supported(self) -> bool:
        """
        Return the ats_supported.
        :return: ats_supported
        :rtype: bool
        """
        return self._ats_supported

    @ats_supported.setter
    def ats_supported(self, ats_supported: bool):
        """
        Set the ats_supported.
        :param ats_supported: ats_supported
        :type ats_supported: bool
        """
        self._ats_supported = ats_supported

    @property
    def zero_supported(self) -> bool:
        """
        Return the zero_supported.
        :return: zero_supported
        :rtype: bool
        """
        return self._zero_supported

    @zero_supported.setter
    def zero_supported(self, zero_supported: bool):
        """
        Set the zero_supported.
        :param zero_supported: zero_supported
        :type zero_supported: bool
        """
        self._zero_supported = zero_supported

    @property
    def clone_supported(self) -> bool:
        """
        Return the clone_supported.
        :return: clone_supported
        :rtype: bool
        """
        return self._clone_supported

    @clone_supported.setter
    def clone_supported(self, clone_supported: bool):
        """
        Set the clone_supported.
        :param clone_supported: clone_supported
        :type clone_supported: bool
        """
        self._clone_supported = clone_supported

    @property
    def max_queue_depth(self) -> int:
        """
        Return the max_queue_depth.
        :return: max_queue_depth
        :rtype: int
        """
        return self._max_queue_depth

    @max_queue_depth.setter
    def max_queue_depth(self, max_queue_depth: int):
        """
        Set the max_queue_depth.
        :param max_queue_depth: max_queue_depth
        :type max_queue_depth: int
        """
        self._max_queue_depth = max_queue_depth

    @property
    def delete_supported(self) -> bool:
        """
        Return the delete_supported.
        :return: delete_supported
        :rtype: bool
        """
        return self._delete_supported

    @delete_supported.setter
    def delete_supported(self, delete_supported: bool):
        """
        Set the delete_supported.
        :param delete_supported: delete_supported
        :type delete_supported: bool
        """
        self._delete_supported = delete_supported

    @property
    def perennial_reserved(self) -> bool:
        """
        Return the perennial_reserved.
        :return: perennial_reserved
        :rtype: bool
        """
        return self._perennial_reserved

    @perennial_reserved.setter
    def perennial_reserved(self, perennial_reserved: bool):
        """
        Set the perennial_reserved.
        :param perennial_reserved: perennial_reserved
        :type perennial_reserved: bool
        """
        self._perennial_reserved = perennial_reserved

    @property
    def queue_full_threshold(self) -> int:
        """
        Return the queue_full_threshold.
        :return: queue_full_threshold
        :rtype: int
        """
        return self._queue_full_threshold

    @queue_full_threshold.setter
    def queue_full_threshold(self, queue_full_threshold: int):
        """
        Set the queue_full_threshold.
        :param queue_full_threshold: queue_full_threshold
        :type queue_full_threshold: int
        """
        self._queue_full_threshold = queue_full_threshold

    @property
    def queue_full_sample_size(self) -> int:
        """
        Return the queue_full_sample_size.
        :return: queue_full_sample_size
        :rtype: int
        """
        return self._queue_full_sample_size

    @queue_full_sample_size.setter
    def queue_full_sample_size(self, queue_full_sample_size: int):
        """
        Set the queue_full_sample_size.
        :param queue_full_sample_size: queue_full_sample_size
        :type queue_full_sample_size: int
        """
        self._queue_full_sample_size = queue_full_sample_size

    @property
    def is_inquiry_cache_ignored(self) -> bool:
        """
        Return the is_inquiry_cache_ignored.
        :return: is_inquiry_cache_ignored
        :rtype: bool
        """
        return self._is_inquiry_cache_ignored

    @is_inquiry_cache_ignored.setter
    def is_inquiry_cache_ignored(self, is_inquiry_cache_ignored: bool):
        """
        Set the is_inquiry_cache_ignored.
        :param is_inquiry_cache_ignored: is_inquiry_cache_ignored
        :type is_inquiry_cache_ignored: bool
        """
        self._is_inquiry_cache_ignored = is_inquiry_cache_ignored

    @property
    def sched_num_req_outstanding(self) -> int:
        """
        Return the sched_num_req_outstanding.
        :return: sched_num_req_outstanding
        :rtype: int
        """
        return self._sched_num_req_outstanding

    @sched_num_req_outstanding.setter
    def sched_num_req_outstanding(self, sched_num_req_outstanding: int):
        """
        Set the sched_num_req_outstanding.
        :param sched_num_req_outstanding: sched_num_req_outstanding
        :type sched_num_req_outstanding: int
        """
        self._sched_num_req_outstanding = sched_num_req_outstanding

    @property
    def latency_sensitive_threshold(self) -> int:
        """
        Return the latency_sensitive_threshold.
        :return: latency_sensitive_threshold
        :rtype: int
        """
        return self._latency_sensitive_threshold

    @latency_sensitive_threshold.setter
    def latency_sensitive_threshold(self, latency_sensitive_threshold: int):
        """
        Set the latency_sensitive_threshold.
        :param latency_sensitive_threshold: latency_sensitive_threshold
        :type latency_sensitive_threshold: int
        """
        self._latency_sensitive_threshold = latency_sensitive_threshold


class NmpClaimRule(BaseModel):

    def __init__(self, criteria: NmpCriteria = None, settings: Settings = None):
        self._criteria: NmpCriteria = criteria
        self._settings: Settings = settings

    @property
    def criteria(self) -> NmpCriteria:
        """
        Return the criteria.
        :return: criteria
        :rtype: CritNmpCriteriaeria
        """
        return self._criteria

    @criteria.setter
    def criteria(self, criteria: NmpCriteria):
        """
        Set the criteria.
        :param criteria: criteria
        :type criteria: NmpCriteria
        """
        self._criteria = criteria

    @property
    def settings(self) -> Settings:
        """
        Return the settings.
        :return: settings
        :rtype: Settings
        """
        return self._settings

    @settings.setter
    def settings(self, settings: Settings):
        """
        Set the settings.
        :param settings: settings
        :type settings: Settings
        """
        self._settings = settings


class ScratchLocation(BaseModel):

    def __init__(self, path: str = None):
        self._path: str = path

    @property
    def path(self) -> str:
        """
        Return the path.
        :return: path
        :rtype: str
        """
        return self._path

    @path.setter
    def path(self, path: str):
        """
        Set the path.
        :param path: path
        :type path: str
        """
        self._path = path


class BaseNfsDatastore(BaseModel):

    def __init__(self, volume_name: str = None, remote_share: str = None, read_only: bool = None,
                 maxq_depth: int = None):
        self._volume_name: str = volume_name
        self._remote_share: str = remote_share
        self._read_only: bool = read_only
        self._maxq_depth: int = maxq_depth

    @property
    def volume_name(self) -> str:
        """
        Return the volume_name.
        :return: volume_name
        :rtype: str
        """
        return self._volume_name

    @volume_name.setter
    def volume_name(self, volume_name: str):
        """
        Set the volume_name.
        :param volume_name: volume_name
        :type volume_name: str
        """
        self._volume_name = volume_name

    @property
    def remote_share(self) -> str:
        """
        Return the remote_share.
        :return: remote_share
        :rtype: str
        """
        return self._remote_share

    @remote_share.setter
    def remote_share(self, remote_share: str):
        """
        Set the remote_share.
        :param remote_share: remote_share
        :type remote_share: str
        """
        self._remote_share = remote_share

    @property
    def read_only(self) -> bool:
        """
        Return the read_only.
        :return: read_only
        :rtype: bool
        """
        return self._read_only

    @read_only.setter
    def read_only(self, read_only: bool):
        """
        Set the read_only.
        :param read_only: read_only
        :type read_only: bool
        """
        self._read_only = read_only

    @property
    def maxq_depth(self) -> int:
        """
        Return the maxq_depth.
        :return: maxq_depth
        :rtype: int
        """
        return self._maxq_depth

    @maxq_depth.setter
    def maxq_depth(self, maxq_depth: int):
        """
        Set the maxq_depth.
        :param maxq_depth: maxq_depth
        :type maxq_depth: int
        """
        self._maxq_depth = maxq_depth


class NfsV3Datastore(BaseNfsDatastore):

    def __init__(self, hostname: str = None, connections: int = None, vmknic_name: str = None,
                 bind_to_vmknic: bool = None):
        super().__init__()
        self._hostname: str = hostname
        self._connections: int = connections
        self._vmknic_name: str = vmknic_name
        self._bind_to_vmknic: bool = bind_to_vmknic

    @property
    def hostname(self) -> str:
        """
        Return the hostname.
        :return: hostname
        :rtype: str
        """
        return self._hostname

    @hostname.setter
    def hostname(self, hostname: str):
        """
        Set the hostname.
        :param hostname: hostname
        :type hostname: str
        """
        self._hostname = hostname

    @property
    def connections(self) -> int:
        """
        Return the connections.
        :return: connections
        :rtype: int
        """
        return self._connections

    @connections.setter
    def connections(self, connections: int):
        """
        Set the connections.
        :param connections: connections
        :type connections: int
        """
        self._connections = connections

    @property
    def vmknic_name(self) -> str:
        """
        Return the vmknic_name.
        :return: vmknic_name
        :rtype: str
        """
        return self._vmknic_name

    @vmknic_name.setter
    def vmknic_name(self, vmknic_name: str):
        """
        Set the vmknic_name.
        :param vmknic_name: vmknic_name
        :type vmknic_name: str
        """
        self._vmknic_name = vmknic_name

    @property
    def bind_to_vmknic(self) -> bool:
        """
        Return the bind_to_vmknic.
        :return: bind_to_vmknic
        :rtype: bool
        """
        return self._bind_to_vmknic

    @bind_to_vmknic.setter
    def bind_to_vmknic(self, bind_to_vmknic: bool):
        """
        Set the bind_to_vmknic.
        :param bind_to_vmknic: bind_to_vmknic
        :type bind_to_vmknic: bool
        """
        self._bind_to_vmknic = bind_to_vmknic


class SatpDefaultPsp(BaseModel):

    def __init__(self, satp: str = None, default_psp: str = None):
        self._satp: str = satp
        self._default_psp: str = default_psp

    @property
    def satp(self) -> str:
        """
        Return the satp.
        :return: satp
        :rtype: str
        """
        return self._satp

    @satp.setter
    def satp(self, satp: str):
        """
        Set the satp.
        :param satp: satp
        :type satp: str
        """
        self._satp = satp

    @property
    def default_psp(self) -> str:
        """
        Return the default_psp.
        :return: default_psp
        :rtype: str
        """
        return self._default_psp

    @default_psp.setter
    def default_psp(self, default_psp: str):
        """
        Set the default_psp.
        :param default_psp: default_psp
        :type default_psp: str
        """
        self._default_psp = default_psp


class NfsV41Datastore(BaseNfsDatastore):

    def __init__(self, auth_type: AuthType = None, hostnames: List[str] = None):
        super().__init__()
        self._auth_type: AuthType = auth_type
        self._hostnames: List[str] = hostnames

    @property
    def auth_type(self) -> AuthType:
        """
        Return the auth_type.
        :return: auth_type
        :rtype: AuthType
        """
        return self._auth_type

    @auth_type.setter
    def auth_type(self, auth_type: AuthType):
        """
        Set the auth_type.
        :param auth_type: auth_type
        :type auth_type: AuthType
        """
        self._auth_type = auth_type

    @property
    def hostnames(self) -> List[str]:
        """
        Return the hostnames.
        :return: hostnames
        :rtype: List[str]
        """
        return self._hostnames

    @hostnames.setter
    def hostnames(self, hostnames: List[str]):
        """
        Set the hostnames.
        :param hostnames: hostnames
        :type hostnames: List[str]
        """
        self._hostnames = hostnames


class NfsKrbCredentials(BaseModel):

    def __init__(self, password: str = None, username: str = None):
        self._password: str = password
        self._username: str = username

    @property
    def password(self) -> str:
        """
        Return the password.
        :return: password
        :rtype: str
        """
        return self._password

    @password.setter
    def password(self, password: str):
        """
        Set the password.
        :param password: password
        :type password: str
        """
        self._password = password

    @property
    def username(self) -> str:
        """
        Return the username.
        :return: username
        :rtype: str
        """
        return self._username

    @username.setter
    def username(self, username: str):
        """
        Set the username.
        :param username: username
        :type username: str
        """
        self._username = username


class PsaMppClaimRule(BaseModel):

    def __init__(self, rule_no: str = None, criteria: PsaMppClaimRuleCriteria = None, settings: PsaMppClaimRulesSettings = None,
                 force_reserved: bool = None):
        self._rule_no: str = rule_no
        self._criteria: PsaMppClaimRuleCriteria = criteria
        self._settings: PsaMppClaimRulesSettings = settings
        self._force_reserved: bool = force_reserved

    @property
    def rule_no(self) -> str:
        """
        Return the rule_no.
        :return: rule_no
        :rtype: str
        """
        return self._rule_no

    @rule_no.setter
    def rule_no(self, rule_no: str):
        """
        Set the rule_no.
        :param rule_no: rule_no
        :type rule_no: str
        """
        self._rule_no = rule_no

    @property
    def criteria(self) -> PsaMppClaimRuleCriteria:
        """
        Return the criteria.
        :return: criteria
        :rtype: PsaMppClaimRuleCriteria
        """
        return self._criteria

    @criteria.setter
    def criteria(self, criteria: PsaMppClaimRuleCriteria):
        """
        Set the criteria.
        :param criteria: criteria
        :type criteria: PsaMppClaimRuleCriteria
        """
        self._criteria = criteria

    @property
    def settings(self) -> PsaMppClaimRulesSettings:
        """
        Return the settings.
        :return: settings
        :rtype: PsaMppClaimRulesSettings
        """
        return self._settings

    @settings.setter
    def settings(self, settings: PsaMppClaimRulesSettings):
        """
        Set the settings.
        :param settings: settings
        :type settings: PsaMppClaimRulesSettings
        """
        self._settings = settings

    @property
    def force_reserved(self) -> bool:
        """
        Return the force_reserved.
        :return: force_reserved
        :rtype: bool
        """
        return self._force_reserved

    @force_reserved.setter
    def force_reserved(self, force_reserved: bool):
        """
        Set the force_reserved.
        :param force_reserved: force_reserved
        :type force_reserved: bool
        """
        self._force_reserved = force_reserved


class CommonClaimRule(BaseModel):

    def __init__(self, rule_no: str = None, criteria: Criteria = None, settings: ClaimRuleSettings = None,
                 force_reserved: bool = None):
        self._rule_no: str = rule_no
        self._criteria: Criteria = criteria
        self._settings: ClaimRuleSettings = settings
        self._force_reserved: bool = force_reserved

    @property
    def rule_no(self) -> str:
        """
        Return the rule_no.
        :return: rule_no
        :rtype: str
        """
        return self._rule_no

    @rule_no.setter
    def rule_no(self, rule_no: str):
        """
        Set the rule_no.
        :param rule_no: rule_no
        :type rule_no: str
        """
        self._rule_no = rule_no

    @property
    def criteria(self) -> Criteria:
        """
        Return the criteria.
        :return: criteria
        :rtype: Criteria
        """
        return self._criteria

    @criteria.setter
    def criteria(self, criteria: Criteria):
        """
        Set the criteria.
        :param criteria: criteria
        :type criteria: Criteria
        """
        self._criteria = criteria

    @property
    def settings(self) -> ClaimRuleSettings:
        """
        Return the settings.
        :return: settings
        :rtype: ClaimRuleSettings
        """
        return self._settings

    @settings.setter
    def settings(self, settings: ClaimRuleSettings):
        """
        Set the settings.
        :param settings: settings
        :type settings: ClaimRuleSettings
        """
        self._settings = settings

    @property
    def force_reserved(self) -> bool:
        """
        Return the force_reserved.
        :return: force_reserved
        :rtype: bool
        """
        return self._force_reserved

    @force_reserved.setter
    def force_reserved(self, force_reserved: bool):
        """
        Set the force_reserved.
        :param force_reserved: force_reserved
        :type force_reserved: bool
        """
        self._force_reserved = force_reserved


class StorageConfigModel(BaseModel):
    """Class to set Storage config for ESXi host."""

    def __init__(self, paths: List[Path] = None, block_devices: List[BlockDevice] = None,
                 nmp_claim_rules: List[NmpClaimRule] = None, scratch_location: ScratchLocation = None,
                 nfs_v3_datastores: List[NfsV3Datastore] = None, satp_default_psps: List[SatpDefaultPsp] = None,
                 nfs_v41_datastores: List[NfsV41Datastore] = None, nfs_krb_credentials: NfsKrbCredentials = None,
                 psa_mpp_claim_rules: List[PsaMppClaimRule] = None, psa_vaai_claim_rules: List[CommonClaimRule] = None,
                 psa_filter_claim_rules: List[CommonClaimRule] = None):
        self._paths: List[Path] = paths
        self._block_devices: List[BlockDevice] = block_devices
        self._nmp_claim_rules: List[NmpClaimRule] = nmp_claim_rules
        self._scratch_location: ScratchLocation = scratch_location
        self._nfs_v3_datastores: List[NfsV3Datastore] = nfs_v3_datastores
        self._satp_default_psps: List[SatpDefaultPsp] = satp_default_psps
        self._nfs_v41_datastores: List[NfsV41Datastore] = nfs_v41_datastores
        self._nfs_krb_credentials: NfsKrbCredentials = nfs_krb_credentials
        self._psa_mpp_claim_rules: List[PsaMppClaimRule] = psa_mpp_claim_rules
        self._psa_vaai_claim_rules: List[CommonClaimRule] = psa_vaai_claim_rules
        self._psa_filter_claim_rules: List[CommonClaimRule] = psa_filter_claim_rules

    @property
    def paths(self) -> List[Path]:
        """
        Return the paths.
        :return: paths
        :rtype: List[Path]
        """
        return self._paths

    @paths.setter
    def paths(self, paths: List[Path]):
        """
        Set the paths.
        :param paths: paths
        :type paths: List[Path]
        """
        self._paths = paths

    @property
    def block_devices(self) -> List[BlockDevice]:
        """
        Return the block_devices.
        :return: block_devices
        :rtype: List[BlockDevice]
        """
        return self._block_devices

    @block_devices.setter
    def block_devices(self, block_devices: List[BlockDevice]):
        """
        Set the block_devices.
        :param block_devices: block_devices
        :type block_devices: List[BlockDevice]
        """
        self._block_devices = block_devices

    @property
    def nmp_claim_rules(self) -> List[NmpClaimRule]:
        """
        Return the nmp_claim_rules.
        :return: nmp_claim_rules
        :rtype: List[NmpClaimRule]
        """
        return self._nmp_claim_rules

    @nmp_claim_rules.setter
    def nmp_claim_rules(self, nmp_claim_rules: List[NmpClaimRule]):
        """
        Set the nmp_claim_rules.
        :param nmp_claim_rules: nmp_claim_rules
        :type nmp_claim_rules: List[NmpClaimRule]
        """
        self._nmp_claim_rules = nmp_claim_rules

    @property
    def scratch_location(self) -> ScratchLocation:
        """
        Return the scratch_location.
        :return: scratch_location
        :rtype: ScratchLocation
        """
        return self._scratch_location

    @scratch_location.setter
    def scratch_location(self, scratch_location: ScratchLocation):
        """
        Set the scratch_location.
        :param scratch_location: scratch_location
        :type scratch_location: ScratchLocation
        """
        self._scratch_location = scratch_location

    @property
    def nfs_v3_datastores(self) -> List[NfsV3Datastore]:
        """
        Return the nfs_v3_datastores.
        :return: nfs_v3_datastores
        :rtype: List[NfsV3Datastore]
        """
        return self._nfs_v3_datastores

    @nfs_v3_datastores.setter
    def nfs_v3_datastores(self, nfs_v3_datastores: List[NfsV3Datastore]):
        """
        Set the nfs_v3_datastores.
        :param nfs_v3_datastores: nfs_v3_datastores
        :type nfs_v3_datastores: List[NfsV3Datastore]
        """
        self._nfs_v3_datastores = nfs_v3_datastores

    @property
    def satp_default_psps(self) -> List[SatpDefaultPsp]:
        """
        Return the satp_default_psps.
        :return: satp_default_psps
        :rtype: List[SatpDefaultPsp]
        """
        return self._satp_default_psps

    @satp_default_psps.setter
    def satp_default_psps(self, satp_default_psps: List[SatpDefaultPsp]):
        """
        Set the satp_default_psps.
        :param satp_default_psps: satp_default_psps
        :type satp_default_psps: List[SatpDefaultPsp]
        """
        self._satp_default_psps = satp_default_psps

    @property
    def nfs_v41_datastores(self) -> List[NfsV41Datastore]:
        """
        Return the nfs_v41_datastores.
        :return: nfs_v41_datastores
        :rtype: List[NfsV41Datastore]
        """
        return self._nfs_v41_datastores

    @nfs_v41_datastores.setter
    def nfs_v41_datastores(self, nfs_v41_datastores: List[NfsV41Datastore]):
        """
        Set the nfs_v41_datastores.
        :param nfs_v41_datastores: nfs_v41_datastores
        :type nfs_v41_datastores: List[NfsV41Datastore]
        """
        self._nfs_v41_datastores = nfs_v41_datastores

    @property
    def nfs_krb_credentials(self) -> NfsKrbCredentials:
        """
        Return the nfs_krb_credentials.
        :return: nfs_krb_credentials
        :rtype: NfsKrbCredentials
        """
        return self._nfs_krb_credentials

    @nfs_krb_credentials.setter
    def nfs_krb_credentials(self, nfs_krb_credentials: NfsKrbCredentials):
        """
        Set the nfs_krb_credentials.
        :param nfs_krb_credentials: nfs_krb_credentials
        :type nfs_krb_credentials: NfsKrbCredentials
        """
        self._nfs_krb_credentials = nfs_krb_credentials

    @property
    def psa_mpp_claim_rules(self) -> List[PsaMppClaimRule]:
        """
        Return the psa_mpp_claim_rules.
        :return: psa_mpp_claim_rules
        :rtype: List[PsaMppClaimRule]
        """
        return self._psa_mpp_claim_rules

    @psa_mpp_claim_rules.setter
    def psa_mpp_claim_rules(self, psa_mpp_claim_rules: List[PsaMppClaimRule]):
        """
        Set the psa_mpp_claim_rules.
        :param psa_mpp_claim_rules: psa_mpp_claim_rules
        :type psa_mpp_claim_rules: List[PsaMppClaimRule]
        """
        self._psa_mpp_claim_rules = psa_mpp_claim_rules

    @property
    def psa_vaai_claim_rules(self) -> List[CommonClaimRule]:
        """
        Return the psa_vaai_claim_rules.
        :return: psa_vaai_claim_rules
        :rtype: List[CommonClaimRule]
        """
        return self._psa_vaai_claim_rules

    @psa_vaai_claim_rules.setter
    def psa_vaai_claim_rules(self, psa_vaai_claim_rules: List[CommonClaimRule]):
        """
        Set the psa_vaai_claim_rules.
        :param psa_vaai_claim_rules: psa_vaai_claim_rules
        :type psa_vaai_claim_rules: List[CommonClaimRule]
        """
        self._psa_vaai_claim_rules = psa_vaai_claim_rules

    @property
    def psa_filter_claim_rules(self) -> List[CommonClaimRule]:
        """
        Return the psa_filter_claim_rules.
        :return: psa_filter_claim_rules
        :rtype: List[CommonClaimRule]
        """
        return self._psa_filter_claim_rules

    @psa_filter_claim_rules.setter
    def psa_filter_claim_rules(self, psa_filter_claim_rules: List[CommonClaimRule]):
        """
        Set the psa_filter_claim_rules.
        :param psa_filter_claim_rules: psa_filter_claim_rules
        :type psa_filter_claim_rules: List[CommonClaimRule]
        """
        self._psa_filter_claim_rules = psa_filter_claim_rules
