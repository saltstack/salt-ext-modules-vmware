# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum
from typing import List

from config_modules_vmware.esxi.config_model.base_model import BaseModel


class AdapterType(BaseModel, Enum):
    DEPENDENT = 0
    INDEPENDENT = 1


class ChapAuthenticationType(BaseModel, Enum):
    PROHIBITED = "chapProhibited"
    DISCOURAGED = "chapDiscouraged"
    PREFERRED = "chapPreferred"
    REQUIRED = "chapRequired"


class DigestLevel(BaseModel, Enum):
    PROHIBITED = "digestProhibited"
    DISCOURAGED = "digestDiscouraged"
    PREFERRED = "digestPreferred"
    REQUIRED = "digestRequired"


class ErrorRecoveryLevel(BaseModel, Enum):
    SESSION_RECOVERY = 0
    DIGEST_RECOVERY = 1
    CONNECTION_RECOVERY = 2


class TargetType(BaseModel, Enum):
    STATIC = "STATIC"
    SENDTARGET = "SENDTARGET"


class IpV4Option(BaseModel, Enum):
    NO_IPV4 = "NO_IPV4"
    DHCP = "DHCP"
    STATIC = "STATIC"


class IpV6Option(BaseModel, Enum):
    NO_IPV6 = "NO_IPV6"
    DHCPV6 = "DHCPV6"
    RA = "RA"
    STATIC = "STATIC"


class Credentials(BaseModel):

    def __init__(self, username=None, password=None):
        self._username = username
        self._password = password

    @property
    def username(self):
        """
        Return the username.
        :return: username
        :rtype: str
        """
        return self._username

    @username.setter
    def username(self, username):
        """
        Set the username.
        :param username: username
        :type username: str
        """
        self._username = username

    @property
    def password(self):
        """
        Return the password.
        :return: password
        :rtype: str
        """
        return self._password

    @password.setter
    def password(self, password):
        """
        Set the password.
        :param password: password
        :type password: str
        """
        self._password = password


class MutualChapAuth(BaseModel):

    def __init__(self, level: ChapAuthenticationType = None, credentials: Credentials = None):
        self._level = level
        self._credentials = credentials

    @property
    def level(self) -> ChapAuthenticationType:
        """
        Return the chap authentication type.
        :return: chap authentication type
        :rtype: ChapAuthenticationType
        """
        return self._level

    @level.setter
    def level(self, level: ChapAuthenticationType):
        """
        Set the chap authentication type.
        :param level: chap authentication type
        :type level: ChapAuthenticationType
        """
        self._level = level

    @property
    def credentials(self) -> Credentials:
        """
        Return the credentials.
        :return: mutual chap auth credentials
        :rtype: Credentials
        """
        return self._credentials

    @credentials.setter
    def credentials(self, credentials: Credentials):
        """
        Set the credentials.
        :param credentials: mutual chap auth credentials
        :type credentials: Credentials
        """
        self._credentials = credentials


class ChapAuthentication(BaseModel):
    """Class to store chap authentication information for storage adapter"""

    def __init__(self, uni_chap_level: ChapAuthenticationType = None, uni_chap_auth_credentials: Credentials = None,
                 mutual_chap_auth: MutualChapAuth = None):
        self._uni_chap_level = uni_chap_level
        self._uni_chap_auth_credentials = uni_chap_auth_credentials
        self._mutual_chap_auth = mutual_chap_auth

    @property
    def uni_chap_level(self) -> ChapAuthenticationType:
        """
        Return the chap authentication type.
        :return: chap authentication type
        :rtype: ChapAuthenticationType
        """
        return self._uni_chap_level

    @uni_chap_level.setter
    def uni_chap_level(self, uni_chap_level: ChapAuthenticationType):
        """
        Set the chap authentication type.
        :param uni_chap_level: chap authentication type
        :type uni_chap_level: ChapAuthenticationType
        """
        self._uni_chap_level = uni_chap_level

    @property
    def uni_chap_auth_credentials(self) -> Credentials:
        """
        Return the chap auth credentials.
        :return: auth credentials
        :rtype: Credentials
        """
        return self._uni_chap_auth_credentials

    @uni_chap_auth_credentials.setter
    def uni_chap_auth_credentials(self, uni_chap_auth_credentials: Credentials):
        """
        Set the chap auth credentials.
        :param uni_chap_auth_credentials: auth credentials
        :type uni_chap_auth_credentials: Credentials
        """
        self._uni_chap_auth_credentials = uni_chap_auth_credentials

    @property
    def mutual_chap_auth(self) -> MutualChapAuth:
        """
        Set the mutual chap auth.
        :return: mutual chap authentication
        :rtype: MutualChapAuth
        """
        return self._mutual_chap_auth

    @mutual_chap_auth.setter
    def mutual_chap_auth(self, mutual_chap_auth: MutualChapAuth):
        """
        Get the mutual chap auth.
        :param mutual_chap_auth: mutual chap authentication
        :type mutual_chap_auth: MutualChapAuth
        """
        self._mutual_chap_auth = mutual_chap_auth


class IpV4(BaseModel):
    """Class to set IPv4 config"""

    def __init__(self, address=None, gateway=None, subnet_mask=None):
        self._address = address
        self._gateway = gateway
        self._subnet_mask = subnet_mask

    @property
    def address(self):
        """
        Return the IPv4 address.
        :return: ipv4 address
        :rtype: str
        """
        return self._address

    @address.setter
    def address(self, address):
        """
        Set the IPv4 address.
        :param address: ipv4 address
        :type address: str
        """
        self._address = address

    @property
    def gateway(self):
        """
        Return the gateway address.
        :return: gateway ip address
        :rtype: str
        """
        return self._gateway

    @gateway.setter
    def gateway(self, gateway):
        """
        Set the gateway address.
        :param gateway: gateway ip address
        :type gateway: str
        """
        self._gateway = gateway

    @property
    def subnet_mask(self):
        """
        Return the subnet mask.
        :return: subnet mask
        :rtype: str
        """
        return self._subnet_mask

    @subnet_mask.setter
    def subnet_mask(self, subnet_mask):
        """
        Set the subnet mask.
        :param subnet_mask: subnet mask
        :type subnet_mask: str
        """
        self._subnet_mask = subnet_mask


class IpAddress(BaseModel):
    """Class to set IPv6 address"""

    def __init__(self, address=None, prefix_length=64):
        self._address = address
        self._prefix_length = prefix_length

    @property
    def address(self):
        """
        Return the IP address.
        :return: ip address
        :rtype: str
        """
        return self._address

    @address.setter
    def address(self, address):
        """
        Set the IP address.
        :param address: ip address
        :type address: str
        """
        self._address = address

    @property
    def prefix_length(self) -> int:
        """
        Return the prefix length.
        :return: prefix length
        :rtype: int
        """
        return self._prefix_length

    @prefix_length.setter
    def prefix_length(self, prefix_length: int):
        """
        Set the prefix length.
        :param prefix_length: prefix length
        :type prefix_length: int
        """
        self._prefix_length = prefix_length


class IpV6(BaseModel):
    """Class to set IPv6 config"""

    def __init__(self, addresses: List[IpAddress] = None, gateway=None):
        self._addresses = addresses
        self._gateway = gateway

    @property
    def addresses(self) -> List[IpAddress]:
        """
        Return the IPv6 addresses.
        :return: List of ipv6 addresses
        :rtype: List[IpAddress]
        """
        return self._addresses

    @addresses.setter
    def addresses(self, addresses: List[IpAddress]):
        """
        Set the IPv6 addresses.
        :param addresses: List of ipv6 addresses
        :type addresses: List[IpAddress]
        """
        self._addresses = addresses

    @property
    def gateway(self):
        """
        Return the gateway information.
        :return: gateway address
        :rtype: str
        """
        return self._gateway

    @gateway.setter
    def gateway(self, gateway):
        """
        Set the gateway information.
        :param gateway: gateway address
        :type gateway: str
        """
        self._gateway = gateway


class IndependentNetworking(BaseModel):
    """Class to set independent networking for hardware adapters config"""

    def __init__(self):
        self._ipv4_option = None
        self._ipv4 = None
        self._ipv6_option = None
        self._ipv6 = None
        self._link_local_address = None
        self._primary_dns = None
        self._secondary_dns = None
        self._mtu = None
        self._arp_redirect = None

    @property
    def ipv4_option(self) -> IpV4Option:
        """
        Return the ipv4 option.
        :return: the ipv4 option
        :rtype: IpV4Option
        """
        return self._ipv4_option

    @ipv4_option.setter
    def ipv4_option(self, ipv4_option: IpV4Option):
        """
        Set the ipv4 option.
        :param ipv4_option: the ipv4 option
        :type ipv4_option: IpV4Option
        """
        self._ipv4_option = ipv4_option

    @property
    def ipv4(self) -> IpV4:
        """
        Return the ipv4.
        :return: the ipv4 information
        :rtype: IpV4 information
        """
        return self._ipv4

    @ipv4.setter
    def ipv4(self, ipv4: IpV4):
        """
        Set the ipv4.
        :param ipv4: the ipv4 information
        :type ipv4: IpV4
        """
        self._ipv4 = ipv4

    @property
    def ipv6_option(self) -> IpV6Option:
        """
        Return the ipv6 option.
        :return: the ipv6 option
        :rtype: IpV6Option
        """
        return self._ipv6_option

    @ipv6_option.setter
    def ipv6_option(self, ipv6_option: IpV6Option):
        """
        Set the ipv6 option.
        :param ipv6_option: the ipv6 option
        :type ipv6_option: IpV6Option
        """
        self._ipv6_option = ipv6_option

    @property
    def ipv6(self) -> IpV6:
        """
        Return the ipv6.
        :return: the ipv6 information
        :rtype: IpV6
        """
        return self._ipv6

    @ipv6.setter
    def ipv6(self, ipv6: IpV6):
        """
        Set the ipv6.
        :param ipv6: the ipv6 information
        :type ipv6: IpV6
        """
        self._ipv6 = ipv6

    @property
    def link_local_address(self) -> IpAddress:
        """
        Return the link local address if any.
        :return: link local address
        :rtype: IpAddress
        """
        return self._link_local_address

    @link_local_address.setter
    def link_local_address(self, link_local_address: IpAddress):
        """
        Set the link local address.
        :param link_local_address: link local address
        :type link_local_address: IpAddress
        """
        self._link_local_address = link_local_address

    @property
    def primary_dns(self):
        """
        Return the primary dns.
        :return: primary dns information
        :rtype: str
        """
        return self._primary_dns

    @primary_dns.setter
    def primary_dns(self, primary_dns):
        """
        Set the primary dns.
        :param primary_dns: primary dns information
        :type primary_dns: str
        """
        self._primary_dns = primary_dns

    @property
    def secondary_dns(self):
        """
        Return the secondary dns.
        :return: secondary dns information
        :rtype: str
        """
        return self._secondary_dns

    @secondary_dns.setter
    def secondary_dns(self, secondary_dns):
        """
        Set the secondary dns.
        :param secondary_dns: secondary dns information
        :type secondary_dns: str
        """
        self._secondary_dns = secondary_dns

    @property
    def mtu(self):
        """
        Return the mtu.
        :return: mtu value
        """
        return self._mtu

    @mtu.setter
    def mtu(self, mtu):
        """
        Set the mtu.
        :param mtu: mtu value
        """
        self._mtu = mtu

    @property
    def arp_redirect(self) -> bool:
        """
        Return the arp redirect setting.
        :return: enabled or not
        :rtype: bool
        """
        return self._arp_redirect

    @arp_redirect.setter
    def arp_redirect(self, arp_redirect: bool):
        """
        Set the arp redirect setting.
        :param arp_redirect: enabled or not
        :type arp_redirect: bool
        """
        self._arp_redirect = arp_redirect


class DigestProperties(BaseModel):

    def __init__(self, header_digest_level: DigestLevel = None, data_digest_level: DigestLevel = None):
        self._header_digest_level = header_digest_level
        self._data_digest_level = data_digest_level

    @property
    def header_digest_level(self) -> DigestLevel:
        """
        Return the header digest level.
        :return: header digest level
        :rtype: DigestLevel
        """
        return self._header_digest_level

    @header_digest_level.setter
    def header_digest_level(self, header_digest_level: DigestLevel):
        """
        Set the header digest level.
        :param header_digest_level: header digest level
        :type header_digest_level: DigestLevel
        """
        self._header_digest_level = header_digest_level

    @property
    def data_digest_level(self) -> DigestLevel:
        """
        Return the data digest level.
        :return: data digest level
        :rtype: DigestLevel
        """
        return self._data_digest_level

    @data_digest_level.setter
    def data_digest_level(self, data_digest_level: DigestLevel):
        """
        Set the data digest level.
        :param data_digest_level: data digest level
        :type data_digest_level: DigestLevel
        """
        self._data_digest_level = data_digest_level


class AdvancedOptions(DigestProperties):

    def __init__(self):
        super().__init__()
        self._max_commands = None
        self._recovery_timeout = None
        self._initial_r2t = None
        self._immediate_data = None
        self._default_time_to_retain = None
        self._default_time_to_wait = None
        self._error_recovery_level = None
        self._max_outstanding_r2t = None
        self._first_burst_length = None
        self._max_burst_length = None
        self._login_retry_max = None
        self._logout_timeout = None
        self._login_timeout = None
        self._noop_out_interval = None
        self._noop_out_timeout = None
        self._delayed_ack = None
        self._max_recv_data_segment_length = None

    @property
    def max_commands(self):
        return self._max_commands

    @max_commands.setter
    def max_commands(self, max_commands):
        self._max_commands = max_commands

    @property
    def recovery_timeout(self):
        return self._recovery_timeout

    @recovery_timeout.setter
    def recovery_timeout(self, recovery_timeout):
        self._recovery_timeout = recovery_timeout

    @property
    def initial_r2t(self) -> bool:
        return self._initial_r2t

    @initial_r2t.setter
    def initial_r2t(self, initial_r2t: bool):
        self._initial_r2t = initial_r2t

    @property
    def immediate_data(self) -> bool:
        return self._immediate_data

    @immediate_data.setter
    def immediate_data(self, immediate_data: bool):
        self._immediate_data = immediate_data

    @property
    def default_time_to_retain(self):
        return self._default_time_to_retain

    @default_time_to_retain.setter
    def default_time_to_retain(self, default_time_to_retain):
        self._default_time_to_retain = default_time_to_retain

    @property
    def default_time_to_wait(self):
        return self._default_time_to_wait

    @default_time_to_wait.setter
    def default_time_to_wait(self, default_time_to_wait):
        self._default_time_to_wait = default_time_to_wait

    @property
    def error_recovery_level(self) -> ErrorRecoveryLevel:
        return self._error_recovery_level

    @error_recovery_level.setter
    def error_recovery_level(self, error_recovery_level: ErrorRecoveryLevel):
        self._error_recovery_level = error_recovery_level

    @property
    def max_outstanding_r2t(self):
        return self._max_outstanding_r2t

    @max_outstanding_r2t.setter
    def max_outstanding_r2t(self, max_outstanding_r2t):
        self._max_outstanding_r2t = max_outstanding_r2t

    @property
    def first_burst_length(self):
        return self._first_burst_length

    @first_burst_length.setter
    def first_burst_length(self, first_burst_length):
        self._first_burst_length = first_burst_length

    @property
    def max_burst_length(self):
        return self._max_burst_length

    @max_burst_length.setter
    def max_burst_length(self, max_burst_length):
        self._max_burst_length = max_burst_length

    @property
    def login_retry_max(self):
        return self._login_retry_max

    @login_retry_max.setter
    def login_retry_max(self, login_retry_max):
        self._login_retry_max = login_retry_max

    @property
    def logout_timeout(self):
        return self._logout_timeout

    @logout_timeout.setter
    def logout_timeout(self, logout_timeout):
        self._logout_timeout = logout_timeout

    @property
    def login_timeout(self):
        return self._login_timeout

    @login_timeout.setter
    def login_timeout(self, login_timeout):
        self._login_timeout = login_timeout

    @property
    def noop_out_interval(self):
        return self._noop_out_interval

    @noop_out_interval.setter
    def noop_out_interval(self, noop_out_interval):
        self._noop_out_interval = noop_out_interval

    @property
    def noop_out_timeout(self):
        return self._noop_out_timeout

    @noop_out_timeout.setter
    def noop_out_timeout(self, noop_out_timeout):
        self._noop_out_timeout = noop_out_timeout

    @property
    def delayed_ack(self) -> bool:
        return self._delayed_ack

    @delayed_ack.setter
    def delayed_ack(self, delayed_ack: bool):
        self._delayed_ack = delayed_ack

    @property
    def max_recv_data_segment_length(self):
        return self._max_recv_data_segment_length

    @max_recv_data_segment_length.setter
    def max_recv_data_segment_length(self, max_recv_data_segment_length):
        self._max_recv_data_segment_length = max_recv_data_segment_length


class Target(AdvancedOptions):
    """Class to store discovery send targets for storage adapter"""

    def __init__(self, address=None, port=3260, type: TargetType = None,
                 chap_authentication: ChapAuthentication = None):
        super().__init__()
        self._address = address
        self._port = port
        self._type = type
        self._chap_authentication = chap_authentication

    @property
    def address(self):
        """
        Return the target ip address.
        :return: ip address
        :rtype: str
        """
        return self._address

    @address.setter
    def address(self, address):
        """
        Set the target ip address.
        :param address: ip address
        :type address: str
        """
        self._address = address

    @property
    def port(self) -> int:
        """
        Return the target port.
        :return: target port
        :rtype: int
        """
        return self._port

    @port.setter
    def port(self, port: int):
        """
        Set the target port.
        :param port: target port
        :type port: int
        """
        self._port = port

    @property
    def type(self) -> TargetType:
        """
        Return the target type.
        :return: target type
        :rtype: TargetType
        """
        return self._type

    @type.setter
    def type(self, target_type: TargetType):
        """
        Set the target type.
        :param target_type: send of static target
        :type target_type: TargetType
        """
        self._type = target_type

    @property
    def chap_authentication(self) -> ChapAuthentication:
        """
        Return the chap authentication.
        :return: chap authentication
        :rtype: ChapAuthentication
        """
        return self._chap_authentication

    @chap_authentication.setter
    def chap_authentication(self, chap_authentication: ChapAuthentication):
        """
        Set the chap authentication.
        :param chap_authentication: chap authentication
        :type chap_authentication: ChapAuthentication
        """
        self._chap_authentication = chap_authentication


class BaseAdapter(AdvancedOptions):
    """Class to store adapter information for storage ISCSI object"""

    def __init__(self, iqn=None, alias=None, vmknics: List[str] = None, chap_authentication: ChapAuthentication = None,
                 discovery_send_targets: List[Target] = None, targets: List[Target] = None):
        super().__init__()
        self._iqn = iqn
        self._alias = alias
        self._vmknics = vmknics
        self._chap_authentication = chap_authentication
        self._discovery_send_targets = discovery_send_targets
        self._targets = targets

    @property
    def iqn(self):
        """
        Add the iqn.
        :return: iqn
        :rtype: str
        """
        return self._iqn

    @iqn.setter
    def iqn(self, iqn):
        """
        Set the iqn.
        :param iqn: the iqn
        :type iqn: str
        """
        self._iqn = iqn

    @property
    def alias(self):
        """
        Return the alias.
        :return: alias name
        :rtype: str
        """
        return self._alias

    @alias.setter
    def alias(self, alias):
        """
        Set the alias.
        :param alias: alias name
        :type alias: str
        """
        self._alias = alias

    @property
    def vmknics(self) -> List[str]:
        """
        Return the vmknics.
        :return: the vmknics information
        :rtype: List[str]
        """
        return self._vmknics

    @vmknics.setter
    def vmknics(self, vmknics: List[str]):
        """
        Set the vmknics.
        :param vmknics: the vmknics information
        :type vmknics: List[str]
        """
        self._vmknics = vmknics

    @property
    def chap_authentication(self) -> ChapAuthentication:
        """
        Return the chap authentication.
        :return: the chap authentication information
        :rtype: ChapAuthentication
        """
        return self._chap_authentication

    @chap_authentication.setter
    def chap_authentication(self, chap_authentication: ChapAuthentication):
        """
        Set the chap authentication.
        :param chap_authentication: the chap authentication information
        :type chap_authentication: ChapAuthentication
        """
        self._chap_authentication = chap_authentication

    @property
    def discovery_send_targets(self) -> List[Target]:
        """
        Return the discovery send targets.
        :return: the list of send targets
        :rtype: List[Target]
        """
        return self._discovery_send_targets

    @discovery_send_targets.setter
    def discovery_send_targets(self, discovery_send_targets: List[Target]):
        """
        Set the discovery send targets.
        :param discovery_send_targets: the list of send targets
        :type discovery_send_targets: List[Target]
        """
        self._discovery_send_targets = discovery_send_targets

    @property
    def targets(self) -> List[Target]:
        """
        Return the static configured targets.
        :return: the list of static targets
        :rtype: List[Target]
        """
        return self._targets

    @targets.setter
    def targets(self, targets: List[Target]):
        """
        Set the static configured targets.
        :param targets: the list of static targets
        :type targets: List[Target]
        """
        self._targets = targets


class StorageISCSISoftwareAdapter(BaseAdapter):
    """Class to set software adapter for storage iscsi config"""

    def __init__(self):
        super().__init__()
        self._enabled = False

    @property
    def enabled(self):
        """
        Return if enabled or not.
        :return: enabled or not
        :rtype: bool
        """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled: bool):
        """
        Set enabled.
        :param enabled: enabled = true
        :type enabled: bool
        """
        self._enabled = enabled


class StorageISCSIHardwareAdapter(BaseAdapter):
    """Class to set hardware adapter for storage iscsi config"""

    def __init__(self, vmhba=None, type: AdapterType = None, independent_networking: IndependentNetworking = None):
        super().__init__()
        self._vmhba = vmhba
        self._type = type
        self._independent_networking = independent_networking

    @property
    def vmhba(self):
        """
        Return the hardware adapter name
        :return: hardware adapter name
        :rtype: str
        """
        return self._vmhba

    @vmhba.setter
    def vmhba(self, vmhba):
        """
        Set hardware adapter name.
        :param vmhba: hardware adapter name
        :type vmhba: str
        """
        self._vmhba = vmhba

    @property
    def type(self) -> AdapterType:
        """
        Get adapter type.
        :return: independent or dependent adapter type
        :rtype: AdapterType
        """
        return self._type

    @type.setter
    def type(self, adapter_type: AdapterType):
        """
        Set adapter type.
        :param adapter_type: independent or dependent adapter type
        :type adapter_type: AdapterType
        """
        self._type = adapter_type

    @property
    def independent_networking(self) -> IndependentNetworking:
        """
        Get independent networking.
        :return: independent networking for the adapter
        :rtype: IndependentNetworking
        """
        return self._independent_networking

    @independent_networking.setter
    def independent_networking(self, independent_networking: IndependentNetworking):
        """
        Set independent networking.
        :param independent_networking: independent networking for the adapter
        :type independent_networking: IndependentNetworking
        """
        self._independent_networking = independent_networking


class StorageISCSIConfigModel(BaseModel):
    """Class to set Storage ISCSI config for ESXi host."""

    def __init__(self, software_adapter: StorageISCSISoftwareAdapter = None,
                 hardware_adapters: List[StorageISCSIHardwareAdapter] = None):
        self._software_adapter = software_adapter
        self._hardware_adapters = hardware_adapters

    @property
    def software_adapter(self) -> StorageISCSISoftwareAdapter:
        """
        Get software adapter.
        :return: software adapter
        :rtype: StorageISCSISoftwareAdapter
        """
        return self._software_adapter

    @software_adapter.setter
    def software_adapter(self, software_adapter: StorageISCSISoftwareAdapter):
        """
        Set software adapter.
        :param software_adapter: software adapter information
        :type software_adapter: StorageISCSISoftwareAdapter
        """
        self._software_adapter = software_adapter

    @property
    def hardware_adapters(self) -> List[StorageISCSIHardwareAdapter]:
        """
        Get hardware adapter.
        :return: hardware adapter
        :rtype: StorageISCSIHardwareAdapter
        """
        return self._hardware_adapters

    @hardware_adapters.setter
    def hardware_adapters(self, hardware_adapters: List[StorageISCSIHardwareAdapter]):
        """
        Set hardware adapters.
        :param hardware_adapters: hardware adapter information
        :type hardware_adapters: List[StorageISCSIHardwareAdapter]
        """
        self._hardware_adapters = hardware_adapters
