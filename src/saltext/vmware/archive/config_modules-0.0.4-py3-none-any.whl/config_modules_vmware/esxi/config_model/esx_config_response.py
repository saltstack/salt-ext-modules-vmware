# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from typing import List

from config_modules_vmware.esxi.config_model.base_model import BaseModel


class Profile(BaseModel):
    """
    Class to define the model for profile section of esx config for each host in the esx config response.
    """
    def __init__(self, esx: dict = None):
        self._esx = esx

    @property
    def esx(self):
        """Get esx"""
        return self._esx

    @esx.setter
    def esx(self, esx: dict):
        """Set esx"""
        self._esx = esx


class Config(BaseModel):
    """
    Class to define the model for config section esx config for each host in the esx config response.
    """
    def __init__(self, profile: Profile = None):
        self._profile = profile

    @property
    def profile(self):
        """Get profile"""
        return self._profile

    @profile.setter
    def profile(self, profile: Profile):
        """Set profile"""
        self._profile = profile


class Host(BaseModel):
    """
    Class to define the model for host object in the esx config response.
    """
    def __init__(self, config: Config = None, name=None, moid=None):
        self._config = config
        self._name = name
        self._moid = moid

    @property
    def config(self):
        """Get config"""
        return self._config

    @config.setter
    def config(self, config: Config):
        """Set config"""
        self._config = config

    @property
    def name(self):
        """Get name"""
        return self._name

    @name.setter
    def name(self, name: str):
        """Set name"""
        self._name = name

    @property
    def moid(self):
        """Get moid"""
        return self._moid

    @moid.setter
    def moid(self, moid: str):
        """Set moid"""
        self._moid = moid


class Cluster(BaseModel):
    """
    Class to define the model for cluster object in the esx config response.
    """
    def __init__(self, hosts: List[Host] = None, name: str = None, moid: str = None):
        self._hosts = hosts
        self._name = name
        self._moid = moid
    
    @property
    def hosts(self):
        """Get hosts"""
        return self._hosts

    @hosts.setter
    def hosts(self, hosts: List[Host]):
        """Set hosts"""
        self._hosts = hosts
    
    @property
    def name(self):
        """Get name"""
        return self._name

    @name.setter
    def name(self, name: str):
        """Set name"""
        self._name = name
    
    @property
    def moid(self):
        """Get moid"""
        return self._moid

    @moid.setter
    def moid(self, moid: str):
        """Set moid"""
        self._moid = moid


class EsxConfigResponse(BaseModel):
    """
    Class to define the model for esx config response as output for 'Get Config' API output.
    """
    def __init__(self, clusters: List[Cluster] = None, standalone_hosts: List[Host] = None):
        self._clusters = clusters
        self._standalone_hosts = standalone_hosts

    @property
    def clusters(self):
        """Get clusters"""
        return self._clusters

    @clusters.setter
    def clusters(self, clusters: List[Cluster]):
        """Set clusters"""
        self._clusters = clusters
        
    @property
    def standalone_hosts(self):
        """Get standalone_hosts"""
        return self._standalone_hosts

    @standalone_hosts.setter
    def standalone_hosts(self, standalone_hosts: List[Host]):
        """Set standalone_hosts"""
        self._standalone_hosts = standalone_hosts
