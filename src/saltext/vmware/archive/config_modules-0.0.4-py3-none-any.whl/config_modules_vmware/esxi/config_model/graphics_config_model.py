# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from enum import Enum
from typing import List

from config_modules_vmware.esxi.config_model.base_model import BaseModel

class DefaultType(BaseModel, Enum):
    SHARED = 'shared'
    SHARED_PASSTHRU = 'sharedDirect'

class SharedPassthruAssignmentPolicy(BaseModel, Enum):
    PERFORMANCE = 'performance'
    CONSOLIDATION = 'consolidation'

class Policy(BaseModel):

    def __init__(self, default_type: DefaultType = None, shared_passthru_assignment_policy: SharedPassthruAssignmentPolicy = None):
        self._default_type: default_type
        self._shared_passthru_assignment_policy: shared_passthru_assignment_policy

    @property
    def default_type(self) -> DefaultType:
        """
        Return the default_type.
        :return: default_type
        :rtype: DefaultType
        """
        return self._default_type

    @default_type.setter
    def default_type(self, default_type: DefaultType):
        """
        Set the default_type.
        :param default_type: default_type
        :type default_type: DefaultType
        """
        self._default_type = default_type

    @property
    def shared_passthru_assignment_policy(self) -> SharedPassthruAssignmentPolicy:
        """
        Return the shared_passthru_assignment_policy.
        :return: shared_passthru_assignment_policy
        :rtype: SharedPassthruAssignmentPolicy
        """
        return self._shared_passthru_assignment_policy

    @shared_passthru_assignment_policy.setter
    def shared_passthru_assignment_policy(self, shared_passthru_assignment_policy: SharedPassthruAssignmentPolicy):
        """
        Set the shared_passthru_assignment_policy.
        :param shared_passthru_assignment_policy: shared_passthru_assignment_policy
        :type shared_passthru_assignment_policy: SharedPassthruAssignmentPolicy
        """
        self._shared_passthru_assignment_policy = shared_passthru_assignment_policy

class Device(BaseModel):
    def __init__(self, type: DefaultType = None, device: str = None):
        self._type: DefaultType = type
        self._device: str = device

    @property
    def type(self) -> DefaultType:
        """
        Return the type.
        :return: type
        :rtype: DefaultType
        """
        return self._type

    @type.setter
    def type(self, type: DefaultType):
        """
        Set the type.
        :param type: type
        :type type: DefaultType
        """
        self._type = type

    @property
    def device(self) -> str:
        """
        Return the device.
        :return: device
        :rtype: str
        """
        return self._device

    @device.setter
    def device(self, device: str):
        """
        Set the device.
        :param device: device
        :type device: str
        """
        self._device = device

class GraphicsConfigModel(BaseModel):

    def __init__(self, policy: Policy = None, devices: List[Device] = None):
        self._policy: policy
        self._devices: devices

    @property
    def policy(self) -> Policy:
        """
        Return the policy.
        :return: policy
        :rtype: Policy
        """
        return self._policy

    @policy.setter
    def policy(self, policy: Policy):
        """
        Set the policy.
        :param policy: policy
        :type policy: Policy
        """
        self._policy = policy

    @property
    def devices(self) -> List[Device]:
        """
        Return the devices.
        :return: devices
        :rtype: Devices
        """
        return self._devices

    @devices.setter
    def devices(self, devices: List[Device]):
        """
        Set the devices.
        :param devices: devices
        :type devices: Devices
        """
        self._devices = devices

