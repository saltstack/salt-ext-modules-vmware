# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum
from typing import List
from config_modules_vmware.esxi.config_model.base_model import BaseModel


class EnforcementLevel(BaseModel, Enum):
    ENFORCING = 'ENFORCING'
    WARNING = 'WARNING'
    DISABLED = 'DISABLED'


class SecuritySettings(BaseModel):
    """"
        Security settings class
    """

    def __init__(self, password_history: int = None, password_max_days: int = None, ssh_session_limit: int = None,
                 default_shell_access: bool = None, account_lock_failures: int = None,
                 password_quality_control: str = None, account_unlock_time: int = None):
        self._password_history: int = password_history
        self._password_max_days: int = password_max_days
        self._ssh_session_limit: int = ssh_session_limit
        self._default_shell_access: bool = default_shell_access
        self._account_lock_failures: int = account_lock_failures
        self._password_quality_control: str = password_quality_control
        self._account_unlock_time: int = account_unlock_time

    @property
    def password_history(self) -> int:
        """
        Return the password_history.
        :return: password_history
        :rtype: int
        """
        return self._password_history

    @password_history.setter
    def password_history(self, password_history: int):
        """
        Set the password_history.
        :param password_history: password_history
        :type password_history: int
        """
        self._password_history = password_history

    @property
    def password_max_days(self) -> int:
        """
        Return the password_max_days.
        :return: password_max_days
        :rtype: int
        """
        return self._password_max_days

    @password_max_days.setter
    def password_max_days(self, password_max_days: int):
        """
        Set the password_max_days.
        :param password_max_days: password_max_days
        :type password_max_days: int
        """
        self._password_max_days = password_max_days

    @property
    def ssh_session_limit(self) -> int:
        """
        Return the ssh_session_limit.
        :return: ssh_session_limit
        :rtype: int
        """
        return self._ssh_session_limit

    @ssh_session_limit.setter
    def ssh_session_limit(self, ssh_session_limit: int):
        """
        Set the ssh_session_limit.
        :param ssh_session_limit: ssh_session_limit
        :type ssh_session_limit: int
        """
        self._ssh_session_limit = ssh_session_limit

    @property
    def default_shell_access(self) -> bool:
        """
        Return the default_shell_access.
        :return: default_shell_access
        :rtype: bool
        """
        return self._default_shell_access

    @default_shell_access.setter
    def default_shell_access(self, default_shell_access: bool):
        """
        Set the default_shell_access.
        :param default_shell_access: default_shell_access
        :type default_shell_access: bool
        """
        self._default_shell_access = default_shell_access

    @property
    def account_lock_failures(self) -> int:
        """
        Return the account_lock_failures.
        :return: account_lock_failures
        :rtype: int
        """
        return self._account_lock_failures

    @account_lock_failures.setter
    def account_lock_failures(self, account_lock_failures: int):
        """
        Set the account_lock_failures.
        :param account_lock_failures: account_lock_failures
        :type account_lock_failures: int
        """
        self._account_lock_failures = account_lock_failures

    @property
    def password_quality_control(self) -> str:
        """
        Return the password_quality_control.
        :return: password_quality_control
        :rtype: str
        """
        return self._password_quality_control

    @password_quality_control.setter
    def password_quality_control(self, password_quality_control: str):
        """
        Set the password_quality_control.
        :param password_quality_control: password_quality_control
        :type password_quality_control: str
        """
        self._password_quality_control = password_quality_control

    @property
    def account_unlock_time(self) -> int:
        """
        Return the account_unlock_time.
        :return: account_unlock_time
        :rtype: int
        """
        return self._account_unlock_time

    @account_unlock_time.setter
    def account_unlock_time(self, account_unlock_time: int):
        """
        Set the account_unlock_time.
        :param account_unlock_time: account_unlock_time
        :type account_unlock_time: int
        """
        self._account_unlock_time = account_unlock_time


class DomainSetting(BaseModel):
    def __init__(self, domain: str = None, enforcement_level: EnforcementLevel = None):
        self._domain: str = domain
        self._enforcement_level: EnforcementLevel = enforcement_level

    @property
    def domain(self) -> str:
        """
        Return the domain.
        :return: domain
        :rtype: str
        """
        return self._domain

    @domain.setter
    def domain(self, domain: str):
        """
        Set the domain.
        :param domain: domain
        :type domain: str
        """
        self._domain = domain

    @property
    def enforcement_level(self) -> EnforcementLevel:
        """
        Return the enforcement_level.
        :return: enforcement_level
        :rtype: EnforcementLevel
        """
        return self._enforcement_level

    @enforcement_level.setter
    def enforcement_level(self, enforcement_level: EnforcementLevel):
        """
        Set the enforcement_level.
        :param enforcement_level: enforcement_level
        :type enforcement_level: EnforcementLevel
        """
        self._enforcement_level = enforcement_level


class Security(BaseModel):
    def __init__(self, settings: SecuritySettings = None, domain_settings: List[DomainSetting] = None):
        self._settings: SecuritySettings = settings
        self._domain_settings: List[DomainSetting] = domain_settings

    @property
    def settings(self) -> SecuritySettings:
        """
        Return the security_settings.
        :return: security_settings
        :rtype: SecuritySettings
        """
        return self._settings

    @settings.setter
    def settings(self, settings: SecuritySettings):
        """
        Set the settings.
        :param settings: security_settings
        :type settings: security_settings
        """
        self._settings = settings

    @property
    def domain_settings(self) -> List[DomainSetting]:
        """
        Return the domain_settings.
        :return: domain_settings
        :rtype: List[DomainSetting]
        """
        return self._domain_settings

    @domain_settings.setter
    def domain_settings(self, domain_settings: List[DomainSetting]):
        """
        Set the domain_settings.
        :param domain_settings: domain_settings
        :type domain_settings: List[DomainSetting]
        """
        self._domain_settings = domain_settings
