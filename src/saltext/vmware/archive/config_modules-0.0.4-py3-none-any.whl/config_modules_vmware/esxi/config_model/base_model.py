# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import six
import inspect

from enum import Enum


class BaseModel(object):
    """Class to be inherited by each module class. This class will have common methods across modules """

    def to_dict(self, strip_privates=True, strip_null=True):
        """Returns the model properties as a dict
        @param strip_privates: remove all attributes without a getter, setter (property)
        @param strip_null: remove attributes with null values
        :rtype: dict
        """
        result = {}
        for attr, _ in inspect.getmembers(self, lambda member: not(inspect.ismethod(member)) and not(inspect.isclass(member))):
            if strip_privates and attr.startswith('_'):
                continue
            value = getattr(self, attr)
            if strip_null and value is None:
                continue
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict(strip_privates, strip_null) if hasattr(x, "to_dict") else x,
                    value
                ))
            elif isinstance(value, Enum):
                result[attr] = value.name
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict(strip_privates, strip_null)
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict(strip_privates, strip_null))
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        return result
