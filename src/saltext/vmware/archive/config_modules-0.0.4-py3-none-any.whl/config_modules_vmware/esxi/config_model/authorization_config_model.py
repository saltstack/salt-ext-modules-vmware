# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from typing import List
from config_modules_vmware.esxi.config_model.base_model import BaseModel


class DcuiAccess(BaseModel):
    """"
    Class to set user has roles for dcui access
    """

    def __init__(self, users):
        self._users = users

    @property
    def users(self):
        """Get user name """
        return self._users

    @users.setter
    def users(self, users: List[str]):
        """Set option name"""
        self._users = users

class Permissions(BaseModel):
    """"
    Class to set user permission for a host
    """

    def __init__(self, principal, is_group, access_mode):
        self._principal = principal
        self._is_group = is_group
        self._access_mode = access_mode

    @property
    def principal(self):
        """Get principal attribute"""
        return self._principal

    @principal.setter
    def principal(self, principal: str):
        """Set principal attribute"""
        self._principal = principal

    @property
    def is_group(self):
        """Get is group attribute """
        return self._is_group

    @is_group .setter
    def is_group(self, is_group: str):
        """Set group attribute"""
        self._is_group = is_group

    @property
    def access_mode(self):
        """Get access mode """
        return self._access_mode

    @access_mode.setter
    def access_mode(self, access_mode: str):
        """Set access mode """
        self._access_mode = access_mode


class SystemUsers(BaseModel):

    """"
    Class to set system users for a host
    """

    def __init__(self, users):
        self._users = users

    @property
    def users(self):
        """Get user """
        return self._users

    @users.setter
    def users(self, users: List[str]):
        """Set users"""
        self._users = users


class AuthorizationData(BaseModel):

    def __init__(self, dcuiaccess, permissions, systemusers):
        self._dcuiaccess = dcuiaccess
        self._permissions = permissions
        self._systemusers = systemusers

    @property
    def dcuiaccess(self):
        """get dcui acesss data """
        return self._dcuiaccess

    @dcuiaccess.setter
    def dcuiaccess(self, dcuiaccess: DcuiAccess):
        """get dcui acesss data """
        self._dcuiaccess = dcuiaccess

    @property
    def permissions(self):
        """get permission  data """
        return self._permissions

    @permissions.setter
    def permissions(self, permissions: List[Permissions]):
        """ set permission data """
        self._permissions = Permissions

    @property
    def systemusers(self):
        """ get system users """
        return self._systemusers

    @systemusers.setter
    def systemusers(self, _systemusers: SystemUsers):
        """set system users """
        self._systemusers = Permissions