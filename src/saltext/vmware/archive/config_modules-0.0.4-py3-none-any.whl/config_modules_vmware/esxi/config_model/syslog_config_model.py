# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum
from typing import List

from config_modules_vmware.esxi.config_model.base_model import BaseModel


class Logfilters(BaseModel):
    """
    Logfilters configuration.
    Log filtering is used to filter out excessive logging. This feature should be
    used only in the case where a log statement is spewing excessively.
    Caution: VMware does not recommend reducing logging as it may make it
    impossible to properly troubleshoot potential future issues.
    """

    def __init__(self, enable_logfilters: bool = None, filters: List[str] = None):
        super().__init__()
        self._enable_logfilters = enable_logfilters
        self._filters = filters

    @property
    def enable_logfilters(self) -> bool:
        """
        This enables filtering of the logs based on the filters added by the user.
        DefaultValue("False").
        :return: This enables filtering of the logs based on the filters added by the user.
        :rtype: bool.
        """
        return self._enable_logfilters

    @enable_logfilters.setter
    def enable_logfilters(self, enable_logfilters: bool):
        """
        Enables filtering of the logs based on the filters added by the user.
        :param enable_logfilters: enables filtering of the logs based on the filters added by the user.
        :type enable_logfilters: bool.
        """
        self._enable_logfilters = enable_logfilters

    @property
    def filters(self) -> List[str]:
        """
        List of filters based on which logs will be filtered.
        Each filter should follow the syntax:
        numLogs | ident | logRegexp
        For example: 0 | vmkernel | bad CDB .* scsi_op=0x9e
        numLogs - This value is the number of times the log entry can appear
        before it is filtered and excluded from system logs.

        ident - This value is used to identify the originating location of the
        log expression. Multiple ident values can be specified in a comma
        separated list. Using '*' for the ident field implies that log messages
        from all sources are a potential match. Refer /etc/vmsyslog.conf.d/*.conf
        files for all available values.

        logRegexp - This value is used to define the log expression to exclude
        conforming to the Python regular expression syntax.
        All comparisons are case-sensitive.
        :return: filters.
        :rtype: List[string]
        """
        return self._filters

    @filters.setter
    def filters(self, filters: List[str]):
        """
        Set the List of filters based om which logs will be filtered.
        :param filters: List of filters based om which logs will be filtered.
        :type filters: List[str].
        """
        self._filters = filters


class LoggerSettings(BaseModel):
    """
    Sub-loggers configuration to individually set the logging configuration for.
    system components such as auth, vmkernel, hostd etc.
    """

    def __init__(self, logger: str, rotation_size_in_kb: int = None, rotations: int = None, name: str = None,
                 description: str = None, log_file_name: str = None, file_logger_class: str = None,
                 network_logger_class: str = None, on_rotate: str = None, identifications: str = None,
                 conf_file: str = None):
        super().__init__()
        self._logger = logger
        self._rotation_size_in_kb = rotation_size_in_kb
        self._rotations = rotations
        self._name = name
        self._description = description
        self._log_file_name = log_file_name
        self._file_logger_class = file_logger_class
        self._network_logger_class = network_logger_class
        self._on_rotate = on_rotate
        self._identifications = identifications
        self._conf_file = conf_file

    @property
    def logger(self) -> str:
        """
        The unique ID of the logger to identify.
        :return: The unique ID of the logger to identify.
        :rtype: string.
        """
        return self._logger

    @logger.setter
    def logger(self, logger: str):
        """
        Set the unique ID of the logger to identify.
        :param logger: the unique ID of the logger to identify.
        :type logger: str.
        """
        self._logger = logger

    @property
    def rotation_size_in_kb(self) -> int:
        """
        Set size of logs before rotation for a specific logger, in KiB.
        minimum("1") maximum("102400").
        :return: Set size of logs before rotation for a specific logger, in KiB.
        :rtype: int.
        """
        return self._rotation_size_in_kb

    @rotation_size_in_kb.setter
    def rotation_size_in_kb(self, rotation_size_in_kb: int):
        """
        Set the size of logs before rotation for a specific logger, in KiB.
        :param rotation_size_in_kb: size of logs before rotation for a specific logger, in KiB.
        :type rotation_size_in_kb: int.
        """
        self._rotation_size_in_kb = rotation_size_in_kb

    @property
    def rotations(self) -> int:
        """
        Number of rotated logs to keep for a specific logger.
        :return: Number of rotated logs to keep for a specific logger.
        :rtype: int.
        """
        return self._rotations

    @rotations.setter
    def rotations(self, rotations: int):
        """
        Set the number of rotated logs to keep for a specific logger.
        :param rotations: number of rotated logs to keep for a specific logger.
        :type rotations: int.
        """
        self._rotations = rotations

    @property
    def name(self) -> str:
        """
        Descriptive name for the logger. Following properties are readonly and
        users are not expected to modify it.
        hidden.
        :return: Descriptive name for the logger.
        :rtype: string.
        """
        return self._name

    @name.setter
    def name(self, name: str):
        """
        Set the descriptive name for the logger.
        :param name: descriptive name for the logger.
        :type name: str.
        """
        self._name = name

    @property
    def description(self) -> str:
        """
        One-liner description of the logger.
        hidden.
        :return: One-liner description of the logger.
        :rtype: string.
        """
        return self._description

    @description.setter
    def description(self, description: str):
        """
        Set the one-liner description of the logger.
        :param description: one-liner description of the logger.
        :type description: str.
        """
        self._description = description

    @property
    def log_file_name(self) -> str:
        """
        The file to which the logger's log will be redirected to.
        hidden.
        :return: The file to which the logger's log will be redirected to.
        :rtype: string.
        """
        return self._log_file_name

    @log_file_name.setter
    def log_file_name(self, log_file_name: str):
        """
        Set the file name to which the logger's log will be redirected to.
        :param log_file_name:  file name to which the logger's log will be redirected to.
        :type log_file_name: str.
        """
        self._log_file_name = log_file_name

    @property
    def file_logger_class(self) -> str:
        """
        File logger class name.
        hidden.
        :return: File logger class name
        :rtype: string
        """
        return self._file_logger_class

    @file_logger_class.setter
    def file_logger_class(self, file_logger_class: str):
        """
        Set the file logger class name.
        :param file_logger_class: file logger class name.
        :type file_logger_class: str.
        """
        self._file_logger_class = file_logger_class

    @property
    def network_logger_class(self) -> str:
        """
        Network logger class name.
        hidden.
        :return: Network logger class name.
        :rtype: string.
        """
        return self._network_logger_class

    @network_logger_class.setter
    def network_logger_class(self, network_logger_class: str):
        """
        Set the network logger class name.
        :param network_logger_class: network logger class name.
        :type network_logger_class: str.
        """
        self._network_logger_class = network_logger_class

    @property
    def on_rotate(self) -> str:
        """
        Write out the header mentioned in this file(path) on log rotation.
        hidden.
        :return: Write out the header mentioned in this file(path) on log rotation.
        :rtype: str.
        """
        return self._on_rotate

    @on_rotate.setter
    def on_rotate(self, on_rotate: str):
        """
        Set the on rotate.
        :param on_rotate: Write out the header mentioned in this file(path) on log rotation.
        :type on_rotate: str.
        """
        self._on_rotate = on_rotate

    @property
    def identifications(self) -> str:
        """
        Identifications the logger is interested in For example: hostd, Vpxa, Fdm.
        hidden.
        :return: Identifications the logger is interested
        :rtype: str.
        """
        return self._identifications

    @identifications.setter
    def identifications(self, identifications: str):
        """
        Set the Identifications the logger is interested in.
        :param identifications: Identifications the logger is interested in.
        :type identifications: str.
        """
        self._identifications = identifications

    @property
    def conf_file(self) -> str:
        """
        Logger config file name.
        hidden.
        :return:  Logger config file name
        :rtype: str.
        """
        return self._conf_file

    @conf_file.setter
    def conf_file(self, conf_file: str):
        """
        Set the logger config file name.
        :param conf_file: the logger config file name.
        :type conf_file: str.
        """
        self._conf_file = conf_file


class AuditRecordSettings(BaseModel):
    """
     Syslog agent audit records storage configuration.

      There is a special logger for writing audit records to audit record storage
      files.

      Note that audit record storage files are not "log files" and should never be
      treated as such. Use the viewAudit utility or the VIM FetchAuditRecords API
      to access them. An admin can provision (create) local audit record storage by
      specifying the desired storage capacity and a location
      (directory; the default is "/scratch/auditLog").

      Audit records, when enabled to do so, may also be transmitted as part of the
      syslog stream sent on one or more networks to collectors(remote hosts).
    """


    def __init__(self, enable_local_audit_record_storage: bool = None, prevent_record_dropping: bool = None,
                 local_storage_dir: str = None, local_storage_dir_capacity: int = None):
        super().__init__()
        self._enable_local_audit_record_storage = enable_local_audit_record_storage
        self._prevent_record_dropping = prevent_record_dropping
        self._local_storage_dir = local_storage_dir
        self._local_storage_dir_capacity = local_storage_dir_capacity

    @property
    def enable_local_audit_record_storage(self) -> bool:
        """
        Enables storing audit records locally. Default to False
        :return: if it enables storing audit records locally
        :rtype: bool
        """
        return self._enable_local_audit_record_storage

    @enable_local_audit_record_storage.setter
    def enable_local_audit_record_storage(self, enable_local_audit_record_storage: bool):
        """
        Set the enable local audit record storage.
        :param enable_local_audit_record_storage: enable local audit record storage.
        :type enable_local_audit_record_storage: bool.
        """
        self._enable_local_audit_record_storage = enable_local_audit_record_storage

    @property
    def prevent_record_dropping(self) -> bool:
        """
        When a remote host is enabled (the syslog stream is sent to another machine),
        enabling this ensures that the syslog daemon does not drop any audit records.
        Default to False.
        :return if it enables storing audit records locally.
        :rtype: bool.
        """
        return self._prevent_record_dropping

    @prevent_record_dropping.setter
    def prevent_record_dropping(self, prevent_record_dropping: bool):
        """
        Set the prevent record dropping.
        :param prevent_record_dropping: prevent record dropping.
        :type prevent_record_dropping: bool.
        """
        self._prevent_record_dropping = prevent_record_dropping

    @property
    def local_storage_dir(self) -> str:
        """
        The local audit record storage directory; where audit record
        storage files are located. Default to /scratch/auditLog.
        :return: local audit record storage directory.
        :rtype: str.
        """
        return self._local_storage_dir;

    @local_storage_dir.setter
    def local_storage_dir(self, local_storage_dir: str):
        """
        Set the local audit record storage directory.
        :param local_storage_dir: the local audit record storage directory.
        :type local_storage_dir: str.
        """
        self._local_storage_dir = local_storage_dir

    @property
    def local_storage_dir_capacity(self) -> int:
        """
        The local audit record storage directory capacity; where audit
        record storage files are located. minimum("4") maximum("100") defaultValue("4")
        :return: local audit record storage directory capacity.
        :rtype: int.
        """
        return self._local_storage_dir_capacity

    @local_storage_dir_capacity.setter
    def local_storage_dir_capacity(self, local_storage_dir_capacity: int):
        """
        Set the local audit record storage directory capacity.
        :param local_storage_dir_capacity: the local audit record storage directory capacity.
        :type local_storage_dir_capacity: int.
        """
        self._local_storage_dir_capacity = local_storage_dir_capacity


class Protocol(BaseModel, Enum):
    # Supported protocols.
    TCP = "TCP"
    UDP = "UDP"
    SSL = "SSL"


class Formatter(BaseModel, Enum):
    # Supported transmission formatters
    NOT_SPECIFIED = "NOT_SPECIFIED"
    RFC_3164 = "RFC_3164"
    RFC_5424 = "RFC_5424"


class Framing(BaseModel, Enum):
    # Supported transmission framings
    NOT_SPECIFIED = "NOT_SPECIFIED"
    OCTET_COUNTING = "OCTET_COUNTING"
    NON_TRANSPARENT = "NON_TRANSPARENT"


class LogLevel(BaseModel, Enum):
    # syslog daemon logging level
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


class LogHost(BaseModel):
    def __init__(self, address: str, port: int = None, protocol: Protocol = None,
                 formatter: Formatter = None,
                 framing: Framing = None):
        super().__init__()
        self._protocol = protocol
        self._address = address
        self._port = port
        self._formatter = formatter
        self._framing = framing

    @property
    def protocol(self) -> Protocol:
        """
        Protocol enum. If not specified, 'UDP' will be used. Sending syslog to a
        remote host via UDP would be lossy as it does not provide retransmission
        of dropped packets and provides no support for authentication or privacy.
        Default to"UDP"
        :return: Protocol enum.
        :rtype: Protocol.
        """
        return self._protocol

    @protocol.setter
    def protocol(self, protocol: Protocol):
        """
        Set the protocol.
        :param protocol: protocol.
        :type protocol: Protocol.
        """
        self._protocol = protocol

    @property
    def address(self) -> str:
        """
        The value of this property should either be an IPv4
        address such as "192.168.0.1", an IPv6 address such as
        "fc00:192:168:0:6cd9:a132:e889:b612 or a fully qualified
        fully qualified domain name (FQDN).
        :return: ip address
        :rtype: string
        """
        return self._address

    @address.setter
    def address(self, address: str):
        """
        Set the address.
        :param address: address.
        :type address: str.
        """
        self._address = address

    @property
    def port(self) -> int:
        """
        Destination Port.
        :return: Destination Port.
        :rtype: int.
        """
        return self._port

    @port.setter
    def port(self, port: int):
        """
        Set the destination Port.
        :param port: destination Port.
        :type port: int.
        """
        self._port = port

    @property
    def formatter(self) -> Formatter:
        """
        Transmission formatter, default to "NOT_SPECIFIED".
        :return: Transmission formatter.
        :rtype: Formatter.
        """
        return self._formatter

    @formatter.setter
    def formatter(self, formatter: Formatter):
        """
        Set the transmission formatter.
        :param formatter: transmission formatter.
        :type formatter: Formatter.
        """
        self._formatter = formatter

    @property
    def framing(self) -> Framing:
        """
        Transmission framing, default to "NOT_SPECIFIED".
        :return: Transmission framing.
        :rtype: Framing.
        """
        return self._framing

    @framing.setter
    def framing(self, framing: Framing):
        """
        Set the transmission framing.
        :param framing: the transmission framing.
        :type framing: Framing.
        """
        self._framing = framing


class RemoteLogging(BaseModel):
    """
    Local syslog service on ESXi can be configured to route log messages over
    the network to a remote syslog log collector.
    """
    def __init__(self, log_host: List[LogHost], crl_check: bool = None,
                 x509_strict: bool = None, check_ssl_certs: bool = None,
                 retry_timeout: int = None):
        super().__init__()
        self._log_host = log_host
        self._crl_check = crl_check
        self._x509_strict = x509_strict
        self._check_ssl_certs = check_ssl_certs
        self._retry_timeout = retry_timeout

    @property
    def log_host(self) -> List[LogHost]:
        """
        Comma-delimited list of remote servers where logs are sent using the syslog protocol
        :return: List of remote hosts to transmit messages to
        :rtype: List[LogHost]
        """
        return self._log_host

    @log_host.setter
    def log_host(self, log_host: List[LogHost]):
        """
        Set the list of remote hosts to transmit messages to
        :param log_host: list of remote hosts to transmit messages to.
        :type log_host: List[LogHost].
        """
        self._log_host = log_host


    @property
    def crl_check(self) -> bool:
        """
        Check revocation status of all the certificates in SSL certificate chain.
        Default value: False.
        :return: Check revocation status of all the certificates in SSL certificate chain
        :rtype: bool.
        """
        return self._crl_check

    @crl_check.setter
    def crl_check(self, crl_check: bool):
        """
        Set the revocation status of all the certificates in SSL certificate chain.
        :param crl_check: the revocation status of all the certificates in SSL certificate chain.
        :type crl_check: bool.
        """
        self._crl_check = crl_check

    @property
    def x509_strict(self) -> bool:
        """
        Strict X.509 compliance when checking SSL certificates.
        Default value: False.
        :return:  Strict X.509 compliance
        :rtype: bool
        """
        return self._x509_strict

    @x509_strict.setter
    def x509_strict(self, x509_strict: bool):
        """
        Set the Strict X.509 compliance when checking SSL certificates.
        :param x509_strict: the Strict X.509 compliance when checking SSL certificates.
        :type x509_strict: bool.
        """
        self._x509_strict = x509_strict

    @property
    def check_ssl_certs(self) -> bool:
        """
        Verify remote SSL certificates against the local CA Store.
        Default value: True.
        :return: if Verify remote SSL certificates against the local CA Store.
        :rtype: bool.
        """
        return self._check_ssl_certs

    @check_ssl_certs.setter
    def check_ssl_certs(self, check_ssl_certs: bool):
        """
        Set the requirement to verify remote SSL certificates against the local CA Store.
        :param check_ssl_certs: Verify remote SSL certificates against the local CA Store.
        :type check_ssl_certs: bool.
        """
        self._check_ssl_certs = check_ssl_certs

    @property
    def retry_timeout(self) -> int:
        """
        Delay before retrying to connect to a remote host after a connection
        attempt has failed (in seconds).
        The default value is 180 seconds.
        :return: teh delay before retrying to connect to a remote host after a connection
            attempt has failed (in seconds).
        :rtype: int.
        """
        return self._retry_timeout

    @retry_timeout.setter
    def retry_timeout(self, retry_timeout: int):
        """
        Set the Delay before retrying to connect to a remote host after a connection
        attempt has failed (in seconds).
        :param retry_timeout: the Delay before retrying to connect to a remote host after a connection
        attempt has failed (in seconds).
        :type retry_timeout: int.
        """
        self._retry_timeout = retry_timeout


class GlobalSettings(BaseModel):
    """
    Global syslog configuration. This configuration will be applicable for
    messages logged to syslog.log and sub-loggers as well. However, sub-loggers
    can override the rotate and size values for them.
    """

    def __init__(self, vsan_backing: bool = None, log_dir_unique: bool = None, rotations: int = None,
                 rotation_size_in_kb: int = None, drop_log_rotate: int = None, drop_log_size: int = None,
                 queue_drop_mark: int = None, log_dir: str = None, log_level: LogLevel = None,
                 remote_logging: RemoteLogging = None, remote_host_max_msg_len: int = None):
        super().__init__()
        self._vsan_backing = vsan_backing
        self._log_dir_unique = log_dir_unique
        self._rotations = rotations
        self._rotation_size_in_kb = rotation_size_in_kb
        self._drop_log_rotate = drop_log_rotate
        self._drop_log_size = drop_log_size
        self._queue_drop_mark = queue_drop_mark
        self._log_dir = log_dir
        self._log_level = log_level
        self._remote_logging = remote_logging
        self._remote_host_max_msg_len = remote_host_max_msg_len

    @property
    def vsan_backing(self) -> bool:
        """
        Allows the log and audit record storage directories to be placed on a VSAN.
        defaultValue("True")
        :return: Allows the log and audit record storage directories to be placed on a VSAN
        :rtype: bool
        """
        return self._vsan_backing

    @vsan_backing.setter
    def vsan_backing(self, vsan_backing: bool):
        """
        Set the Allows the log and audit record storage directories to be placed on a VSAN.
        :param vsan_backing: Allows the log and audit record storage directories to be placed on a VSAN.
        :type vsan_backing: bool.
        """
        self._vsan_backing = vsan_backing

    @property
    def log_dir_unique(self) -> bool:
        """
        Place logs in a unique subdirectory of logdir, based on hostname.
        @defaultValue("False")
        :return: Place logs in a unique subdirectory of logdir, based on hostname.
        :rtype: bool.
        """
        return self._log_dir_unique

    @log_dir_unique.setter
    def log_dir_unique(self, log_dir_unique: bool):
        """
        Set the place logs in a unique subdirectory of logdir.
        :param log_dir_unique: Place logs in a unique subdirectory of logdir.
        :type log_dir_unique: bool.
        """
        self._log_dir_unique = log_dir_unique

    @property
    def rotations(self) -> int:
        """
        Number of older log files to keep.
        The default value is 8.
        :return: Number of older log files to keep.
        :rtype: int.
        """
        return self._rotations

    @rotations.setter
    def rotations(self, rotations: int):
        """
        Set the number of older log files to keep.
        :param rotations: number of older log files to keep.
        :type rotations: int.
        """
        self._rotations = rotations

    @property
    def rotation_size_in_kb(self) -> int:
        """
        Size of each log file before switching to a new one (in KiB).
        The default value is 1024.
        :return: Size of each log file before switching to a new one (in KiB).
        :rtype: bool.
        """
        return self._rotation_size_in_kb

    @rotation_size_in_kb.setter
    def rotation_size_in_kb(self, rotation_size_in_kb: int):
        """
        Set the size of each log file before switching to a new one (in KiB).
        :param rotation_size_in_kb: size of each log file before switching to a new one (in KiB).
        :type rotation_size_in_kb: int.
        """
        self._rotation_size_in_kb = rotation_size_in_kb

    @property
    def drop_log_rotate(self) -> int:
        """
        Number of older dropped message log files to keep.
        The default value is 10.
        :return: number of older dropped message log files to keep..
        :rtype: int.
        """
        return self._drop_log_rotate

    @drop_log_rotate.setter
    def drop_log_rotate(self, drop_log_rotate: int):
        """
        Set the number of older dropped message log files to keep.
        :param drop_log_rotate: Number of older dropped message log files to keep.
        :type drop_log_rotate: int.
        """
        self._drop_log_rotate = drop_log_rotate

    @property
    def drop_log_size(self) -> int:
        """
        Size of each dropped message log file before switching to a new one (in KiB).
        The default value is 100.
        :return: Size of each dropped message log file before switching to a new one (in KiB).
        :rtype: int.
        """
        return self._drop_log_size

    @drop_log_size.setter
    def drop_log_size(self, drop_log_size: int):
        """
        Set the size of each dropped message log file before switching to a new one (in KiB).
        :param drop_log_size: size of each dropped message log file before switching to a new one (in KiB).
        :type drop_log_size: int.
        """
        self._drop_log_size = drop_log_size

    @property
    def queue_drop_mark(self) -> int:
        """
        Message queue capacity after which messages are dropped (as a percentage).
        The default value is 90.
        :return: Message queue capacity after which messages are dropped (as a percentage).
        :rtype: int.
        """
        return self._queue_drop_mark

    @queue_drop_mark.setter
    def queue_drop_mark(self, queue_drop_mark: int):
        """
        Set the message queue capacity after which messages are dropped (as a percentage).
        :param queue_drop_mark: Message queue capacity after which messages are dropped (as a percentage).
        :type queue_drop_mark: int.
        """
        self._queue_drop_mark = queue_drop_mark

    @property
    def log_dir(self) -> str:
        """
        The directory to output local logs to.
        defaultValue("/scratch/log")
        :return: The directory to output local logs to.
        :rtype: string
        """
        return self._log_dir

    @log_dir.setter
    def log_dir(self, log_dir: str):
        """
        Set the directory to output local logs to.
        :param log_dir: the directory to output local logs to.
        :type log_dir: str.
        """
        self._log_dir = log_dir

    @property
    def log_level(self) -> LogLevel:
        """
        Syslog daemon logging level.
        Caution: Syslog daemon's loglevel should be changed only while debugging
        some issue related to syslog service, as changing the loglevel from its
        default value i.e. 'ERROR' to a more detailed one could affect the overall
        logging performance of the system.
        defaultValue("ERROR")
        :return: Syslog daemon logging level.
        :rtype: LogLevel
        """
        return self._log_level

    @log_level.setter
    def log_level(self, log_level: LogLevel):
        """
        Set the Syslog daemon logging level.
        :param log_level: Syslog daemon logging level.
        :type log_level: LogLevel.
        """
        self._log_level = log_level

    @property
    def remote_logging(self) -> RemoteLogging:
        """
        Remote Logging related config.
        :return: Remote Logging related config.
        :rtype: RemoteLogging
        """
        return self._remote_logging

    @remote_logging.setter
    def remote_logging(self, remote_logging: RemoteLogging):
        """
        Set the remote Logging related config.
        :param remote_logging: Remote Logging related config.
        :type remote_logging: RemoteLogging.
        """
        self._remote_logging = remote_logging

    @property
    def remote_host_max_msg_len(self) -> int:
        """
        Remote host maximum message length (in bytes).
        The maximum length of messages that will transmitted to remote hosts
        when using the TCP and TLS (SSL) protocols. Messages longer than this
        will be truncated.

        CAUTION: Raising this value above 1 KiB (in RFC 3164 environments) or
            2 KiB (in RFC 5424 environments) does not ensure that long
            transmissions will arrive, untouched, at a syslog collector.
            Something in the syslog infrastructure may have transmission
            length limitations. If the maximum message length must be
            raised, set it to the lowest value possible. Caveat Emptor!
            defaultValue("1024")
            minimum("1024") maximum("16384")
          :return: Remote host maximum message length (in bytes).
          :rtype: int
        """
        return self._remote_host_max_msg_len

    @remote_host_max_msg_len.setter
    def remote_host_max_msg_len(self, remote_host_max_msg_len: int):
        """
        Set the remote host maximum message length (in bytes).
        :param remote_host_max_msg_len: remote host maximum message length (in bytes).
        :type remote_host_max_msg_len: int.
        """
        self._remote_host_max_msg_len = remote_host_max_msg_len


class SyslogConfigModel(BaseModel):
    """Class to set Syslog config for ESXi host."""
    _logfilters: Logfilters
    _logger_settings: List[LoggerSettings]
    _global_settings: GlobalSettings
    _audit_record_settings: AuditRecordSettings

    def __init__(self, logfilters: Logfilters = None,
                 logger_settings: List[LoggerSettings] = None,
                 global_settings: GlobalSettings = None,
                 audit_record_settings: AuditRecordSettings = None):
        super().__init__()
        self._logfilters = logfilters
        self._logger_settings = logger_settings
        self._global_settings = global_settings
        self._audit_record_settings = audit_record_settings

    @property
    def logfilters(self) -> Logfilters:
        """
        The yslog log filters.
        :return the syslog log filters.
        :rtype: Logfilters.
        """
        return self._logfilters

    @logfilters.setter
    def logfilters(self, logfilters: Logfilters):
        """
        Set the list of syslog log filters.
        :param logfilters: the list of syslog log filters.
        :type logfilters: Logfilters.
        """
        self._logfilters = logfilters

    @property
    def logger_settings(self) -> List[LoggerSettings]:
        """
        Sub-loggers configuration to individually set the logging configuration.
        :return Sub-loggers configuration to individually set the logging configuration
        :rtype: LoggerSettings
        """
        return self._logger_settings

    @logger_settings.setter
    def logger_settings(self, logger_settings: List[LoggerSettings]):
        """
        Set the sub-loggers configuration to individually set the logging configuration.
        :param logger_settings: sub-loggers configuration to individually set the logging configuration.
        :type logger_settings: List[LoggerSettings].
        """
        self._logger_settings = logger_settings

    @property
    def global_settings(self) -> GlobalSettings:
        """
        Syslog global settings.
        :return Syslog global settings.
        :rtype: GlobalSettings.
        """
        return self._global_settings

    @global_settings.setter
    def global_settings(self, global_settings: GlobalSettings):
        """
        Set the Syslog global settings.
        :param global_settings: Syslog global settings.
        :type global_settings: GlobalSettings.
        """
        self._global_settings = global_settings

    @property
    def audit_record_settings(self) -> AuditRecordSettings:
        """
        Get audit record settings..
        :return: audit record settings.
        :rtype: AuditRecordSettings.
        """
        return self._audit_record_settings

    @audit_record_settings.setter
    def audit_record_settings(self, audit_record_settings: AuditRecordSettings):
        """
        Set the audit record settings.
        :param audit_record_settings: audit record settings.
        :type audit_record_settings: AuditRecordSettings.
        """
        self._audit_record_settings = audit_record_settings

