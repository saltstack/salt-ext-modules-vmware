from enum import Enum
from typing import List
from config_modules_vmware.esxi.config_model.base_model import BaseModel


class EncryptAlgorithm(BaseModel, Enum):
	TDES_CBC = "tdes_cbc"
	AES128_CBC = "aes128_cbc"


class AuthAlgorithm(BaseModel, Enum):
	HMAC_SHA1 = "hmac_sha1"
	HMAC_SHA2_256 = "hmac_sha2_256"


class Mode(BaseModel, Enum):
	TRANSPORT = "transport"
	TUNNEL = "tunnel"


class IpSecurityAssociation(BaseModel):
	def __init__(self, mode: Mode = None, name: str = None, auth_key: str = None, dst_address: str = None, encrypt_key: str = None, src_address: str = None, auth_algorithm: AuthAlgorithm = None, encrypt_algorithm: EncryptAlgorithm = None, sec_parameter_index: str = None):
		self._mode: Mode = mode
		self._name: str = name
		self._auth_key: str = auth_key
		self._dst_address: str = dst_address
		self._encrypt_key: str = encrypt_key
		self._src_address: str = src_address
		self._auth_algorithm: AuthAlgorithm = auth_algorithm
		self._encrypt_algorithm: EncryptAlgorithm = encrypt_algorithm
		self._sec_parameter_index: str = sec_parameter_index

	@property
	def mode(self) -> Mode:
		"""
		Return the mode.
		:return: mode
		:rtype: Mode
		"""
		return self._mode

	@mode.setter
	def mode(self, mode: Mode):
		"""
		Set the mode.
		:param mode: mode
		:type mode: Mode
		"""
		self._mode = mode

	@property
	def name(self) -> str:
		"""
		Return the name.
		:return: name
		:rtype: str
		"""
		return self._name

	@name.setter
	def name(self, name: str):
		"""
		Set the name.
		:param name: name
		:type name: str
		"""
		self._name = name

	@property
	def auth_key(self) -> str:
		"""
		Return the auth_key.
		:return: auth_key
		:rtype: str
		"""
		return self._auth_key

	@auth_key.setter
	def auth_key(self, auth_key: str):
		"""
		Set the auth_key.
		:param auth_key: auth_key
		:type auth_key: str
		"""
		self._auth_key = auth_key

	@property
	def dst_address(self) -> str:
		"""
		Return the dst_address.
		:return: dst_address
		:rtype: str
		"""
		return self._dst_address

	@dst_address.setter
	def dst_address(self, dst_address: str):
		"""
		Set the dst_address.
		:param dst_address: dst_address
		:type dst_address: str
		"""
		self._dst_address = dst_address

	@property
	def encrypt_key(self) -> str:
		"""
		Return the encrypt_key.
		:return: encrypt_key
		:rtype: str
		"""
		return self._encrypt_key

	@encrypt_key.setter
	def encrypt_key(self, encrypt_key: str):
		"""
		Set the encrypt_key.
		:param encrypt_key: encrypt_key
		:type encrypt_key: str
		"""
		self._encrypt_key = encrypt_key

	@property
	def src_address(self) -> str:
		"""
		Return the src_address.
		:return: src_address
		:rtype: str
		"""
		return self._src_address

	@src_address.setter
	def src_address(self, src_address: str):
		"""
		Set the src_address.
		:param src_address: src_address
		:type src_address: str
		"""
		self._src_address = src_address

	@property
	def auth_algorithm(self) -> AuthAlgorithm:
		"""
		Return the auth_algorithm.
		:return: auth_algorithm
		:rtype: AuthAlgorithm
		"""
		return self._auth_algorithm

	@auth_algorithm.setter
	def auth_algorithm(self, auth_algorithm: AuthAlgorithm):
		"""
		Set the auth_algorithm.
		:param auth_algorithm: auth_algorithm
		:type auth_algorithm: AuthAlgorithm
		"""
		self._auth_algorithm = auth_algorithm

	@property
	def encrypt_algorithm(self) -> EncryptAlgorithm:
		"""
		Return the encrypt_algorithm.
		:return: encrypt_algorithm
		:rtype: EncryptAlgorithm
		"""
		return self._encrypt_algorithm

	@encrypt_algorithm.setter
	def encrypt_algorithm(self, encrypt_algorithm: EncryptAlgorithm):
		"""
		Set the encrypt_algorithm.
		:param encrypt_algorithm: encrypt_algorithm
		:type encrypt_algorithm: EncryptAlgorithm
		"""
		self._encrypt_algorithm = encrypt_algorithm

	@property
	def sec_parameter_index(self) -> str:
		"""
		Return the sec_parameter_index.
		:return: sec_parameter_index
		:rtype: str
		"""
		return self._sec_parameter_index

	@sec_parameter_index.setter
	def sec_parameter_index(self, sec_parameter_index: str):
		"""
		Set the sec_parameter_index.
		:param sec_parameter_index: sec_parameter_index
		:type sec_parameter_index: str
		"""
		self._sec_parameter_index = sec_parameter_index


class UpperLayerProtocol(BaseModel, Enum):
	ANY = "any"
	TCP = "tcp"
	UDP = "udp"
	ICMP6 = "icmp6"


class Direction(BaseModel, Enum):
	IN = "in"
	OUT = "out"


class Action(BaseModel, Enum):
	DISCARD = "discard"
	IPSEC = "ipsec"


class IpSecurityPolicy(BaseModel):
	def __init__(self, mode: Mode = None, name: str = None, action: Action = None, dst_port: int = None, src_port: int = None, direction: Direction = None, dst_prefix: int = None, src_prefix: int = None, dst_address: str = None, src_address: str = None, association_name: str = None, upper_layer_protocol: UpperLayerProtocol = None):
		self._mode: Mode = mode
		self._name: str = name
		self._action: Action = action
		self._dst_port: int = dst_port
		self._src_port: int = src_port
		self._direction: Direction = direction
		self._dst_prefix: int = dst_prefix
		self._src_prefix: int = src_prefix
		self._dst_address: str = dst_address
		self._src_address: str = src_address
		self._association_name: str = association_name
		self._upper_layer_protocol: UpperLayerProtocol = upper_layer_protocol

	@property
	def mode(self) -> Mode:
		"""
		Return the mode.
		:return: mode
		:rtype: Mode
		"""
		return self._mode

	@mode.setter
	def mode(self, mode: Mode):
		"""
		Set the mode.
		:param mode: mode
		:type mode: Mode
		"""
		self._mode = mode

	@property
	def name(self) -> str:
		"""
		Return the name.
		:return: name
		:rtype: str
		"""
		return self._name

	@name.setter
	def name(self, name: str):
		"""
		Set the name.
		:param name: name
		:type name: str
		"""
		self._name = name

	@property
	def action(self) -> Action:
		"""
		Return the action.
		:return: action
		:rtype: Action
		"""
		return self._action

	@action.setter
	def action(self, action: Action):
		"""
		Set the action.
		:param action: action
		:type action: Action
		"""
		self._action = action

	@property
	def dst_port(self) -> int:
		"""
		Return the dst_port.
		:return: dst_port
		:rtype: int
		"""
		return self._dst_port

	@dst_port.setter
	def dst_port(self, dst_port: int):
		"""
		Set the dst_port.
		:param dst_port: dst_port
		:type dst_port: int
		"""
		self._dst_port = dst_port

	@property
	def src_port(self) -> int:
		"""
		Return the src_port.
		:return: src_port
		:rtype: int
		"""
		return self._src_port

	@src_port.setter
	def src_port(self, src_port: int):
		"""
		Set the src_port.
		:param src_port: src_port
		:type src_port: int
		"""
		self._src_port = src_port

	@property
	def direction(self) -> Direction:
		"""
		Return the direction.
		:return: direction
		:rtype: Direction
		"""
		return self._direction

	@direction.setter
	def direction(self, direction: Direction):
		"""
		Set the direction.
		:param direction: direction
		:type direction: Direction
		"""
		self._direction = direction

	@property
	def dst_prefix(self) -> int:
		"""
		Return the dst_prefix.
		:return: dst_prefix
		:rtype: int
		"""
		return self._dst_prefix

	@dst_prefix.setter
	def dst_prefix(self, dst_prefix: int):
		"""
		Set the dst_prefix.
		:param dst_prefix: dst_prefix
		:type dst_prefix: int
		"""
		self._dst_prefix = dst_prefix

	@property
	def src_prefix(self) -> int:
		"""
		Return the src_prefix.
		:return: src_prefix
		:rtype: int
		"""
		return self._src_prefix

	@src_prefix.setter
	def src_prefix(self, src_prefix: int):
		"""
		Set the src_prefix.
		:param src_prefix: src_prefix
		:type src_prefix: int
		"""
		self._src_prefix = src_prefix

	@property
	def dst_address(self) -> str:
		"""
		Return the dst_address.
		:return: dst_address
		:rtype: str
		"""
		return self._dst_address

	@dst_address.setter
	def dst_address(self, dst_address: str):
		"""
		Set the dst_address.
		:param dst_address: dst_address
		:type dst_address: str
		"""
		self._dst_address = dst_address

	@property
	def src_address(self) -> str:
		"""
		Return the src_address.
		:return: src_address
		:rtype: str
		"""
		return self._src_address

	@src_address.setter
	def src_address(self, src_address: str):
		"""
		Set the src_address.
		:param src_address: src_address
		:type src_address: str
		"""
		self._src_address = src_address

	@property
	def association_name(self) -> str:
		"""
		Return the association_name.
		:return: association_name
		:rtype: str
		"""
		return self._association_name

	@association_name.setter
	def association_name(self, association_name: str):
		"""
		Set the association_name.
		:param association_name: association_name
		:type association_name: str
		"""
		self._association_name = association_name

	@property
	def upper_layer_protocol(self) -> UpperLayerProtocol:
		"""
		Return the upper_layer_protocol.
		:return: upper_layer_protocol
		:rtype: UpperLayerProtocol
		"""
		return self._upper_layer_protocol

	@upper_layer_protocol.setter
	def upper_layer_protocol(self, upper_layer_protocol: UpperLayerProtocol):
		"""
		Set the upper_layer_protocol.
		:param upper_layer_protocol: upper_layer_protocol
		:type upper_layer_protocol: UpperLayerProtocol
		"""
		self._upper_layer_protocol = upper_layer_protocol


class CongestionControlAlgorithm(BaseModel, Enum):
	NEWRENO = "newreno"
	CUBIC = "cubic"


class Route(BaseModel):
	def __init__(self, gateway: str = None, network: str = None):
		self._gateway: str = gateway
		self._network: str = network

	@property
	def gateway(self) -> str:
		"""
		Return the gateway.
		:return: gateway
		:rtype: str
		"""
		return self._gateway

	@gateway.setter
	def gateway(self, gateway: str):
		"""
		Set the gateway.
		:param gateway: gateway
		:type gateway: str
		"""
		self._gateway = gateway

	@property
	def network(self) -> str:
		"""
		Return the network.
		:return: network
		:rtype: str
		"""
		return self._network

	@network.setter
	def network(self, network: str):
		"""
		Set the network.
		:param network: network
		:type network: str
		"""
		self._network = network


class RoutingConfig(BaseModel):
	def __init__(self, routes: List[Route] = None, v6routes: List[Route] = None, ipv4_default_gateway: str = None, ipv6_default_gateway: str = None):
		self._routes: List[Route] = routes
		self._v6routes: List[Route] = v6routes
		self._ipv4_default_gateway: str = ipv4_default_gateway
		self._ipv6_default_gateway: str = ipv6_default_gateway

	@property
	def routes(self) -> List[Route]:
		"""
		Return the routes.
		:return: routes
		:rtype: List[Route]
		"""
		return self._routes

	@routes.setter
	def routes(self, routes: List[Route]):
		"""
		Set the routes.
		:param routes: routes
		:type routes: List[Route]
		"""
		self._routes = routes

	@property
	def v6routes(self) -> List[Route]:
		"""
		Return the v6routes.
		:return: v6routes
		:rtype: List[Route]
		"""
		return self._v6routes

	@v6routes.setter
	def v6routes(self, v6routes: List[Route]):
		"""
		Set the v6routes.
		:param v6routes: v6routes
		:type v6routes: List[Route]
		"""
		self._v6routes = v6routes

	@property
	def ipv4_default_gateway(self) -> str:
		"""
		Return the ipv4_default_gateway.
		:return: ipv4_default_gateway
		:rtype: str
		"""
		return self._ipv4_default_gateway

	@ipv4_default_gateway.setter
	def ipv4_default_gateway(self, ipv4_default_gateway: str):
		"""
		Set the ipv4_default_gateway.
		:param ipv4_default_gateway: ipv4_default_gateway
		:type ipv4_default_gateway: str
		"""
		self._ipv4_default_gateway = ipv4_default_gateway

	@property
	def ipv6_default_gateway(self) -> str:
		"""
		Return the ipv6_default_gateway.
		:return: ipv6_default_gateway
		:rtype: str
		"""
		return self._ipv6_default_gateway

	@ipv6_default_gateway.setter
	def ipv6_default_gateway(self, ipv6_default_gateway: str):
		"""
		Set the ipv6_default_gateway.
		:param ipv6_default_gateway: ipv6_default_gateway
		:type ipv6_default_gateway: str
		"""
		self._ipv6_default_gateway = ipv6_default_gateway


class EcnStatus(BaseModel, Enum):
	DISABLED = "disabled"
	ENABLED = "enabled"
	ECHOONLY = "echoonly"


class Dns(BaseModel):
	def __init__(self, name_server: List[str] = None, search_domain: List[str] = None):
		self._name_server: List[str] = name_server
		self._search_domain: List[str] = search_domain

	@property
	def name_server(self) -> List[str]:
		"""
		Return the name_server.
		:return: name_server
		:rtype: List[str]
		"""
		return self._name_server

	@name_server.setter
	def name_server(self, name_server: List[str]):
		"""
		Set the name_server.
		:param name_server: name_server
		:type name_server: List[str]
		"""
		self._name_server = name_server

	@property
	def search_domain(self) -> List[str]:
		"""
		Return the search_domain.
		:return: search_domain
		:rtype: List[str]
		"""
		return self._search_domain

	@search_domain.setter
	def search_domain(self, search_domain: List[str]):
		"""
		Set the search_domain.
		:param search_domain: search_domain
		:type search_domain: List[str]
		"""
		self._search_domain = search_domain


class NetStack(BaseModel):
	def __init__(self, dns: Dns = None, key: str = None, name: str = None, host_name: str = None, ecn_status: EcnStatus = None, ipv6_enabled: bool = None, routing_config: RoutingConfig = None, max_connections: int = None, congestion_control_algorithm: CongestionControlAlgorithm = None):
		self._dns: Dns = dns
		self._key: str = key
		self._name: str = name
		self._host_name: str = host_name
		self._ecn_status: EcnStatus = ecn_status
		self._ipv6_enabled: bool = ipv6_enabled
		self._routing_config: RoutingConfig = routing_config
		self._max_connections: int = max_connections
		self._congestion_control_algorithm: CongestionControlAlgorithm = congestion_control_algorithm

	@property
	def dns(self) -> Dns:
		"""
		Return the dns.
		:return: dns
		:rtype: Dns
		"""
		return self._dns

	@dns.setter
	def dns(self, dns: Dns):
		"""
		Set the dns.
		:param dns: dns
		:type dns: Dns
		"""
		self._dns = dns

	@property
	def key(self) -> str:
		"""
		Return the key.
		:return: key
		:rtype: str
		"""
		return self._key

	@key.setter
	def key(self, key: str):
		"""
		Set the key.
		:param key: key
		:type key: str
		"""
		self._key = key

	@property
	def name(self) -> str:
		"""
		Return the name.
		:return: name
		:rtype: str
		"""
		return self._name

	@name.setter
	def name(self, name: str):
		"""
		Set the name.
		:param name: name
		:type name: str
		"""
		self._name = name

	@property
	def host_name(self) -> str:
		"""
		Return the host_name.
		:return: host_name
		:rtype: str
		"""
		return self._host_name

	@host_name.setter
	def host_name(self, host_name: str):
		"""
		Set the host_name.
		:param host_name: host_name
		:type host_name: str
		"""
		self._host_name = host_name

	@property
	def ecn_status(self) -> EcnStatus:
		"""
		Return the ecn_status.
		:return: ecn_status
		:rtype: EcnStatus
		"""
		return self._ecn_status

	@ecn_status.setter
	def ecn_status(self, ecn_status: EcnStatus):
		"""
		Set the ecn_status.
		:param ecn_status: ecn_status
		:type ecn_status: EcnStatus
		"""
		self._ecn_status = ecn_status

	@property
	def ipv6_enabled(self) -> bool:
		"""
		Return the ipv6_enabled.
		:return: ipv6_enabled
		:rtype: bool
		"""
		return self._ipv6_enabled

	@ipv6_enabled.setter
	def ipv6_enabled(self, ipv6_enabled: bool):
		"""
		Set the ipv6_enabled.
		:param ipv6_enabled: ipv6_enabled
		:type ipv6_enabled: bool
		"""
		self._ipv6_enabled = ipv6_enabled

	@property
	def routing_config(self) -> RoutingConfig:
		"""
		Return the routing_config.
		:return: routing_config
		:rtype: RoutingConfig
		"""
		return self._routing_config

	@routing_config.setter
	def routing_config(self, routing_config: RoutingConfig):
		"""
		Set the routing_config.
		:param routing_config: routing_config
		:type routing_config: RoutingConfig
		"""
		self._routing_config = routing_config

	@property
	def max_connections(self) -> int:
		"""
		Return the max_connections.
		:return: max_connections
		:rtype: int
		"""
		return self._max_connections

	@max_connections.setter
	def max_connections(self, max_connections: int):
		"""
		Set the max_connections.
		:param max_connections: max_connections
		:type max_connections: int
		"""
		self._max_connections = max_connections

	@property
	def congestion_control_algorithm(self) -> CongestionControlAlgorithm:
		"""
		Return the congestion_control_algorithm.
		:return: congestion_control_algorithm
		:rtype: CongestionControlAlgorithm
		"""
		return self._congestion_control_algorithm

	@congestion_control_algorithm.setter
	def congestion_control_algorithm(self, congestion_control_algorithm: CongestionControlAlgorithm):
		"""
		Set the congestion_control_algorithm.
		:param congestion_control_algorithm: congestion_control_algorithm
		:type congestion_control_algorithm: CongestionControlAlgorithm
		"""
		self._congestion_control_algorithm = congestion_control_algorithm


class HostName(BaseModel):
	def __init__(self, name: str = None, aliases: List[str] = None, comment: str = None, ip_address: str = None):
		self._name: str = name
		self._aliases: List[str] = aliases
		self._comment: str = comment
		self._ip_address: str = ip_address

	@property
	def name(self) -> str:
		"""
		Return the name.
		:return: name
		:rtype: str
		"""
		return self._name

	@name.setter
	def name(self, name: str):
		"""
		Set the name.
		:param name: name
		:type name: str
		"""
		self._name = name

	@property
	def aliases(self) -> List[str]:
		"""
		Return the aliases.
		:return: aliases
		:rtype: List[str]
		"""
		return self._aliases

	@aliases.setter
	def aliases(self, aliases: List[str]):
		"""
		Set the aliases.
		:param aliases: aliases
		:type aliases: List[str]
		"""
		self._aliases = aliases

	@property
	def comment(self) -> str:
		"""
		Return the comment.
		:return: comment
		:rtype: str
		"""
		return self._comment

	@comment.setter
	def comment(self, comment: str):
		"""
		Set the comment.
		:param comment: comment
		:type comment: str
		"""
		self._comment = comment

	@property
	def ip_address(self) -> str:
		"""
		Return the ip_address.
		:return: ip_address
		:rtype: str
		"""
		return self._ip_address

	@ip_address.setter
	def ip_address(self, ip_address: str):
		"""
		Set the ip_address.
		:param ip_address: ip_address
		:type ip_address: str
		"""
		self._ip_address = ip_address


class EtcHosts(BaseModel):
	def __init__(self, host_names: List[HostName] = None):
		self._host_names: List[HostName] = host_names

	@property
	def host_names(self) -> List[HostName]:
		"""
		Return the host_names.
		:return: host_names
		:rtype: List[HostName]
		"""
		return self._host_names

	@host_names.setter
	def host_names(self, host_names: List[HostName]):
		"""
		Set the host_names.
		:param host_names: host_names
		:type host_names: List[HostName]
		"""
		self._host_names = host_names


class DefaultAction(BaseModel, Enum):
	PASS = "pass"
	DROP = "drop"


class Firewall(BaseModel):
	def __init__(self, enabled: bool = None, default_action: DefaultAction = None):
		self._enabled: bool = enabled
		self._default_action: DefaultAction = default_action

	@property
	def enabled(self) -> bool:
		"""
		Return the enabled.
		:return: enabled
		:rtype: bool
		"""
		return self._enabled

	@enabled.setter
	def enabled(self, enabled: bool):
		"""
		Set the enabled.
		:param enabled: enabled
		:type enabled: bool
		"""
		self._enabled = enabled

	@property
	def default_action(self) -> DefaultAction:
		"""
		Return the default_action.
		:return: default_action
		:rtype: DefaultAction
		"""
		return self._default_action

	@default_action.setter
	def default_action(self, default_action: DefaultAction):
		"""
		Set the default_action.
		:param default_action: default_action
		:type default_action: DefaultAction
		"""
		self._default_action = default_action


class PortConnectionType(BaseModel, Enum):
	VDS = "vds"
	OPAQUE_NETWORK = "opaque_network"
	VSS_PORT_GROUP = "vss_port_group"


class EnabledServices(BaseModel):
	def __init__(self, vsan: bool = None, vmotion: bool = None, witness: bool = None, nvme_tcp: bool = None, nvme_rdma: bool = None, management: bool = None, vsan_replication: bool = None, vsphere_backup_nfc: bool = None, vsphere_replication: bool = None, vsphere_provisioning: bool = None, fault_tolerance_logging: bool = None, precision_time_protocol: bool = None, vsphere_replication_nfc: bool = None):
		self._vsan: bool = vsan
		self._vmotion: bool = vmotion
		self._witness: bool = witness
		self._nvme_tcp: bool = nvme_tcp
		self._nvme_rdma: bool = nvme_rdma
		self._management: bool = management
		self._vsan_replication: bool = vsan_replication
		self._vsphere_backup_nfc: bool = vsphere_backup_nfc
		self._vsphere_replication: bool = vsphere_replication
		self._vsphere_provisioning: bool = vsphere_provisioning
		self._fault_tolerance_logging: bool = fault_tolerance_logging
		self._precision_time_protocol: bool = precision_time_protocol
		self._vsphere_replication_nfc: bool = vsphere_replication_nfc

	@property
	def vsan(self) -> bool:
		"""
		Return the vsan.
		:return: vsan
		:rtype: bool
		"""
		return self._vsan

	@vsan.setter
	def vsan(self, vsan: bool):
		"""
		Set the vsan.
		:param vsan: vsan
		:type vsan: bool
		"""
		self._vsan = vsan

	@property
	def vmotion(self) -> bool:
		"""
		Return the vmotion.
		:return: vmotion
		:rtype: bool
		"""
		return self._vmotion

	@vmotion.setter
	def vmotion(self, vmotion: bool):
		"""
		Set the vmotion.
		:param vmotion: vmotion
		:type vmotion: bool
		"""
		self._vmotion = vmotion

	@property
	def witness(self) -> bool:
		"""
		Return the witness.
		:return: witness
		:rtype: bool
		"""
		return self._witness

	@witness.setter
	def witness(self, witness: bool):
		"""
		Set the witness.
		:param witness: witness
		:type witness: bool
		"""
		self._witness = witness

	@property
	def nvme_tcp(self) -> bool:
		"""
		Return the nvme_tcp.
		:return: nvme_tcp
		:rtype: bool
		"""
		return self._nvme_tcp

	@nvme_tcp.setter
	def nvme_tcp(self, nvme_tcp: bool):
		"""
		Set the nvme_tcp.
		:param nvme_tcp: nvme_tcp
		:type nvme_tcp: bool
		"""
		self._nvme_tcp = nvme_tcp

	@property
	def nvme_rdma(self) -> bool:
		"""
		Return the nvme_rdma.
		:return: nvme_rdma
		:rtype: bool
		"""
		return self._nvme_rdma

	@nvme_rdma.setter
	def nvme_rdma(self, nvme_rdma: bool):
		"""
		Set the nvme_rdma.
		:param nvme_rdma: nvme_rdma
		:type nvme_rdma: bool
		"""
		self._nvme_rdma = nvme_rdma

	@property
	def management(self) -> bool:
		"""
		Return the management.
		:return: management
		:rtype: bool
		"""
		return self._management

	@management.setter
	def management(self, management: bool):
		"""
		Set the management.
		:param management: management
		:type management: bool
		"""
		self._management = management

	@property
	def vsan_replication(self) -> bool:
		"""
		Return the vsan_replication.
		:return: vsan_replication
		:rtype: bool
		"""
		return self._vsan_replication

	@vsan_replication.setter
	def vsan_replication(self, vsan_replication: bool):
		"""
		Set the vsan_replication.
		:param vsan_replication: vsan_replication
		:type vsan_replication: bool
		"""
		self._vsan_replication = vsan_replication

	@property
	def vsphere_backup_nfc(self) -> bool:
		"""
		Return the vsphere_backup_nfc.
		:return: vsphere_backup_nfc
		:rtype: bool
		"""
		return self._vsphere_backup_nfc

	@vsphere_backup_nfc.setter
	def vsphere_backup_nfc(self, vsphere_backup_nfc: bool):
		"""
		Set the vsphere_backup_nfc.
		:param vsphere_backup_nfc: vsphere_backup_nfc
		:type vsphere_backup_nfc: bool
		"""
		self._vsphere_backup_nfc = vsphere_backup_nfc

	@property
	def vsphere_replication(self) -> bool:
		"""
		Return the vsphere_replication.
		:return: vsphere_replication
		:rtype: bool
		"""
		return self._vsphere_replication

	@vsphere_replication.setter
	def vsphere_replication(self, vsphere_replication: bool):
		"""
		Set the vsphere_replication.
		:param vsphere_replication: vsphere_replication
		:type vsphere_replication: bool
		"""
		self._vsphere_replication = vsphere_replication

	@property
	def vsphere_provisioning(self) -> bool:
		"""
		Return the vsphere_provisioning.
		:return: vsphere_provisioning
		:rtype: bool
		"""
		return self._vsphere_provisioning

	@vsphere_provisioning.setter
	def vsphere_provisioning(self, vsphere_provisioning: bool):
		"""
		Set the vsphere_provisioning.
		:param vsphere_provisioning: vsphere_provisioning
		:type vsphere_provisioning: bool
		"""
		self._vsphere_provisioning = vsphere_provisioning

	@property
	def fault_tolerance_logging(self) -> bool:
		"""
		Return the fault_tolerance_logging.
		:return: fault_tolerance_logging
		:rtype: bool
		"""
		return self._fault_tolerance_logging

	@fault_tolerance_logging.setter
	def fault_tolerance_logging(self, fault_tolerance_logging: bool):
		"""
		Set the fault_tolerance_logging.
		:param fault_tolerance_logging: fault_tolerance_logging
		:type fault_tolerance_logging: bool
		"""
		self._fault_tolerance_logging = fault_tolerance_logging

	@property
	def precision_time_protocol(self) -> bool:
		"""
		Return the precision_time_protocol.
		:return: precision_time_protocol
		:rtype: bool
		"""
		return self._precision_time_protocol

	@precision_time_protocol.setter
	def precision_time_protocol(self, precision_time_protocol: bool):
		"""
		Set the precision_time_protocol.
		:param precision_time_protocol: precision_time_protocol
		:type precision_time_protocol: bool
		"""
		self._precision_time_protocol = precision_time_protocol

	@property
	def vsphere_replication_nfc(self) -> bool:
		"""
		Return the vsphere_replication_nfc.
		:return: vsphere_replication_nfc
		:rtype: bool
		"""
		return self._vsphere_replication_nfc

	@vsphere_replication_nfc.setter
	def vsphere_replication_nfc(self, vsphere_replication_nfc: bool):
		"""
		Set the vsphere_replication_nfc.
		:param vsphere_replication_nfc: vsphere_replication_nfc
		:type vsphere_replication_nfc: bool
		"""
		self._vsphere_replication_nfc = vsphere_replication_nfc


class OpaqueNetwork(BaseModel):
	def __init__(self, id: str = None, type: str = None):
		self._id: str = id
		self._type: str = type

	@property
	def id(self) -> str:
		"""
		Return the id.
		:return: id
		:rtype: str
		"""
		return self._id

	@id.setter
	def id(self, id: str):
		"""
		Set the id.
		:param id: id
		:type id: str
		"""
		self._id = id

	@property
	def type(self) -> str:
		"""
		Return the type.
		:return: type
		:rtype: str
		"""
		return self._type

	@type.setter
	def type(self, type: str):
		"""
		Set the type.
		:param type: type
		:type type: str
		"""
		self._type = type


class VdsPort(BaseModel):
	def __init__(self, switch_name: str = None, portgroup_name: str = None):
		self._switch_name: str = switch_name
		self._portgroup_name: str = portgroup_name

	@property
	def switch_name(self) -> str:
		"""
		Return the switch_name.
		:return: switch_name
		:rtype: str
		"""
		return self._switch_name

	@switch_name.setter
	def switch_name(self, switch_name: str):
		"""
		Set the switch_name.
		:param switch_name: switch_name
		:type switch_name: str
		"""
		self._switch_name = switch_name

	@property
	def portgroup_name(self) -> str:
		"""
		Return the portgroup_name.
		:return: portgroup_name
		:rtype: str
		"""
		return self._portgroup_name

	@portgroup_name.setter
	def portgroup_name(self, portgroup_name: str):
		"""
		Set the portgroup_name.
		:param portgroup_name: portgroup_name
		:type portgroup_name: str
		"""
		self._portgroup_name = portgroup_name


class MacMode(BaseModel, Enum):
	PNIC_BASED = "pnic_based"
	USER_DEFINED = "user_defined"
	AUTO_GENERATED = "auto_generated"


class Ipv6Address(BaseModel):
	def __init__(self, address: str = None, prefix_length: int = None):
		self._address: str = address
		self._prefix_length: int = prefix_length

	@property
	def address(self) -> str:
		"""
		Return the address.
		:return: address
		:rtype: str
		"""
		return self._address

	@address.setter
	def address(self, address: str):
		"""
		Set the address.
		:param address: address
		:type address: str
		"""
		self._address = address

	@property
	def prefix_length(self) -> int:
		"""
		Return the prefix_length.
		:return: prefix_length
		:rtype: int
		"""
		return self._prefix_length

	@prefix_length.setter
	def prefix_length(self, prefix_length: int):
		"""
		Set the prefix_length.
		:param prefix_length: prefix_length
		:type prefix_length: int
		"""
		self._prefix_length = prefix_length


class Ipv6(BaseModel):
	def __init__(self, dhcp: bool = None, dhcp_dns: bool = None, ipv6_address: List[Ipv6Address] = None, auto_configuration_enabled: bool = None):
		self._dhcp: bool = dhcp
		self._dhcp_dns: bool = dhcp_dns
		self._ipv6_address: List[Ipv6Address] = ipv6_address
		self._auto_configuration_enabled: bool = auto_configuration_enabled

	@property
	def dhcp(self) -> bool:
		"""
		Return the dhcp.
		:return: dhcp
		:rtype: bool
		"""
		return self._dhcp

	@dhcp.setter
	def dhcp(self, dhcp: bool):
		"""
		Set the dhcp.
		:param dhcp: dhcp
		:type dhcp: bool
		"""
		self._dhcp = dhcp

	@property
	def dhcp_dns(self) -> bool:
		"""
		Return the dhcp_dns.
		:return: dhcp_dns
		:rtype: bool
		"""
		return self._dhcp_dns

	@dhcp_dns.setter
	def dhcp_dns(self, dhcp_dns: bool):
		"""
		Set the dhcp_dns.
		:param dhcp_dns: dhcp_dns
		:type dhcp_dns: bool
		"""
		self._dhcp_dns = dhcp_dns

	@property
	def ipv6_address(self) -> List[Ipv6Address]:
		"""
		Return the ipv6_address.
		:return: ipv6_address
		:rtype: List[Ipv6Address]
		"""
		return self._ipv6_address

	@ipv6_address.setter
	def ipv6_address(self, ipv6_address: List[Ipv6Address]):
		"""
		Set the ipv6_address.
		:param ipv6_address: ipv6_address
		:type ipv6_address: List[Ipv6Address]
		"""
		self._ipv6_address = ipv6_address

	@property
	def auto_configuration_enabled(self) -> bool:
		"""
		Return the auto_configuration_enabled.
		:return: auto_configuration_enabled
		:rtype: bool
		"""
		return self._auto_configuration_enabled

	@auto_configuration_enabled.setter
	def auto_configuration_enabled(self, auto_configuration_enabled: bool):
		"""
		Set the auto_configuration_enabled.
		:param auto_configuration_enabled: auto_configuration_enabled
		:type auto_configuration_enabled: bool
		"""
		self._auto_configuration_enabled = auto_configuration_enabled


class Ip(BaseModel):
	def __init__(self, dhcp: bool = None, ipv6: Ipv6 = None, dhcp_dns: bool = None, ipv4_address: str = None, ipv6_enabled: bool = None, ipv4_subnet_mask: str = None):
		self._dhcp: bool = dhcp
		self._ipv6: Ipv6 = ipv6
		self._dhcp_dns: bool = dhcp_dns
		self._ipv4_address: str = ipv4_address
		self._ipv6_enabled: bool = ipv6_enabled
		self._ipv4_subnet_mask: str = ipv4_subnet_mask

	@property
	def dhcp(self) -> bool:
		"""
		Return the dhcp.
		:return: dhcp
		:rtype: bool
		"""
		return self._dhcp

	@dhcp.setter
	def dhcp(self, dhcp: bool):
		"""
		Set the dhcp.
		:param dhcp: dhcp
		:type dhcp: bool
		"""
		self._dhcp = dhcp

	@property
	def ipv6(self) -> Ipv6:
		"""
		Return the ipv6.
		:return: ipv6
		:rtype: Ipv6
		"""
		return self._ipv6

	@ipv6.setter
	def ipv6(self, ipv6: Ipv6):
		"""
		Set the ipv6.
		:param ipv6: ipv6
		:type ipv6: Ipv6
		"""
		self._ipv6 = ipv6

	@property
	def dhcp_dns(self) -> bool:
		"""
		Return the dhcp_dns.
		:return: dhcp_dns
		:rtype: bool
		"""
		return self._dhcp_dns

	@dhcp_dns.setter
	def dhcp_dns(self, dhcp_dns: bool):
		"""
		Set the dhcp_dns.
		:param dhcp_dns: dhcp_dns
		:type dhcp_dns: bool
		"""
		self._dhcp_dns = dhcp_dns

	@property
	def ipv4_address(self) -> str:
		"""
		Return the ipv4_address.
		:return: ipv4_address
		:rtype: str
		"""
		return self._ipv4_address

	@ipv4_address.setter
	def ipv4_address(self, ipv4_address: str):
		"""
		Set the ipv4_address.
		:param ipv4_address: ipv4_address
		:type ipv4_address: str
		"""
		self._ipv4_address = ipv4_address

	@property
	def ipv6_enabled(self) -> bool:
		"""
		Return the ipv6_enabled.
		:return: ipv6_enabled
		:rtype: bool
		"""
		return self._ipv6_enabled

	@ipv6_enabled.setter
	def ipv6_enabled(self, ipv6_enabled: bool):
		"""
		Set the ipv6_enabled.
		:param ipv6_enabled: ipv6_enabled
		:type ipv6_enabled: bool
		"""
		self._ipv6_enabled = ipv6_enabled

	@property
	def ipv4_subnet_mask(self) -> str:
		"""
		Return the ipv4_subnet_mask.
		:return: ipv4_subnet_mask
		:rtype: str
		"""
		return self._ipv4_subnet_mask

	@ipv4_subnet_mask.setter
	def ipv4_subnet_mask(self, ipv4_subnet_mask: str):
		"""
		Set the ipv4_subnet_mask.
		:param ipv4_subnet_mask: ipv4_subnet_mask
		:type ipv4_subnet_mask: str
		"""
		self._ipv4_subnet_mask = ipv4_subnet_mask


class Vmknic(BaseModel):
	def __init__(self, ip: Ip = None, mtu: int = None, nic: str = None, device: str = None, enabled: bool = None, mac_mode: MacMode = None, vds_port: VdsPort = None, pinned_nic: str = None, port_group: str = None, num_rx_queue: int = None, mac_from_user: str = None, opaque_network: OpaqueNetwork = None, enabled_services: EnabledServices = None, port_connection_type: PortConnectionType = None, net_stack_instance_key: str = None, ip_route_default_gateway: str = None, ip_route_ip_v6_default_gateway: str = None):
		self._ip: Ip = ip
		self._mtu: int = mtu
		self._nic: str = nic
		self._device: str = device
		self._enabled: bool = enabled
		self._mac_mode: MacMode = mac_mode
		self._vds_port: VdsPort = vds_port
		self._pinned_nic: str = pinned_nic
		self._port_group: str = port_group
		self._num_rx_queue: int = num_rx_queue
		self._mac_from_user: str = mac_from_user
		self._opaque_network: OpaqueNetwork = opaque_network
		self._enabled_services: EnabledServices = enabled_services
		self._port_connection_type: PortConnectionType = port_connection_type
		self._net_stack_instance_key: str = net_stack_instance_key
		self._ip_route_default_gateway: str = ip_route_default_gateway
		self._ip_route_ip_v6_default_gateway: str = ip_route_ip_v6_default_gateway

	@property
	def ip(self) -> Ip:
		"""
		Return the ip.
		:return: ip
		:rtype: Ip
		"""
		return self._ip

	@ip.setter
	def ip(self, ip: Ip):
		"""
		Set the ip.
		:param ip: ip
		:type ip: Ip
		"""
		self._ip = ip

	@property
	def mtu(self) -> int:
		"""
		Return the mtu.
		:return: mtu
		:rtype: int
		"""
		return self._mtu

	@mtu.setter
	def mtu(self, mtu: int):
		"""
		Set the mtu.
		:param mtu: mtu
		:type mtu: int
		"""
		self._mtu = mtu

	@property
	def nic(self) -> str:
		"""
		Return the nic.
		:return: nic
		:rtype: str
		"""
		return self._nic

	@nic.setter
	def nic(self, nic: str):
		"""
		Set the nic.
		:param nic: nic
		:type nic: str
		"""
		self._nic = nic

	@property
	def device(self) -> str:
		"""
		Return the device.
		:return: device
		:rtype: str
		"""
		return self._device

	@device.setter
	def device(self, device: str):
		"""
		Set the device.
		:param device: device
		:type device: str
		"""
		self._device = device

	@property
	def enabled(self) -> bool:
		"""
		Return the enabled.
		:return: enabled
		:rtype: bool
		"""
		return self._enabled

	@enabled.setter
	def enabled(self, enabled: bool):
		"""
		Set the enabled.
		:param enabled: enabled
		:type enabled: bool
		"""
		self._enabled = enabled

	@property
	def mac_mode(self) -> MacMode:
		"""
		Return the mac_mode.
		:return: mac_mode
		:rtype: MacMode
		"""
		return self._mac_mode

	@mac_mode.setter
	def mac_mode(self, mac_mode: MacMode):
		"""
		Set the mac_mode.
		:param mac_mode: mac_mode
		:type mac_mode: MacMode
		"""
		self._mac_mode = mac_mode

	@property
	def vds_port(self) -> VdsPort:
		"""
		Return the vds_port.
		:return: vds_port
		:rtype: VdsPort
		"""
		return self._vds_port

	@vds_port.setter
	def vds_port(self, vds_port: VdsPort):
		"""
		Set the vds_port.
		:param vds_port: vds_port
		:type vds_port: VdsPort
		"""
		self._vds_port = vds_port

	@property
	def pinned_nic(self) -> str:
		"""
		Return the pinned_nic.
		:return: pinned_nic
		:rtype: str
		"""
		return self._pinned_nic

	@pinned_nic.setter
	def pinned_nic(self, pinned_nic: str):
		"""
		Set the pinned_nic.
		:param pinned_nic: pinned_nic
		:type pinned_nic: str
		"""
		self._pinned_nic = pinned_nic

	@property
	def port_group(self) -> str:
		"""
		Return the port_group.
		:return: port_group
		:rtype: str
		"""
		return self._port_group

	@port_group.setter
	def port_group(self, port_group: str):
		"""
		Set the port_group.
		:param port_group: port_group
		:type port_group: str
		"""
		self._port_group = port_group

	@property
	def num_rx_queue(self) -> int:
		"""
		Return the num_rx_queue.
		:return: num_rx_queue
		:rtype: int
		"""
		return self._num_rx_queue

	@num_rx_queue.setter
	def num_rx_queue(self, num_rx_queue: int):
		"""
		Set the num_rx_queue.
		:param num_rx_queue: num_rx_queue
		:type num_rx_queue: int
		"""
		self._num_rx_queue = num_rx_queue

	@property
	def mac_from_user(self) -> str:
		"""
		Return the mac_from_user.
		:return: mac_from_user
		:rtype: str
		"""
		return self._mac_from_user

	@mac_from_user.setter
	def mac_from_user(self, mac_from_user: str):
		"""
		Set the mac_from_user.
		:param mac_from_user: mac_from_user
		:type mac_from_user: str
		"""
		self._mac_from_user = mac_from_user

	@property
	def opaque_network(self) -> OpaqueNetwork:
		"""
		Return the opaque_network.
		:return: opaque_network
		:rtype: OpaqueNetwork
		"""
		return self._opaque_network

	@opaque_network.setter
	def opaque_network(self, opaque_network: OpaqueNetwork):
		"""
		Set the opaque_network.
		:param opaque_network: opaque_network
		:type opaque_network: OpaqueNetwork
		"""
		self._opaque_network = opaque_network

	@property
	def enabled_services(self) -> EnabledServices:
		"""
		Return the enabled_services.
		:return: enabled_services
		:rtype: EnabledServices
		"""
		return self._enabled_services

	@enabled_services.setter
	def enabled_services(self, enabled_services: EnabledServices):
		"""
		Set the enabled_services.
		:param enabled_services: enabled_services
		:type enabled_services: EnabledServices
		"""
		self._enabled_services = enabled_services

	@property
	def port_connection_type(self) -> PortConnectionType:
		"""
		Return the port_connection_type.
		:return: port_connection_type
		:rtype: PortConnectionType
		"""
		return self._port_connection_type

	@port_connection_type.setter
	def port_connection_type(self, port_connection_type: PortConnectionType):
		"""
		Set the port_connection_type.
		:param port_connection_type: port_connection_type
		:type port_connection_type: PortConnectionType
		"""
		self._port_connection_type = port_connection_type

	@property
	def net_stack_instance_key(self) -> str:
		"""
		Return the net_stack_instance_key.
		:return: net_stack_instance_key
		:rtype: str
		"""
		return self._net_stack_instance_key

	@net_stack_instance_key.setter
	def net_stack_instance_key(self, net_stack_instance_key: str):
		"""
		Set the net_stack_instance_key.
		:param net_stack_instance_key: net_stack_instance_key
		:type net_stack_instance_key: str
		"""
		self._net_stack_instance_key = net_stack_instance_key

	@property
	def ip_route_default_gateway(self) -> str:
		"""
		Return the ip_route_default_gateway.
		:return: ip_route_default_gateway
		:rtype: str
		"""
		return self._ip_route_default_gateway

	@ip_route_default_gateway.setter
	def ip_route_default_gateway(self, ip_route_default_gateway: str):
		"""
		Set the ip_route_default_gateway.
		:param ip_route_default_gateway: ip_route_default_gateway
		:type ip_route_default_gateway: str
		"""
		self._ip_route_default_gateway = ip_route_default_gateway

	@property
	def ip_route_ip_v6_default_gateway(self) -> str:
		"""
		Return the ip_route_ip_v6_default_gateway.
		:return: ip_route_ip_v6_default_gateway
		:rtype: str
		"""
		return self._ip_route_ip_v6_default_gateway

	@ip_route_ip_v6_default_gateway.setter
	def ip_route_ip_v6_default_gateway(self, ip_route_ip_v6_default_gateway: str):
		"""
		Set the ip_route_ip_v6_default_gateway.
		:param ip_route_ip_v6_default_gateway: ip_route_ip_v6_default_gateway
		:type ip_route_ip_v6_default_gateway: str
		"""
		self._ip_route_ip_v6_default_gateway = ip_route_ip_v6_default_gateway


class SoftwareSimulation(BaseModel):
	def __init__(self, tagging: bool = None, high_DMA: bool = None, untagging: bool = None, geneve_offload: bool = None, scatter_gather: bool = None, vxlan_encap_offload: bool = None, ipv4_tcp_seg_offload: bool = None, ipv6_tcp_seg_offload: bool = None, ipv4_checksum_offload: bool = None, ipv6_checksum_offload: bool = None, scatter_gather_span_pages: bool = None, offset_based_encap_offload: bool = None, ipv6_ext_hdr_tcp_seg_offload: bool = None, ipv6_ext_hdr_checksum_offload: bool = None):
		self._tagging: bool = tagging
		self._high_DMA: bool = high_DMA
		self._untagging: bool = untagging
		self._geneve_offload: bool = geneve_offload
		self._scatter_gather: bool = scatter_gather
		self._vxlan_encap_offload: bool = vxlan_encap_offload
		self._ipv4_tcp_seg_offload: bool = ipv4_tcp_seg_offload
		self._ipv6_tcp_seg_offload: bool = ipv6_tcp_seg_offload
		self._ipv4_checksum_offload: bool = ipv4_checksum_offload
		self._ipv6_checksum_offload: bool = ipv6_checksum_offload
		self._scatter_gather_span_pages: bool = scatter_gather_span_pages
		self._offset_based_encap_offload: bool = offset_based_encap_offload
		self._ipv6_ext_hdr_tcp_seg_offload: bool = ipv6_ext_hdr_tcp_seg_offload
		self._ipv6_ext_hdr_checksum_offload: bool = ipv6_ext_hdr_checksum_offload

	@property
	def tagging(self) -> bool:
		"""
		Return the tagging.
		:return: tagging
		:rtype: bool
		"""
		return self._tagging

	@tagging.setter
	def tagging(self, tagging: bool):
		"""
		Set the tagging.
		:param tagging: tagging
		:type tagging: bool
		"""
		self._tagging = tagging

	@property
	def high_DMA(self) -> bool:
		"""
		Return the high_DMA.
		:return: high_DMA
		:rtype: bool
		"""
		return self._high_DMA

	@high_DMA.setter
	def high_DMA(self, high_DMA: bool):
		"""
		Set the high_DMA.
		:param high_DMA: high_DMA
		:type high_DMA: bool
		"""
		self._high_DMA = high_DMA

	@property
	def untagging(self) -> bool:
		"""
		Return the untagging.
		:return: untagging
		:rtype: bool
		"""
		return self._untagging

	@untagging.setter
	def untagging(self, untagging: bool):
		"""
		Set the untagging.
		:param untagging: untagging
		:type untagging: bool
		"""
		self._untagging = untagging

	@property
	def geneve_offload(self) -> bool:
		"""
		Return the geneve_offload.
		:return: geneve_offload
		:rtype: bool
		"""
		return self._geneve_offload

	@geneve_offload.setter
	def geneve_offload(self, geneve_offload: bool):
		"""
		Set the geneve_offload.
		:param geneve_offload: geneve_offload
		:type geneve_offload: bool
		"""
		self._geneve_offload = geneve_offload

	@property
	def scatter_gather(self) -> bool:
		"""
		Return the scatter_gather.
		:return: scatter_gather
		:rtype: bool
		"""
		return self._scatter_gather

	@scatter_gather.setter
	def scatter_gather(self, scatter_gather: bool):
		"""
		Set the scatter_gather.
		:param scatter_gather: scatter_gather
		:type scatter_gather: bool
		"""
		self._scatter_gather = scatter_gather

	@property
	def vxlan_encap_offload(self) -> bool:
		"""
		Return the vxlan_encap_offload.
		:return: vxlan_encap_offload
		:rtype: bool
		"""
		return self._vxlan_encap_offload

	@vxlan_encap_offload.setter
	def vxlan_encap_offload(self, vxlan_encap_offload: bool):
		"""
		Set the vxlan_encap_offload.
		:param vxlan_encap_offload: vxlan_encap_offload
		:type vxlan_encap_offload: bool
		"""
		self._vxlan_encap_offload = vxlan_encap_offload

	@property
	def ipv4_tcp_seg_offload(self) -> bool:
		"""
		Return the ipv4_tcp_seg_offload.
		:return: ipv4_tcp_seg_offload
		:rtype: bool
		"""
		return self._ipv4_tcp_seg_offload

	@ipv4_tcp_seg_offload.setter
	def ipv4_tcp_seg_offload(self, ipv4_tcp_seg_offload: bool):
		"""
		Set the ipv4_tcp_seg_offload.
		:param ipv4_tcp_seg_offload: ipv4_tcp_seg_offload
		:type ipv4_tcp_seg_offload: bool
		"""
		self._ipv4_tcp_seg_offload = ipv4_tcp_seg_offload

	@property
	def ipv6_tcp_seg_offload(self) -> bool:
		"""
		Return the ipv6_tcp_seg_offload.
		:return: ipv6_tcp_seg_offload
		:rtype: bool
		"""
		return self._ipv6_tcp_seg_offload

	@ipv6_tcp_seg_offload.setter
	def ipv6_tcp_seg_offload(self, ipv6_tcp_seg_offload: bool):
		"""
		Set the ipv6_tcp_seg_offload.
		:param ipv6_tcp_seg_offload: ipv6_tcp_seg_offload
		:type ipv6_tcp_seg_offload: bool
		"""
		self._ipv6_tcp_seg_offload = ipv6_tcp_seg_offload

	@property
	def ipv4_checksum_offload(self) -> bool:
		"""
		Return the ipv4_checksum_offload.
		:return: ipv4_checksum_offload
		:rtype: bool
		"""
		return self._ipv4_checksum_offload

	@ipv4_checksum_offload.setter
	def ipv4_checksum_offload(self, ipv4_checksum_offload: bool):
		"""
		Set the ipv4_checksum_offload.
		:param ipv4_checksum_offload: ipv4_checksum_offload
		:type ipv4_checksum_offload: bool
		"""
		self._ipv4_checksum_offload = ipv4_checksum_offload

	@property
	def ipv6_checksum_offload(self) -> bool:
		"""
		Return the ipv6_checksum_offload.
		:return: ipv6_checksum_offload
		:rtype: bool
		"""
		return self._ipv6_checksum_offload

	@ipv6_checksum_offload.setter
	def ipv6_checksum_offload(self, ipv6_checksum_offload: bool):
		"""
		Set the ipv6_checksum_offload.
		:param ipv6_checksum_offload: ipv6_checksum_offload
		:type ipv6_checksum_offload: bool
		"""
		self._ipv6_checksum_offload = ipv6_checksum_offload

	@property
	def scatter_gather_span_pages(self) -> bool:
		"""
		Return the scatter_gather_span_pages.
		:return: scatter_gather_span_pages
		:rtype: bool
		"""
		return self._scatter_gather_span_pages

	@scatter_gather_span_pages.setter
	def scatter_gather_span_pages(self, scatter_gather_span_pages: bool):
		"""
		Set the scatter_gather_span_pages.
		:param scatter_gather_span_pages: scatter_gather_span_pages
		:type scatter_gather_span_pages: bool
		"""
		self._scatter_gather_span_pages = scatter_gather_span_pages

	@property
	def offset_based_encap_offload(self) -> bool:
		"""
		Return the offset_based_encap_offload.
		:return: offset_based_encap_offload
		:rtype: bool
		"""
		return self._offset_based_encap_offload

	@offset_based_encap_offload.setter
	def offset_based_encap_offload(self, offset_based_encap_offload: bool):
		"""
		Set the offset_based_encap_offload.
		:param offset_based_encap_offload: offset_based_encap_offload
		:type offset_based_encap_offload: bool
		"""
		self._offset_based_encap_offload = offset_based_encap_offload

	@property
	def ipv6_ext_hdr_tcp_seg_offload(self) -> bool:
		"""
		Return the ipv6_ext_hdr_tcp_seg_offload.
		:return: ipv6_ext_hdr_tcp_seg_offload
		:rtype: bool
		"""
		return self._ipv6_ext_hdr_tcp_seg_offload

	@ipv6_ext_hdr_tcp_seg_offload.setter
	def ipv6_ext_hdr_tcp_seg_offload(self, ipv6_ext_hdr_tcp_seg_offload: bool):
		"""
		Set the ipv6_ext_hdr_tcp_seg_offload.
		:param ipv6_ext_hdr_tcp_seg_offload: ipv6_ext_hdr_tcp_seg_offload
		:type ipv6_ext_hdr_tcp_seg_offload: bool
		"""
		self._ipv6_ext_hdr_tcp_seg_offload = ipv6_ext_hdr_tcp_seg_offload

	@property
	def ipv6_ext_hdr_checksum_offload(self) -> bool:
		"""
		Return the ipv6_ext_hdr_checksum_offload.
		:return: ipv6_ext_hdr_checksum_offload
		:rtype: bool
		"""
		return self._ipv6_ext_hdr_checksum_offload

	@ipv6_ext_hdr_checksum_offload.setter
	def ipv6_ext_hdr_checksum_offload(self, ipv6_ext_hdr_checksum_offload: bool):
		"""
		Set the ipv6_ext_hdr_checksum_offload.
		:param ipv6_ext_hdr_checksum_offload: ipv6_ext_hdr_checksum_offload
		:type ipv6_ext_hdr_checksum_offload: bool
		"""
		self._ipv6_ext_hdr_checksum_offload = ipv6_ext_hdr_checksum_offload


class LinkSpeedMb(BaseModel, Enum):
	SPEED_10 = "speed_10"
	SPEED_100 = "speed_100"
	SPEED_1000 = "speed_1000"
	SPEED_2500 = "speed_2500"
	SPEED_5000 = "speed_5000"
	SPEED_10000 = "speed_10000"
	SPEED_20000 = "speed_20000"
	SPEED_25000 = "speed_25000"
	SPEED_40000 = "speed_40000"
	SPEED_50000 = "speed_50000"
	SPEED_56000 = "speed_56000"
	SPEED_75000 = "speed_75000"
	SPEED_100000 = "speed_100000"
	SPEED_200000 = "speed_200000"
	SPEED_400000 = "speed_400000"


class LoadBalancer(BaseModel):
	def __init__(self, enable: bool = None, mac_learn: bool = None, geneve_OAM: bool = None, rx_dynamic: bool = None, rx_scaling: bool = None, dynamic_pool: bool = None, numa_dynamic: bool = None, rx_queue_pair: bool = None, large_rx_offload: bool = None, rx_queue_latency: bool = None, rx_queue_no_feature: bool = None, rx_queue_preemptible: bool = None):
		self._enable: bool = enable
		self._mac_learn: bool = mac_learn
		self._geneve_OAM: bool = geneve_OAM
		self._rx_dynamic: bool = rx_dynamic
		self._rx_scaling: bool = rx_scaling
		self._dynamic_pool: bool = dynamic_pool
		self._numa_dynamic: bool = numa_dynamic
		self._rx_queue_pair: bool = rx_queue_pair
		self._large_rx_offload: bool = large_rx_offload
		self._rx_queue_latency: bool = rx_queue_latency
		self._rx_queue_no_feature: bool = rx_queue_no_feature
		self._rx_queue_preemptible: bool = rx_queue_preemptible

	@property
	def enable(self) -> bool:
		"""
		Return the enable.
		:return: enable
		:rtype: bool
		"""
		return self._enable

	@enable.setter
	def enable(self, enable: bool):
		"""
		Set the enable.
		:param enable: enable
		:type enable: bool
		"""
		self._enable = enable

	@property
	def mac_learn(self) -> bool:
		"""
		Return the mac_learn.
		:return: mac_learn
		:rtype: bool
		"""
		return self._mac_learn

	@mac_learn.setter
	def mac_learn(self, mac_learn: bool):
		"""
		Set the mac_learn.
		:param mac_learn: mac_learn
		:type mac_learn: bool
		"""
		self._mac_learn = mac_learn

	@property
	def geneve_OAM(self) -> bool:
		"""
		Return the geneve_OAM.
		:return: geneve_OAM
		:rtype: bool
		"""
		return self._geneve_OAM

	@geneve_OAM.setter
	def geneve_OAM(self, geneve_OAM: bool):
		"""
		Set the geneve_OAM.
		:param geneve_OAM: geneve_OAM
		:type geneve_OAM: bool
		"""
		self._geneve_OAM = geneve_OAM

	@property
	def rx_dynamic(self) -> bool:
		"""
		Return the rx_dynamic.
		:return: rx_dynamic
		:rtype: bool
		"""
		return self._rx_dynamic

	@rx_dynamic.setter
	def rx_dynamic(self, rx_dynamic: bool):
		"""
		Set the rx_dynamic.
		:param rx_dynamic: rx_dynamic
		:type rx_dynamic: bool
		"""
		self._rx_dynamic = rx_dynamic

	@property
	def rx_scaling(self) -> bool:
		"""
		Return the rx_scaling.
		:return: rx_scaling
		:rtype: bool
		"""
		return self._rx_scaling

	@rx_scaling.setter
	def rx_scaling(self, rx_scaling: bool):
		"""
		Set the rx_scaling.
		:param rx_scaling: rx_scaling
		:type rx_scaling: bool
		"""
		self._rx_scaling = rx_scaling

	@property
	def dynamic_pool(self) -> bool:
		"""
		Return the dynamic_pool.
		:return: dynamic_pool
		:rtype: bool
		"""
		return self._dynamic_pool

	@dynamic_pool.setter
	def dynamic_pool(self, dynamic_pool: bool):
		"""
		Set the dynamic_pool.
		:param dynamic_pool: dynamic_pool
		:type dynamic_pool: bool
		"""
		self._dynamic_pool = dynamic_pool

	@property
	def numa_dynamic(self) -> bool:
		"""
		Return the numa_dynamic.
		:return: numa_dynamic
		:rtype: bool
		"""
		return self._numa_dynamic

	@numa_dynamic.setter
	def numa_dynamic(self, numa_dynamic: bool):
		"""
		Set the numa_dynamic.
		:param numa_dynamic: numa_dynamic
		:type numa_dynamic: bool
		"""
		self._numa_dynamic = numa_dynamic

	@property
	def rx_queue_pair(self) -> bool:
		"""
		Return the rx_queue_pair.
		:return: rx_queue_pair
		:rtype: bool
		"""
		return self._rx_queue_pair

	@rx_queue_pair.setter
	def rx_queue_pair(self, rx_queue_pair: bool):
		"""
		Set the rx_queue_pair.
		:param rx_queue_pair: rx_queue_pair
		:type rx_queue_pair: bool
		"""
		self._rx_queue_pair = rx_queue_pair

	@property
	def large_rx_offload(self) -> bool:
		"""
		Return the large_rx_offload.
		:return: large_rx_offload
		:rtype: bool
		"""
		return self._large_rx_offload

	@large_rx_offload.setter
	def large_rx_offload(self, large_rx_offload: bool):
		"""
		Set the large_rx_offload.
		:param large_rx_offload: large_rx_offload
		:type large_rx_offload: bool
		"""
		self._large_rx_offload = large_rx_offload

	@property
	def rx_queue_latency(self) -> bool:
		"""
		Return the rx_queue_latency.
		:return: rx_queue_latency
		:rtype: bool
		"""
		return self._rx_queue_latency

	@rx_queue_latency.setter
	def rx_queue_latency(self, rx_queue_latency: bool):
		"""
		Set the rx_queue_latency.
		:param rx_queue_latency: rx_queue_latency
		:type rx_queue_latency: bool
		"""
		self._rx_queue_latency = rx_queue_latency

	@property
	def rx_queue_no_feature(self) -> bool:
		"""
		Return the rx_queue_no_feature.
		:return: rx_queue_no_feature
		:rtype: bool
		"""
		return self._rx_queue_no_feature

	@rx_queue_no_feature.setter
	def rx_queue_no_feature(self, rx_queue_no_feature: bool):
		"""
		Set the rx_queue_no_feature.
		:param rx_queue_no_feature: rx_queue_no_feature
		:type rx_queue_no_feature: bool
		"""
		self._rx_queue_no_feature = rx_queue_no_feature

	@property
	def rx_queue_preemptible(self) -> bool:
		"""
		Return the rx_queue_preemptible.
		:return: rx_queue_preemptible
		:rtype: bool
		"""
		return self._rx_queue_preemptible

	@rx_queue_preemptible.setter
	def rx_queue_preemptible(self, rx_queue_preemptible: bool):
		"""
		Set the rx_queue_preemptible.
		:param rx_queue_preemptible: rx_queue_preemptible
		:type rx_queue_preemptible: bool
		"""
		self._rx_queue_preemptible = rx_queue_preemptible


class NetQueue(BaseModel):
	def __init__(self, load_balancer: LoadBalancer = None, rx_queue_count: int = None, tx_queue_count: int = None):
		self._load_balancer: LoadBalancer = load_balancer
		self._rx_queue_count: int = rx_queue_count
		self._tx_queue_count: int = tx_queue_count

	@property
	def load_balancer(self) -> LoadBalancer:
		"""
		Return the load_balancer.
		:return: load_balancer
		:rtype: LoadBalancer
		"""
		return self._load_balancer

	@load_balancer.setter
	def load_balancer(self, load_balancer: LoadBalancer):
		"""
		Set the load_balancer.
		:param load_balancer: load_balancer
		:type load_balancer: LoadBalancer
		"""
		self._load_balancer = load_balancer

	@property
	def rx_queue_count(self) -> int:
		"""
		Return the rx_queue_count.
		:return: rx_queue_count
		:rtype: int
		"""
		return self._rx_queue_count

	@rx_queue_count.setter
	def rx_queue_count(self, rx_queue_count: int):
		"""
		Set the rx_queue_count.
		:param rx_queue_count: rx_queue_count
		:type rx_queue_count: int
		"""
		self._rx_queue_count = rx_queue_count

	@property
	def tx_queue_count(self) -> int:
		"""
		Return the tx_queue_count.
		:return: tx_queue_count
		:rtype: int
		"""
		return self._tx_queue_count

	@tx_queue_count.setter
	def tx_queue_count(self, tx_queue_count: int):
		"""
		Set the tx_queue_count.
		:param tx_queue_count: tx_queue_count
		:type tx_queue_count: int
		"""
		self._tx_queue_count = tx_queue_count


class Nic(BaseModel):
	def __init__(self, name: str = None, duplex: bool = None, enabled: bool = None, net_queue: NetQueue = None, rx_ring_size: int = None, tx_ring_size: int = None, link_speed_mb: LinkSpeedMb = None, auto_negotiation: bool = None, software_simulation: SoftwareSimulation = None):
		self._name: str = name
		self._duplex: bool = duplex
		self._enabled: bool = enabled
		self._net_queue: NetQueue = net_queue
		self._rx_ring_size: int = rx_ring_size
		self._tx_ring_size: int = tx_ring_size
		self._link_speed_mb: LinkSpeedMb = link_speed_mb
		self._auto_negotiation: bool = auto_negotiation
		self._software_simulation: SoftwareSimulation = software_simulation

	@property
	def name(self) -> str:
		"""
		Return the name.
		:return: name
		:rtype: str
		"""
		return self._name

	@name.setter
	def name(self, name: str):
		"""
		Set the name.
		:param name: name
		:type name: str
		"""
		self._name = name

	@property
	def duplex(self) -> bool:
		"""
		Return the duplex.
		:return: duplex
		:rtype: bool
		"""
		return self._duplex

	@duplex.setter
	def duplex(self, duplex: bool):
		"""
		Set the duplex.
		:param duplex: duplex
		:type duplex: bool
		"""
		self._duplex = duplex

	@property
	def enabled(self) -> bool:
		"""
		Return the enabled.
		:return: enabled
		:rtype: bool
		"""
		return self._enabled

	@enabled.setter
	def enabled(self, enabled: bool):
		"""
		Set the enabled.
		:param enabled: enabled
		:type enabled: bool
		"""
		self._enabled = enabled

	@property
	def net_queue(self) -> NetQueue:
		"""
		Return the net_queue.
		:return: net_queue
		:rtype: NetQueue
		"""
		return self._net_queue

	@net_queue.setter
	def net_queue(self, net_queue: NetQueue):
		"""
		Set the net_queue.
		:param net_queue: net_queue
		:type net_queue: NetQueue
		"""
		self._net_queue = net_queue

	@property
	def rx_ring_size(self) -> int:
		"""
		Return the rx_ring_size.
		:return: rx_ring_size
		:rtype: int
		"""
		return self._rx_ring_size

	@rx_ring_size.setter
	def rx_ring_size(self, rx_ring_size: int):
		"""
		Set the rx_ring_size.
		:param rx_ring_size: rx_ring_size
		:type rx_ring_size: int
		"""
		self._rx_ring_size = rx_ring_size

	@property
	def tx_ring_size(self) -> int:
		"""
		Return the tx_ring_size.
		:return: tx_ring_size
		:rtype: int
		"""
		return self._tx_ring_size

	@tx_ring_size.setter
	def tx_ring_size(self, tx_ring_size: int):
		"""
		Set the tx_ring_size.
		:param tx_ring_size: tx_ring_size
		:type tx_ring_size: int
		"""
		self._tx_ring_size = tx_ring_size

	@property
	def link_speed_mb(self) -> LinkSpeedMb:
		"""
		Return the link_speed_mb.
		:return: link_speed_mb
		:rtype: LinkSpeedMb
		"""
		return self._link_speed_mb

	@link_speed_mb.setter
	def link_speed_mb(self, link_speed_mb: LinkSpeedMb):
		"""
		Set the link_speed_mb.
		:param link_speed_mb: link_speed_mb
		:type link_speed_mb: LinkSpeedMb
		"""
		self._link_speed_mb = link_speed_mb

	@property
	def auto_negotiation(self) -> bool:
		"""
		Return the auto_negotiation.
		:return: auto_negotiation
		:rtype: bool
		"""
		return self._auto_negotiation

	@auto_negotiation.setter
	def auto_negotiation(self, auto_negotiation: bool):
		"""
		Set the auto_negotiation.
		:param auto_negotiation: auto_negotiation
		:type auto_negotiation: bool
		"""
		self._auto_negotiation = auto_negotiation

	@property
	def software_simulation(self) -> SoftwareSimulation:
		"""
		Return the software_simulation.
		:return: software_simulation
		:rtype: SoftwareSimulation
		"""
		return self._software_simulation

	@software_simulation.setter
	def software_simulation(self, software_simulation: SoftwareSimulation):
		"""
		Set the software_simulation.
		:param software_simulation: software_simulation
		:type software_simulation: SoftwareSimulation
		"""
		self._software_simulation = software_simulation


class Network(BaseModel):
	def __init__(self, nics: List[Nic] = None, vmknics: List[Vmknic] = None, firewall: Firewall = None, etc_hosts: EtcHosts = None, net_stacks: List[NetStack] = None, ip_security_policies: List[IpSecurityPolicy] = None, ip_security_associations: List[IpSecurityAssociation] = None):
		self._nics: List[Nic] = nics
		self._vmknics: List[Vmknic] = vmknics
		self._firewall: Firewall = firewall
		self._etc_hosts: EtcHosts = etc_hosts
		self._net_stacks: List[NetStack] = net_stacks
		self._ip_security_policies: List[IpSecurityPolicy] = ip_security_policies
		self._ip_security_associations: List[IpSecurityAssociation] = ip_security_associations

	@property
	def nics(self) -> List[Nic]:
		"""
		Return the nics.
		:return: nics
		:rtype: List[Nic]
		"""
		return self._nics

	@nics.setter
	def nics(self, nics: List[Nic]):
		"""
		Set the nics.
		:param nics: nics
		:type nics: List[Nic]
		"""
		self._nics = nics

	@property
	def vmknics(self) -> List[Vmknic]:
		"""
		Return the vmknics.
		:return: vmknics
		:rtype: List[Vmknic]
		"""
		return self._vmknics

	@vmknics.setter
	def vmknics(self, vmknics: List[Vmknic]):
		"""
		Set the vmknics.
		:param vmknics: vmknics
		:type vmknics: List[Vmknic]
		"""
		self._vmknics = vmknics

	@property
	def firewall(self) -> Firewall:
		"""
		Return the firewall.
		:return: firewall
		:rtype: Firewall
		"""
		return self._firewall

	@firewall.setter
	def firewall(self, firewall: Firewall):
		"""
		Set the firewall.
		:param firewall: firewall
		:type firewall: Firewall
		"""
		self._firewall = firewall

	@property
	def etc_hosts(self) -> EtcHosts:
		"""
		Return the etc_hosts.
		:return: etc_hosts
		:rtype: EtcHosts
		"""
		return self._etc_hosts

	@etc_hosts.setter
	def etc_hosts(self, etc_hosts: EtcHosts):
		"""
		Set the etc_hosts.
		:param etc_hosts: etc_hosts
		:type etc_hosts: EtcHosts
		"""
		self._etc_hosts = etc_hosts

	@property
	def net_stacks(self) -> List[NetStack]:
		"""
		Return the net_stacks.
		:return: net_stacks
		:rtype: List[NetStack]
		"""
		return self._net_stacks

	@net_stacks.setter
	def net_stacks(self, net_stacks: List[NetStack]):
		"""
		Set the net_stacks.
		:param net_stacks: net_stacks
		:type net_stacks: List[NetStack]
		"""
		self._net_stacks = net_stacks

	@property
	def ip_security_policies(self) -> List[IpSecurityPolicy]:
		"""
		Return the ip_security_policies.
		:return: ip_security_policies
		:rtype: List[IpSecurityPolicy]
		"""
		return self._ip_security_policies

	@ip_security_policies.setter
	def ip_security_policies(self, ip_security_policies: List[IpSecurityPolicy]):
		"""
		Set the ip_security_policies.
		:param ip_security_policies: ip_security_policies
		:type ip_security_policies: List[IpSecurityPolicy]
		"""
		self._ip_security_policies = ip_security_policies

	@property
	def ip_security_associations(self) -> List[IpSecurityAssociation]:
		"""
		Return the ip_security_associations.
		:return: ip_security_associations
		:rtype: List[IpSecurityAssociation]
		"""
		return self._ip_security_associations

	@ip_security_associations.setter
	def ip_security_associations(self, ip_security_associations: List[IpSecurityAssociation]):
		"""
		Set the ip_security_associations.
		:param ip_security_associations: ip_security_associations
		:type ip_security_associations: List[IpSecurityAssociation]
		"""
		self._ip_security_associations = ip_security_associations
