# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

from typing import List
from config_modules_vmware.esxi.config_model.base_model import BaseModel


class UsbPassThroughSwitch(BaseModel):

    def __init__(self,bus_id,device_id, vendor_id, product_id, enabled):
        self._bus_id = bus_id
        self._device_id = device_id
        self._vendor_id = vendor_id
        self._product_id = product_id
        self._enabled = enabled

    @property
    def bus_id(self):
        """Get bus id  """
        return self._bus_id

    @bus_id.setter
    def bus_id(self, _bus_id: int):
        """Set bus id"""
        self._bus_id = _bus_id
    
    @property
    def device_id(self):
        """Get device id  """
        return self._device_id

    @device_id.setter
    def device_id(self, device_id: str):
        """Set device id """
        self._device_id = device_id
    
    @property
    def vendor_id(self):
        """Get vendor id  """
        return self._vendor_id

    @vendor_id.setter
    def vendor_id(self, vendor_id: str):
        """Set vendor id """
        self._vendor_id = vendor_id
    
    @property
    def product_id(self):
        """Get product id  """
        return self._product_id

    @product_id.setter
    def product_id(self, product_id: str):
        """Set product id """
        self._product_id = product_id

    @property
    def enabled(self):
        """Get usb pass through enabled """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled: bool):
        """Set  usb pass through enabled"""
        self._enabled = enabled

class HardwareConfigData(BaseModel):

    def __init__(self, usb_passthrough_switch):
        self._usb_passthrough_switch = usb_passthrough_switch
    
    @property
    def usb_passthrough_switch(self):
        """Get usb pass through switch """
        return self._usb_passthrough_switch

    @usb_passthrough_switch.setter
    def usb_passthrough_switch(self, usb_passthrough_switch: List[UsbPassThroughSwitch]):
        """Set usb pass throguh switch """
        self._usb_passthrough_switch = usb_passthrough_switch