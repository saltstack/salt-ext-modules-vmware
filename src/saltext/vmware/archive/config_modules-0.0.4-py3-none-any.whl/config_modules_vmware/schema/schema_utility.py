# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import logging
import os
from enum import Enum
from pathlib import Path

import jsonref

logger = logging.getLogger(__name__)


class Product(Enum):
    ESX = "esx_reference_schema.json"
    ESX_VCP = "esx_schema.json"


def retrieve_reference_schema(product: Product):
    """
    Retrieve reference schema for given product.
    @param product: Supported product.
    @type product: Product
    @return: the schema in jsonSchema format.
    @rtype: dict
    """
    schema_path = os.path.join(os.path.dirname(__file__), product.value)
    if os.path.exists(schema_path) and os.path.isfile(schema_path):
        with open(schema_path) as f:
            return jsonref.load(f, base_uri=Path(__file__).as_uri())
    else:
        logger.error(F"Missing schema file for product {product}")
        raise Exception(F"Missing schema file for product {product}")
