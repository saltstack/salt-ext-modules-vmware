# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from config_modules_vmware.context import Context


class BaseConfig:
    """
    BaseConfig class defines the interface each config module should implement.
    """
    def __init__(self, context: Context):
        """
        BaseConfig constructor.

        :param context: contains product clients and shared context information.
        """
        self._context = context

    def get_configuration(self, *args, **kwargs):
        """
        Returns configuration for the product or product attribute.
        If the specific product has its own service/solution that can be used to get the configuration, the product
        solution should be used. If no such solution exists, product APIs are used to retrieve the configuration.

        :return: Json spec with configuration for this product.
        """
        pass

    def get_desired_state_drifts(self, *args, **kwargs):
        """
        Scans configuration drifts against its desired spec.
        If the specific product has its own service/solution that can be used to get the drifts, the product
        solution should be used. If no such solution exists, compare the provided specs and generate any config drifts
        between them.

        :return: Json spec defining
        """
        pass

    def kwargs_for_get_configuration(self, **kwargs):
        """
        This method added to as helper to the CLI interface. This method adapts the generic input parameters to CLI
        interface into specific input parameters of get configuration functionality of corresponding product
        implementing this method.
        """
        pass