import json
import logging
import sys
from typing import List

from config_modules_vmware.esxi.esx_config import EsxConfig
from config_modules_vmware.esxi.esx_config_modules import EsxConfigModulesEnum
from config_modules_vmware.esxi.esx_context import EsxContext
from config_modules_vmware.lib.common.credentials import SddcCredentials, VcenterCredentials

root = logging.getLogger()
root.setLevel(logging.DEBUG)
handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
root.addHandler(handler)


def main():
    vc_creds = VcenterCredentials(hostname="sc2-rdops-vm08-dhcp-3-236.eng.vmware.com",
                                  username="administrator@vsphere.local",
                                  password="GVXZ_8yo*elW7egR",
                                  ssl_thumbprint="71e8acc711842a00a2abf4ff59562d959db27f0b")
    sddc_creds = SddcCredentials(vc_creds=vc_creds)
    esx_context = EsxContext(sddc_credentials=sddc_creds)
    with esx_context:
        esx_config_obj = EsxConfig(context=esx_context)
        esx_config = esx_config_obj.get_configuration(esx_config_modules=[EsxConfigModulesEnum.STORAGE])
        print(esx_config)
        ##only for demp purpose to write json object to file
        foo(esx_config)


def foo(json_data):
    """Create the NSX-T bringup json file."""
    a = '/tmp/config.json'
    with open(a, 'w') as outfile:
        json.dump(json_data, outfile, indent=4, sort_keys=True)


if __name__ == "__main__":
    main()
