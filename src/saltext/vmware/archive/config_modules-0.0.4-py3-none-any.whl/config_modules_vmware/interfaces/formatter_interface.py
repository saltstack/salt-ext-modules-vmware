# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from abc import ABC, abstractmethod


class FormatterInterface(ABC):

    @staticmethod
    @abstractmethod
    def format(config: dict, reference_host_uuid: str) -> dict:
        pass
