import logging

from config_modules_vmware.base_config import BaseConfig
from config_modules_vmware.lib.context import Context

logger = logging.getLogger(__name__)


class Printer(BaseConfig):
    def __init__(self, context: Context):
        super().__init__(context)

    def get_configuration(self):
        print("get configuration")
        vc_client = self._context.vc_client()
        print("printer vc client")
        print(vc_client.content.about)
        config = {}
        return config


    def get_desired_state_drifts(self, current_spec, desired_spec):
        print("printer get desired state drifts")
        drifts = {}
        return drifts
