# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import io
import json
import logging
import shutil
import subprocess

from config_modules_vmware.lib.common.credentials import EsxCredentials

logger = logging.getLogger(__name__)


class Dcli(object):
    """
    Wrapper for invoking dcli command
    """

    def __init__(self):
        self._path = None
        self._host_info = None
        self._namespaces = []
        self._command = None
        self._dcli_options = ['+show-unreleased-apis', '+skip-server-verification', '+formatter', 'json']
        self._command_options = []

    def clear(self):
        """Clears the current state

        Returns:
            Dcli: self
        """
        self._path = None
        self._host = None
        self._host_info = None
        self._namespaces = []
        self._command = None
        self._dcli_options = ['+formatter', 'json']
        self._command_options = []
        return self

    def host_info(self, host_info):
        """Sets host and credential to be used while invoking dcli

        Args:
            host_info (EsxCredentials): Host and Credential

        Returns:
            Dcli: self
        """
        self._host_info = host_info
        return self

    def namespace(self, namespace):
        """Sets or Append the namespace.
        If str argument is provided, the given value will be added to namespace hierarchy.
        if list<str> is provided, that will be set as the namespaces clearing existing values

        Args:
            namespace (str|list): single namespace as string or multiple namespaces as a List

        Returns:
            Dcli: self
        """
        if isinstance(namespace, list):
            self._namespaces = [str(item) for item in namespace]
        else:
            self._namespaces.append(str(namespace))
        return self

    def dcli_option(self, key, value=None):
        """dcli options to be set. This is different from namespace command's options

        Args:
            key (str): Option name
            value (str, optional): Option's value. Defaults to None.

        Returns:
            Dcli: self
        """
        if value:
            option = f"{key} {value}"
        else:
            option = key

        self._dcli_options.append(str(option))
        return self

    def command_options(self, key, value=None):
        """Sets the command options to be used.

        Args:
            key (str): Option name
            value (str, optional): Option's value. Defaults to None.

        Returns:
            Dcli: self
        """
        option = ""
        if value:
            option = f"{key}={value}"
        else:
            option = key

        self._command_options.append(str(option))
        return self

    def command(self, command):
        """Sets the command (in the namespace) to be invoked

        Args:
            command (str): command in the namespace

        Returns:
            Dcli: self
        """
        self._command = str(command)
        return self

    def path(self, path):
        """Sets path of the dcli

        Args:
            path (_type_): dcli path. if not set, PATH will be looked at

        Returns:
            Dcli: self
        """
        self._path = str(path)
        return self

    def execute(self):
        """_summary_

        Raises:
            subprocess.CalledProcessError: if process invocation failed
            Exception: Any exception which is not process related

        Returns:
            dict: Output of the dcli command execution in json format
            None: if dcli is not installed
        """
        if self._path is None:
            self._path = shutil.which('dcli')
            if self._path is None:
                logger.error("DCLI is not installed")
                return None

        logger.info("Using %s", self._path)

        # DCLI Usage: dcli [options] {namespace}+ {cmd} [cmd options]
        args = [self._path]
        if not self._host_info:
            logger.error("Missing credential information. Exiting")
            return None
        args.append("+username")
        args.append(self._host_info.username)
        args.append("+password")
        args.append(self._host_info.password)
        args.append("+server")
        args.append("https://" + self._host_info.hostname + ":443/lifecycle-api")

        # Append dcli options
        args.extend(self._dcli_options)

        # Append namespaces
        args.extend(self._namespaces)

        # Append cmd
        args.append(self._command)

        # Append cmd options
        args.extend(self._command_options)

        try:
            logger.info(" ".join(args))
            process = subprocess.run(args, check=True,
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout = str(process.stdout).strip()
            if process.returncode == 0:
                f = io.StringIO(stdout)
                return json.load(f)
            else:
                raise Exception(
                    f"Unexpected return code {process.returncode}, Stdout: {process.stdout}, Stderr: {process.stderr}")
        except subprocess.CalledProcessError as ex:
            logger.exception(str(ex))
            raise ex
        except Exception as ex:
            logger.exception(str(ex))
            raise ex
