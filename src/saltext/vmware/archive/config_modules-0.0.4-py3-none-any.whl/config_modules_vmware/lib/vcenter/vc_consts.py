# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

# Vmware REST API related
VC_API_BASE = 'https://{}/'
VC_REST_API_TIMEOUT_VALUE = 30

# Vmware REST API session related
VMWARE_API_SESSION_ID = 'vmware-api-session-id'
VMWARE_CIS_URL = 'https://%s/rest/com/vmware/cis'
SESSION_ID_URL = VMWARE_CIS_URL + '/session'

# CIS task related
CIS_TASKS_URL = 'rest/cis/tasks/{}'
CIS_TASK_TERMINAL_STATUS = ("SUCCEEDED", "FAILED")
CIS_TASK_ACTIVE_STATUS = ("PENDING", "RUNNING", "BLOCKED")
CIS_TASK_SUCCEEDED = "SUCCEEDED"
CIS_TASK_FAILED = "FAILED"
CIS_TASK_KEY_VALUE = "value"
CIS_TASK_KEY_STATUS = "status"
CIS_TASK_KEY_RESULT = "result"

# VCSA API appliance related
APPLIANCE_URL_PREFIX = 'rest/appliance/'
VC_SYSTEM_VERSION_URL = APPLIANCE_URL_PREFIX + 'system/version'

# VLCM Config Manager related
START_VC_VERSION_FOR_VLCM_CONFIG_FEATURE = '8.0.1.00000'
VLCM_CONFIG_EXTRACT_HOST_CONFIG_URL = 'api/esx/settings/hosts/{}/configuration?action=extract'
VLCM_CONFIG_ENABLEMENT_ON_CLUSTER_URL = 'api/esx/settings/clusters/{}/enablement/configuration'
VLCM_CONFIG_CHECK_COMPLIANCE_CLUSTER_CONFIG_URL = \
    'api/esx/settings/clusters/{}/configuration?action=checkCompliance&vmw-task=true'
VLCM_CONFIG_EXPORT_CLUSTER_CONFIG_URL = 'api/esx/settings/clusters/{}/configuration?action=exportConfig'
VLCM_CONFIG_GET_CLUSTER_CONFIG_URL = 'api/esx/settings/clusters/{}/configuration'
VLCM_CONFIG_PRECHECK_DESIRED_CLUSTER_CONFIG_URL = \
    'api/esx/settings/clusters/{}/configuration?action=precheck&vmw-task=true'
VLCM_CONFIG_REMEDIATE_DESIRED_CLUSTER_CONFIG_URL = \
    'api/esx/settings/clusters/{}/configuration?action=apply&vmw-task=true'

