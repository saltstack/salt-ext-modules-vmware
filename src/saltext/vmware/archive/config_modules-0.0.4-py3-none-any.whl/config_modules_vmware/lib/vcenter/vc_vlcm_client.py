# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
import json

from config_modules_vmware.lib.vcenter import vc_consts
from config_modules_vmware.lib.common import consts
from config_modules_vmware.lib.vcenter.vc_rest_client import VcRestClient
from config_modules_vmware.lib.common.credentials import VcenterCredentials
from config_modules_vmware.lib.common import consts

# Set up logger
logger = logging.getLogger(__name__)


class VcVlcmClient(VcRestClient):
    """
    Class to provide helper functions invoke  VCENTER REST APIs related vLCM config Manager.
    """
    def __init__(self, vc_access: VcenterCredentials):
        """
        :type vc_access: :class:`VcenterCredentials`
        :param vc_access: credentials used to connect to vcenter.
        """
        super(VcVlcmClient, self).__init__(vc_access)

    def extract_host_current_config(self, host_moid):
        """
        Extracts the current config of the host.
        :type host_moid: :class:`str`
        :param host_moid: Host Mob id.
        """
        url = self._base_url + \
              vc_consts.VLCM_CONFIG_EXTRACT_HOST_CONFIG_URL.format(host_moid)

        response = self.post_helper(url=url)
        config = json.loads(response["config"])

        if "metadata" in config:
            del config["metadata"]

        return config

    def is_vlcm_config_manager_enabled_on_cluster(self, cluster_moid):
        """
        Checks if the given cluster has vlcm config manager enabled or not.

        :rtype :class:`boolean`
        :return: True if vlcm config manager has been configured, False if not.
        """
        url = self._base_url + \
              vc_consts.VLCM_CONFIG_ENABLEMENT_ON_CLUSTER_URL.format(cluster_moid)

        response = self.get_helper(url=url)
        return response["enabled"]

    def is_vlcm_config_manager_supported_in_vcsa(self):
        """
        Checks if the vlcm config manager feature is available on
        the current vcsa by checking the vcsa version

        :rtype :class:`boolean`
        :return: True if vlcm config available False if not
        """

        actual_version = self.get_vcsa_version()
        actual_version_trim = '.'.join(actual_version.rsplit("-", 1))
        actual_version_compare_value = list(map(int, actual_version_trim.split('.')))

        available_version_compare_value = \
            list(map(int, vc_consts.START_VC_VERSION_FOR_VLCM_CONFIG_FEATURE.split('.')))

        return actual_version_compare_value >= available_version_compare_value

    def check_compliance_cluster_configuration(self, cluster_moid):
        """
        Checks for the compliance of cluster configurations and returns compliance status with list of drifts
        for each non-compliant hosts.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return: compliance result in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_CHECK_COMPLIANCE_CLUSTER_CONFIG_URL.format(cluster_moid)

        task_id = self.post_helper(url=url, json_result=False)
        response = self._wait_for_cis_task_completion(task_id)
        return {
            vc_consts.CIS_TASK_KEY_STATUS: response[vc_consts.CIS_TASK_KEY_STATUS],
            vc_consts.CIS_TASK_KEY_RESULT: response[vc_consts.CIS_TASK_KEY_RESULT]
        }

    def export_desired_state_cluster_configuration(self, cluster_moid):
        """
        This function will export the desired state configuration associated with the cluster.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return:  desired state configuration in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_EXPORT_CLUSTER_CONFIG_URL.format(cluster_moid)

        response = self.post_helper(url=url)
        return {
            "config": json.loads(response["config"])
        }

    def precheck_cluster_configuration(self, cluster_moid):
        """
        This method is to perform precheck of desired state configuration on each hosts in the cluster.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return: precheck result in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_PRECHECK_DESIRED_CLUSTER_CONFIG_URL.format(cluster_moid)

        task_id = self.post_helper(url=url, json_result=False)
        response = self._wait_for_cis_task_completion(task_id)
        return {
            vc_consts.CIS_TASK_KEY_STATUS: response[vc_consts.CIS_TASK_KEY_STATUS],
            vc_consts.CIS_TASK_KEY_RESULT: response[vc_consts.CIS_TASK_KEY_RESULT]
        }

    def remediate_cluster_configuration(self, cluster_moid):
        """
        This method is to apply desired state configuration on each hosts in the cluster which are non-compliant.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return: precheck result in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_REMEDIATE_DESIRED_CLUSTER_CONFIG_URL.format(cluster_moid)

        empty_body = {}
        task_id = self.post_helper(url=url, body=empty_body, json_result=False)
        response = self._wait_for_cis_task_completion(task_id, timeout=consts.SECS_IN_30_MINS)
        return {
            vc_consts.CIS_TASK_KEY_STATUS: response[vc_consts.CIS_TASK_KEY_STATUS],
            vc_consts.CIS_TASK_KEY_RESULT: response[vc_consts.CIS_TASK_KEY_RESULT]
        }

    def get_desired_state_cluster_configuration(self, cluster_moid):
        """
        This function will get the desired state configuration associated with the cluster.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return:  desired state configuration in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_GET_CLUSTER_CONFIG_URL.format(cluster_moid)

        response = self.get_helper(url=url)
        return {
            "config": json.loads(response["config"]),
            "host_info": response["host_info"]
        }

    def draft_create(self, cluster_moid, config=None):
        """
        Create a new draft for given cluster. If config is passed it will be imported as draft
        otherwise draft is created from current desired state.

        :rtype :class:`str`
        :return: draft id
        """
        url = self._base_url + vc_consts.VCP_DRAFTS_URL.format(cluster_moid)
        draft_request = {}
        # Create draft with input body
        if config is not None:
            draft_request["config"] = json.dumps(config)
        draft_id = self.post_helper(url=url, body=draft_request)
        return draft_id

    def draft_get(self, cluster_moid, draft_id):
        """
        Get draft by draft id for a cluster.

        :rtype :class:`dict`
        :return: draft config

        Sample Draft response
        {
            "host_id_to_UUID": {},
            "metadata": {},
            "changes": {},
            "config": {
                "profile": {
                    "esx": {}
                },
                "metadata": {},
                "host-override": {}
            },
            "host_info": {},
        }

        """
        url = self._base_url + vc_consts.VCP_DRAFT_URL.format(cluster_moid, draft_id)
        return self.get_helper(url=url)

    def draft_list(self, cluster_moid):
        """
        Returns all available drafts metadata for a cluster. Includes drafts created by any user(s).

        :rtype :class:`dict`
        :return: list of draft metadata

        Sample response
        {
            "config-draft-4": {
                "creation_time": "2023-10-06T15:46:11.366Z",
                "owner": "svc-sddc-manager-vcenter-1@vsphere.local",
                "modified_time": "2023-10-06T15:46:48.101Z",
                "parent_id": "config-commit-3",
                "id": "config-draft-4",
                "state": "VALID",
                "revision": 3
            },
            "config-draft-5": {
                "creation_time": "2023-10-06T15:47:14.919Z",
                "owner": "Administrator@VSPHERE.LOCAL",
                "modified_time": "2023-10-06T15:47:34.297Z",
                "parent_id": "config-commit-3",
                "id": "config-draft-5",
                "state": "VALID",
                "revision": 3
            }
        }

        """
        url = self._base_url + vc_consts.VCP_DRAFTS_URL.format(cluster_moid)
        return self.get_helper(url=url)

    def draft_update(self, cluster_moid, draft_id, config):
        """
        Update a draft config for a cluster.

        :rtype :class:`dict`
        :return: updated draft config

        Sample response
        {
            "config": {
                "profile": {
                    "esx": {}
                },
                "metadata": {},
                "host-override": {}
            }
        }

        """
        url = self._base_url + vc_consts.VCP_DRAFT_UPDATE_URL.format(cluster_moid, draft_id)
        update_request = {"config": json.dumps(json.dumps(config))}
        self.post_helper(url=url, body=update_request)

    def draft_export(self, cluster_moid, draft_id):
        """
        Export a draft config for a cluster.

        :rtype :class:`dict`
        :return: draft config

        Sample response
        {
            "config": {
                "profile": {
                    "esx": {}
                },
                "metadata": {},
                "host-override": {}
            }
        }

        """
        url = self._base_url + vc_consts.VCP_DRAFT_EXPORT_URL.format(cluster_moid, draft_id)
        # Create draft with input body
        return self.post_helper(url=url)

    def draft_precheck(self, cluster_moid, draft_id):
        """
        Run precheck against draft for a cluster.
        When precheck returns task id, poll task for completion and return the task response.

        :rtype :class:`dict`
        :return: precheck response

        Sample response
        {
            "result": {
              "summary": {},
              "successful_hosts": [],
              "end_time": "2023-10-03T22:05:55.378Z",
              "precheck_result": {},
              "host_precheck": [],
              "remediation_summary": [],
              "failed_hosts": [],
              "skipped_hosts": [],
              "host_info": [],
              "remediation_notes": [],
              "software_commit": "3",
              "status": "OK"
            },
            "status": "SUCCEEDED"
        }

        """
        url = self._base_url + vc_consts.VCP_DRAFT_PRECHECK_URL.format(cluster_moid, draft_id)
        task_id = self.post_helper(url=url)
        response = self._wait_for_cis_task_completion(task_id)
        return {
            vc_consts.CIS_TASK_KEY_STATUS: response[vc_consts.CIS_TASK_KEY_STATUS],
            vc_consts.CIS_TASK_KEY_RESULT: response[vc_consts.CIS_TASK_KEY_RESULT]
        }

    def draft_check_compliance(self, cluster_moid, draft_id):
        """
        Run check compliance against draft for a cluster.
        When check compliance response returns task id, poll task for completion and return the task response.

        :rtype :class:`dict`
        :return: check compliance response

        Sample response
        {
            "result": {
                "summary": {},
                "cluster_status": "NOT_COMPLIANT",
                "failed_hosts": [],
                "hosts": [],
                "non_compliant_hosts": [],
                "skipped_hosts": [],
                "end_time": "2023-10-03T21:07:55.806Z",
                "compliant_hosts": [],
                "host_info": [],
                "software_commit": "1"
                },
            "status": "SUCCEEDED"
        }

        """
        url = self._base_url + vc_consts.VCP_DRAFT_CHECKCOMPLIANCE_URL.format(cluster_moid, draft_id)
        task_id = self.post_helper(url=url)
        response = self._wait_for_cis_task_completion(task_id)
        return {
            vc_consts.CIS_TASK_KEY_STATUS: response[vc_consts.CIS_TASK_KEY_STATUS],
            vc_consts.CIS_TASK_KEY_RESULT: response[vc_consts.CIS_TASK_KEY_RESULT]
        }

    def draft_apply(self, cluster_moid, draft_id):
        """
        Invoke apply against a draft for a cluster.
        When apply response returns task id, poll task for completion and return the task response.

        :rtype :class:`dict`
        :return: apply response object

        Sample Apply Response:
        {
            "apply_task":"52424f8a-d88b-d9ee-6aa5-79204016ef8c:com.vmware.esx.settings.clusters.configuration",
            "commit":"config-commit-4"
        }

        Sample Apply Task response
        {
            "result": {
                  "successful_hosts": [],
                  "failed_hosts": [],
                  "skipped_hosts": [],
                  "commit": "config-commit-6",
                  "host_status": [],
                  "host_info": [],
                  "software_commit": "4",
                  "status": {}
                },
            "status": "SUCCEEDED"
        }

        """
        url = self._base_url + vc_consts.VCP_DRAFT_APPLY_URL.format(cluster_moid, draft_id)
        apply_response = self.post_helper(url=url)
        if "apply_task" in apply_response:
            response = self._wait_for_cis_task_completion(apply_response["apply_task"])
            return {
                vc_consts.CIS_TASK_KEY_STATUS: response[vc_consts.CIS_TASK_KEY_STATUS],
                vc_consts.CIS_TASK_KEY_RESULT: response[vc_consts.CIS_TASK_KEY_RESULT]
            }
        else:
            return apply_response

    def draft_delete(self, cluster_moid, draft_id):
        """
        Delete a draft for a cluster.
        @param cluster_moid: cluster moid
        @param draft_id: draft id
        @return: true/false
        """
        url = self._base_url + vc_consts.VCP_DRAFT_URL.format(cluster_moid, draft_id)
        if self.delete_helper(url=url):
            return True
        else:
            return False

    def draft_show_changes(self, cluster_moid, draft_id):
        """
        Show chages in a draft against current desired state in a cluster.

        @param cluster_moid: cluster moid
        @param draft_id: draft id
        @return: json object of changes

        Sample Response:
        {
            "adds": [],
            "sets": []
        }
        """
        url = self._base_url + vc_consts.VCP_DRAFT_SHOW_CHANGES_URL.format(cluster_moid, draft_id)
        return self.get_helper(url=url)

    def import_desired_state_cluster_configuration(self, cluster_moid, payload):
        """
        This function will export the desired state configuration associated with the cluster.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return:  desired state configuration in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_IMPORT_CLUSTER_CONFIG_URL.format(cluster_moid)
        body = {"description" : "import config", "config": json.dumps(payload["config"])}
        return self.post_helper(url=url, body=body)

    def extract_cluster_desired_state_config(self, cluster_moid):
        """
        Extracts the current config of the cluster.
        :type host_moid: :class:`str`
        :param host_moid: Host Mob id.
        """
        url = self._base_url + \
              vc_consts.VLCM_CONFIG_GET_CLUSTER_CONFIG_URL.format(cluster_moid)

        response = self.get_helper(url=url)
        config = json.loads(response["config"])

        #if "metadata" in config:
        #    del config["metadata"]

        return config

