# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
import json

from config_modules_vmware.lib.vcenter import vc_consts
from config_modules_vmware.lib.vcenter.vc_rest_client import VcRestClient
from config_modules_vmware.lib.common.credentials import VcenterCredentials

# Set up logger
logger = logging.getLogger(__name__)


class VcVlcmClient(VcRestClient):
    """
    Class to provide helper functions invoke  VCENTER REST APIs related vLCM config Manager.
    """
    def __init__(self, vc_access: VcenterCredentials):
        """
        :type vc_access: :class:`VcenterCredentials`
        :param vc_access: credentials used to connect to vcenter.
        """
        super(VcVlcmClient, self).__init__(vc_access)

    def extract_host_current_config(self, host_moid):
        """
        Extracts the current config of the host.
        :type host_moid: :class:`str`
        :param host_moid: Host Mob id.
        """
        url = self._base_url + \
              vc_consts.VLCM_CONFIG_EXTRACT_HOST_CONFIG_URL.format(host_moid)

        response = self.post_helper(url=url)
        config = json.loads(response["config"])

        if "metadata" in config:
            del config["metadata"]

        return config

    def is_vlcm_config_manager_enabled_on_cluster(self, cluster_moid):
        """
        Checks if the given cluster has vlcm config manager enabled or not.

        :rtype :class:`boolean`
        :return: True if vlcm config manager has been configured, False if not.
        """
        url = self._base_url + \
              vc_consts.VLCM_CONFIG_ENABLEMENT_ON_CLUSTER_URL.format(cluster_moid)

        response = self.get_helper(url=url)
        return response["enabled"]

    def is_vlcm_config_manager_supported_in_vcsa(self):
        """
        Checks if the vlcm config manager feature is available on
        the current vcsa by checking the vcsa version

        :rtype :class:`boolean`
        :return: True if vlcm config available False if not
        """

        actual_version = self.get_vcsa_version()
        actual_version_trim = '.'.join(actual_version.rsplit("-", 1))
        actual_version_compare_value = list(map(int, actual_version_trim.split('.')))

        available_version_compare_value = \
            list(map(int, vc_consts.START_VC_VERSION_FOR_VLCM_CONFIG_FEATURE.split('.')))

        return actual_version_compare_value >= available_version_compare_value

    def check_compliance_cluster_configuration(self, cluster_moid):
        """
        Checks for the compliance of cluster configurations and returns compliance status with list of drifts
        for each non-compliant hosts.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return: compliance result in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_CHECK_COMPLIANCE_CLUSTER_CONFIG_URL.format(cluster_moid)

        task_id = self.post_helper(url=url, json_result=False)
        response = self._wait_for_cis_task_completion(task_id)
        return {
            vc_consts.CIS_TASK_KEY_STATUS: response[vc_consts.CIS_TASK_KEY_STATUS],
            vc_consts.CIS_TASK_KEY_RESULT: response[vc_consts.CIS_TASK_KEY_RESULT]
        }

    def export_desired_state_cluster_configuration(self, cluster_moid):
        """
        This function will export the desired state configuration associated with the cluster.

        :type cluster_moid: :class:`str`
        :param cluster_moid: Cluster Mob id.
        :rtype :class:`dict`
        :return:  desired state configuration in the json type format.
        """

        url = self._base_url + \
              vc_consts.VLCM_CONFIG_EXPORT_CLUSTER_CONFIG_URL.format(cluster_moid)

        response = self.post_helper(url=url)
        return {
            "config": json.loads(response["config"])
        }


