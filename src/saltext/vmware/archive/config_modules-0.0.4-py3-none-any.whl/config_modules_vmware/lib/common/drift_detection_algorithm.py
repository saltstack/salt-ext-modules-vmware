# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
import numbers
import re
from typing import Any, List, Optional, Union

from config_modules_vmware.lib.common import consts

logger = logging.getLogger(__name__)
ARRAY_OBJECT_QUERY = "[?({query})]"
ARRAY_OBJECT_QUERY_INT = "@.{key}=={value}"
ARRAY_OBJECT_QUERY_STR = "@.{key}==\"{value}\""
DEFAULT_PATH_PREFIX = "$"


class DriftDetectionAlgorithm(object):
    """
    Class that provides utility for drift detection algorithm.
    """

    def __init__(self, root_json_path: Optional[str] = DEFAULT_PATH_PREFIX):
        """
        Constructor.
        :param root_json_path: Optional. The root parent path of comparing objects.
                                        The path will be appended in front of drifts keys by the framework.
                                        The framework will handle setting this root json path to your extension, e.g.:
                                        $.nsx.firewall_rules
        """
        self.root_json_path = root_json_path if root_json_path else DEFAULT_PATH_PREFIX
        self.root_regex_json_path = self.root_json_path.replace("$", "\\$").replace(".", "\\.")

    def get_drifts(self, desired_spec: Any, current_spec: Any, arrays_keys_map: dict,
                   parent_json_path: Optional[str] = "",
                   include_addition_drifts: Optional[bool] = False) -> dict:
        """
        General method to get two Json object's drifts - JsonDiff.
        Since general JsonDiff does not do good job in finding drifts between arrays,
             we need to write our own JsonDiff method.
        1. Recursively traverse the desiredSpec Json and extract the arrays encountered.
        2. Call find array drifts helper functions to get drifts between two arrays.
        3. Call find value objects drifts helper function to get drifts between two value nodes.

        :param desired_spec: Desired Spec.
        :param current_spec: Current Spec.
        :param arrays_keys_map: Map which stores parent path -> key to identify object in array.
        :param parent_json_path: Optional. The parent path of comparing objects.
                                        The path will be appended in front of drifts keys, after root_json_path.
                                        e.g. if root_json_path is $.nsx.firewall_rules, you can pass parent_json_path
                                        as domains. Then all drifts keys will start with
                                        $.nsx.firewall_rules.domains
        :param include_addition_drifts: boolean. If set to true, will include any additional objects contained in
                                                current spec that are not expected in desired spec.
        :return List of drifts
        """
        arrays_keys_map_copy = {}
        # Compiling the regular expression strings from input to regex patterns.
        # Append regex parent path to regex keys.
        regex_key_map_original = arrays_keys_map.get("regex_key_map") or {}
        regex_obj = {}
        regex_key_map_extended = {}
        for regex, regex_ids in regex_key_map_original.items():
            if not regex.startswith(self.root_regex_json_path):
                # adding .? since when extension itself is array, the dot will not be present in jsonpath.
                regex = self.root_regex_json_path + ".?" + regex
            regex_obj[regex] = re.compile(regex)
            regex_key_map_extended[regex] = regex_ids
        arrays_keys_map_copy["regex_obj"] = regex_obj
        arrays_keys_map_copy["regex_key_map"] = regex_key_map_extended

        # Append parent path to static keys.
        static_obj_original = arrays_keys_map.get("static_key_map") or {}
        static_obj_extended = {}
        for static_key, static_ids in static_obj_original.items():
            if not static_key.startswith(self.root_json_path):
                if static_key != "":
                    static_key = self.root_json_path + '.' + static_key
                else:
                    static_key = self.root_json_path
            static_obj_extended[static_key] = static_ids
        arrays_keys_map_copy["static_key_map"] = static_obj_extended
        drifts = []
        if parent_json_path:
            json_path_prefix = self.root_json_path + "." + parent_json_path
        else:
            json_path_prefix = self.root_json_path
        DriftDetectionAlgorithm._get_object_drifts(desired_spec, current_spec, arrays_keys_map_copy, drifts,
                                                   json_path_prefix, include_addition_drifts)
        return {consts.COMPLIANCE_STATUS: consts.COMPLIANT if len(drifts) == 0 else consts.NON_COMPLIANT,
                consts.DRIFTS: drifts}

    @staticmethod
    def _get_object_drifts(desired_spec: Any, current_spec: Any, arrays_keys_map: dict, drifts: list,
                           parent_json_path: str, include_addition_drifts: bool):
        """
        General helper method to get two Json object's drifts - JsonDiff.
        Since general JsonDiff does not do good job in finding drifts between arrays,
             we need to write our own JsonDiff method.
        1. Recursively traverse the desiredSpec Json and extract the arrays encountered.
        2. Call find array drifts helper functions to get drifts between two arrays.
        3. Call find value objects drifts helper function to get drifts between two value nodes.

        :param desired_spec: Desired Spec.
        :param current_spec: Current Spec.
        :param arrays_keys_map: Map which stores parent path -> key to identify object in array.
        :param drifts: List of already found diffs
        :param parent_json_path: String. The parent path of comparing objects.
                                        The path will be appended in front of drifts keys.
        :param include_addition_drifts: boolean. If set to true, will include any additional objects contained in
                                                current spec that are not expected in desired spec.
        """
        if current_spec is None and desired_spec is None:
            return

        if current_spec is None:
            drifts.append(
                DriftDetectionAlgorithm.missing_current_config(parent_json_path, desired_spec))
            return
        elif desired_spec is None and include_addition_drifts:
            drifts.append(
                DriftDetectionAlgorithm.missing_desired_config(parent_json_path, current_spec))
            return
        elif desired_spec is None:
            return

        if DriftDetectionAlgorithm._is_value_node(desired_spec):
            DriftDetectionAlgorithm._get_value_objects_drift(desired_spec, current_spec, drifts,
                                                             parent_json_path)
        elif isinstance(desired_spec, list):
            DriftDetectionAlgorithm._get_arrays_objects_drifts(desired_spec, current_spec, arrays_keys_map,
                                                               drifts, parent_json_path, include_addition_drifts)
        else:
            desired_spec_keys_set = set()
            current_spec_keys_set = set()
            desired_spec_keys_set.update(list(desired_spec.keys()))
            current_spec_keys_set.update(list(current_spec.keys()))
            common = desired_spec_keys_set.intersection(current_spec_keys_set)
            for common_key in common:
                curr_path = parent_json_path + "." + common_key
                current_node = current_spec.get(common_key)
                desired_node = desired_spec.get(common_key)
                DriftDetectionAlgorithm._get_object_drifts(desired_node, current_node, arrays_keys_map, drifts,
                                                           curr_path, include_addition_drifts)
            missing_in_current = desired_spec_keys_set.difference(common)
            for missing_key in missing_in_current:
                curr_path = parent_json_path + "." + missing_key
                desired_node = desired_spec.get(missing_key)
                drifts.append(
                    DriftDetectionAlgorithm.missing_current_config(curr_path, desired_node))
            if include_addition_drifts:
                missing_in_desired = current_spec_keys_set.difference(common)
                for missing_key in missing_in_desired:
                    curr_path = parent_json_path + "." + missing_key
                    current_node = current_spec.get(missing_key)
                    drifts.append(
                        DriftDetectionAlgorithm.missing_desired_config(curr_path, current_node))

    @staticmethod
    def _get_value_objects_drift(desired_spec: Union[str, int, list], current_spec: Union[str, int, list],
                                 drifts: list, parent_json_path: str):
        """
        Finds drift between two value nodes - String or numeric.

        :param desired_spec: Desired value node. Could be String or numeric.
        :param current_spec: Current value node. Could be String or numeric.
        :param drifts: List of already found diffs
        :param parent_json_path: The parent path to this value node.
.
        """
        if current_spec != desired_spec:
            drifts.append(DriftDetectionAlgorithm.make_replace_drift_entry(parent_json_path, desired_spec,
                                                                           current_spec))

    @staticmethod
    def _get_arrays_objects_drifts(desired_array: list, current_array: list, arrays_keys_map: dict,
                                   drifts: list, parent_json_path: str, include_addition_drifts: bool):
        """
        Finds drift between two arrays. The arrays could contain nested arrays.

        :param desired_array: Desired array spec. Must be a list.
        :param current_array: Current array spec. Must be a list.
        :param arrays_keys_map: Map which stores parent path -> key to identify object in array.
        :param drifts: List of already found diffs
        :param parent_json_path: The parent path to this array object. The path will be appended in front of drift paths.
        :param include_addition_drifts: If set to true, will include any additional objects contained in current spec that
                                     are not expected in desired spec.

        """
        if len(desired_array) == 0 and len(current_array) == 0:
            return
        if (len(desired_array) != 0 and DriftDetectionAlgorithm._is_value_node(desired_array[0])) \
                or (len(current_array) != 0 and DriftDetectionAlgorithm._is_value_node(current_array[0])):
            DriftDetectionAlgorithm._get_arrays_values_drift(desired_array, current_array,
                                                             drifts, parent_json_path, include_addition_drifts)
            return
        # If reach here, we are comparing two array of objects.
        try :
            field_keys = DriftDetectionAlgorithm._get_field_keys(parent_json_path, arrays_keys_map)
        except Exception as e:
            logger.warning("Falling back to do exact array matching: %s", e)
            DriftDetectionAlgorithm._get_value_objects_drift(desired_array, current_array, drifts,
                                                             parent_json_path)
            return

        current_array_map = {}
        for cur_spec in current_array:
            key = DriftDetectionAlgorithm._concat_obj_identifier(field_keys, cur_spec)
            current_array_map[key] = cur_spec
        for des_spec in desired_array:
            key = DriftDetectionAlgorithm._concat_obj_identifier(field_keys, des_spec)
            # If array object exists in current spec, compare the two objects.
            if key in current_array_map:
                DriftDetectionAlgorithm._get_object_drifts(des_spec, current_array_map[key], arrays_keys_map, drifts,
                                                           parent_json_path + ARRAY_OBJECT_QUERY.format(query=key),
                                                           include_addition_drifts)
                current_array_map.pop(key)
            else:
                # If array object is missing in current spec, directly add it to drifts.
                drifts.append(DriftDetectionAlgorithm.missing_current_config(
                    parent_json_path + ARRAY_OBJECT_QUERY.format(query=key), des_spec))
        # If current spec contains additional objects that are not expected in desired spec.
        if include_addition_drifts:
            for key, value in current_array_map.items():
                drifts.append(DriftDetectionAlgorithm.missing_desired_config(
                    parent_json_path + ARRAY_OBJECT_QUERY.format(query=key), value))

    @staticmethod
    def _get_arrays_values_drift(desired_array: list, current_array: list, drifts: list,
                                 parent_json_path: str, include_addition_drifts: bool):
        """
        Finds drift between two arrays containing value objects.
        We treat value node array as leaf node
            - if the two arrays don't contain the same set of elements we only have one drift entry for the two arrays.

        :param desired_array: Desired array spec. Must be a list.
        :param current_array: Current array spec. Must be a list.
        :param drifts: List of already found diffs
        :param parent_json_path: The parent path to this array object. The path will be appended in front of drift paths.
        :param include_addition_drifts: If set to true, will include any additional objects contained in current spec that
                                        are not expected in desired spec.
        :return: List of drift between the two arrays.
        """
        current_array_set = set(current_array)
        desired_array_set = set(desired_array)
        if len(desired_array_set.difference(current_array_set)) > 0 \
                or (include_addition_drifts and len(current_array_set.difference(desired_array_set)) > 0):
            drifts.append(DriftDetectionAlgorithm.make_replace_drift_entry(parent_json_path, desired_array,
                                                                           current_array))

    @staticmethod
    def _get_field_keys(path: str, arrays_keys_map: dict) -> List[str]:
        """
        Gets field name which can uniquely identity the object at path `path`.
        :param path: String path to json object.
        :param arrays_keys_map: map which stores parent path -> keys to identify object in array.
        :return: List<String> field names.
        """
        static_array_keys_map = arrays_keys_map.get("static_key_map")
        regex_array_keys_map = arrays_keys_map.get("regex_key_map")
        regex_array_objs_map = arrays_keys_map.get("regex_obj")
        if path in static_array_keys_map:
            return static_array_keys_map.get(path)
        else:
            for regex, regex_obj in regex_array_objs_map.items():
                if regex_obj.fullmatch(path):
                    return regex_array_keys_map.get(regex)
        raise Exception("Could not find matching key name for path " + path)

    @staticmethod
    def _concat_obj_identifier(field_keys: list, obj: dict) -> str:
        """
        Helper method to build unique identifier for an object based on array key map.
        :param field_keys: List of keys to uniquely identify an object in an array.
        :param obj: The Json object.
        :return: Concatenated String to uniquely identify the object.
        """
        key_queries = []
        for field_key in field_keys:
            field_value = obj[field_key]
            if field_value is not None and isinstance(field_value, numbers.Number):
                key_queries.append(ARRAY_OBJECT_QUERY_INT.format(key=field_key, value=field_value))
            else:
                key_queries.append(ARRAY_OBJECT_QUERY_STR.format(key=field_key, value=field_value))
        return "&&".join(key_queries)

    @staticmethod
    def _is_value_node(node: Any) -> bool:
        """
        Checks if a json node is a value node.
        :param node: Json node.
        :return: True if it is a value node, False otherwise.
        """
        if node is None or isinstance(node, dict) or isinstance(node, list):
            return False
        return True

    @staticmethod
    def make_replace_drift_entry(key: str, desired_node: Any, current_node: Any) -> dict:
        """
        Creates a REPLACE drift entry - when current spec and desired spec has difference in values.
        :param key: String parent path to this object. i.e. key of drift.
        :param desired_node: Json desired spec node.
        :param current_node: Json current spec node.
        :return: Json drift entry.
        """
        res = dict()
        res[consts.DRIFT_KEY_DESIRED] = desired_node
        res[consts.DRIFT_KEY_CURRENT] = current_node
        res[consts.DRIFT_KEY_KEY] = key
        return res

    @staticmethod
    def missing_current_config(key: str, desired_node: Any) -> dict:
        """
        Creates drift entry which represents missing current spec node.
        :param key: String parent path to this object. i.e. key of drift.
        :param desired_node: Json desired spec node.
        :return: Json Drift entry.
        """
        drift_node = DriftDetectionAlgorithm._create_drift_node_based_on_type(desired_node)
        res = dict()
        res[consts.DRIFT_KEY_DESIRED] = desired_node
        res[consts.DRIFT_KEY_CURRENT] = drift_node
        res[consts.DRIFT_KEY_KEY] = key
        return res

    @staticmethod
    def missing_desired_config(key: str, current_node: Any) -> dict:
        """
        Creates drift entry which represents missing desired spec node.
        :param key: String parent path to this object. i.e. key of drift.
        :param current_node: Json desired spec node.
        :return: Json Drift entry.
        """
        drift_node = DriftDetectionAlgorithm._create_drift_node_based_on_type(current_node)
        res = dict()
        res[consts.DRIFT_KEY_DESIRED] = drift_node
        res[consts.DRIFT_KEY_CURRENT] = current_node
        res[consts.DRIFT_KEY_KEY] = key
        return res

    @staticmethod
    def _create_drift_node_based_on_type(node: Any) -> Any:
        """
        Creates an empty node based on the type of input node.
        :param node: Json node.
        :return: An empty Json.
        """
        if isinstance(node, dict):
            return {}
        elif isinstance(node, list):
            return []
        else:
            return None
