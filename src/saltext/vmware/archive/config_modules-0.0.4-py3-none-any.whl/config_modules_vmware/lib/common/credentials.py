# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

class VcenterCredentials:
    def __init__(self, hostname=None, username=None, password=None, ssl_thumbprint=None, saml_token=None):
        """
        Initialize VcenterCredentials
        :param hostname: vCenter hostname
        :type hostname: :class:'str'
        :param username: vCenter username
        :type username: :class:'str'
        :param password: vCenter Password
        :type password: :class:'str'
        :param ssl_thumbprint: vCenter thumbprint
        :type ssl_thumbprint: :class:'str'
        :param saml_token: vCenter SAML token to use for authentication instead of username/password
        :type saml_token: :class:'str'
        """
        self._hostname = hostname
        self._username = username
        self._password = password
        self._ssl_thumbprint = ssl_thumbprint
        self._saml_token = saml_token

    @property
    def hostname(self):
        """
        Gets the hostname of this VcCredentials.
        :return: The hostname of this VcCredentials.
        :rtype: :class:'str'
        """
        return self._hostname

    @property
    def username(self):
        """
        Gets the username of this VcCredentials.
        :return: The username of this VcCredentials.
        :rtype: :class:'str'
        """
        return self._username

    @property
    def password(self):
        """
        Gets the password of this VcCredentials.
        :return: The password of this VcCredentials.
        :rtype: :class:'str'
        """
        return self._password

    @property
    def ssl_thumbprint(self):
        """
        Gets the ssl_thumbprint of this VcCredentials.
        :return: The ssl_thumbprint of this VcCredentials.
        :rtype: :class:'str'
        """
        return self._ssl_thumbprint

    @property
    def saml_token(self):
        """
        Gets the saml_token of this VcCredentials.
        :return: The saml_token of this VcCredentials.
        :rtype: :class:'str'
        """
        return self._saml_token

    @classmethod
    def from_dict(cls, vc_creds_dict) -> 'VcenterCredentials':
        """
        Constructs a VcenterCredentials object from a Python dict object.
        :param vc_creds_dict: The vCenter credentials of this Sddc.
        :type vc_creds_dict: Python dictionary
        :return: a new VcCredentials object.
        :rtype: :class:'VcCredentials'
        """
        return VcenterCredentials(**vc_creds_dict)


class SddcCredentials:
    def __init__(self, vc_creds: VcenterCredentials):
        """
        Initialize SddcCredentials
        :param vc_creds: The vCenter credentials of this Sddc.
        :type vc_creds: VcenterCredentials
        """

        self._vc_creds = vc_creds

    @property
    def vc_creds(self):
        """
        Gets the vc_creds of this SddcCredentials.
        :return: The vc_creds of this SddcCredentials.
        :rtype: VcenterCredentials
        """
        return self._vc_creds

