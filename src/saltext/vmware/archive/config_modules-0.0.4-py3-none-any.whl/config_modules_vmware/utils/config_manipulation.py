# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum, auto
import importlib
import logging


logger = logging.getLogger(__name__)


class Operations(Enum):
    """
    Enum Class to define config operations.
    """
    GET = "get"
    SET = "set"
    PRECHECK = "precheck"
    REMEDIATE = "remediate"


class SetStatus(Enum):
    """
    Enum Class to define config operations.
    """
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


class ConfigManipulation:
    """
    This class provides framework for getting, setting and doing precheck operations on a template of
    configs mapped to python functions.
    """

    @staticmethod
    def operate(context, host_ref, config_template, operation: Operations, apply_values=None):
        """
        Performs requested Operation on config_template
        :param context: The Context that can be used by the config classes to retrieve value.
        :type context: Context
        :param host_ref: The Pyvmomi object that can be used by the config classes to retrieve value.
        :type host_ref: pyvmomi HostRef
        :param config_template: Map of requested config values to be operated on.
        :type config_template: dict
        :param operation: Operation to perform
        :type operation: Operations
        :param apply_values: For set/remediate/precheck new values that should be set or checked.
        :type apply_values: dict
        """
        if config_template is None:
            err_msg = "config_template cannot be None."
            logger.error(err_msg)
            raise Exception(err_msg)
        if operation == Operations.GET:
            config = {}
            ConfigManipulation.get_all_items(config_template, config, context, host_ref)
            return config
        elif operation == Operations.SET or operation == Operations.REMEDIATE:
            if apply_values is None:
                err_msg = f"apply_values cannot be None for {operation.name} operation."
                logger.error(err_msg)
                raise Exception(err_msg)
            result_status_list = {SetStatus.SUCCESS.value: list(), SetStatus.FAILED.value: list()}
            ConfigManipulation.set_all_items(config_template, result_status_list, context, host_ref, apply_values, "", operation.value)
            return result_status_list
        elif operation == Operations.PRECHECK:
            if apply_values is None:
                err_msg = "apply_values cannot be None for PRECHECK operation."
                logger.error(err_msg)
                raise Exception(err_msg)
            result_status = {}
            ConfigManipulation.precheck_all_items(config_template, result_status, context, host_ref, apply_values, "")
            return result_status

    @staticmethod
    def get_class(module_path):
        try:
            partition = module_path.rpartition('.')
            module_str = partition[0]
            class_str = partition[2]
            module = importlib.import_module(module_str)
            return getattr(module, class_str)
        except Exception as e:
            logger.error(f"Could not load module from path {module_path}. {e}")
            return None

    @staticmethod
    def get_all_items(config_template, result_config, context, host_ref):
        for key, value in config_template.items():
            if type(value) is dict:
                if key not in result_config:
                    result_config[key] = {}
                ConfigManipulation.get_all_items(value, result_config[key], context, host_ref)
            else:
                class_ref = ConfigManipulation.get_class(value)
                if class_ref is None:
                    continue
                result_config[key] = class_ref().get(context, host_ref)

    @staticmethod
    def set_all_items(config_template, result_status, context, host_ref, apply_values, path, function_name):
        path += '/'
        for key, value in config_template.items():
            if key not in apply_values:
                err_msg = f"New value not supplied for key {path+key}. Not continuing with {function_name} operation"
                logger.error(err_msg)
                result_status[SetStatus.FAILED.value].append(path+key)
                raise Exception(err_msg)
            if type(value) is dict:
                ConfigManipulation.set_all_items(value, result_status, context, host_ref, apply_values[key], path + key, function_name)
            else:
                class_ref = ConfigManipulation.get_class(value)
                if class_ref is None:
                    result_status[SetStatus.FAILED.value].append(path+key)
                    err_msg = f"Config class for {path+key} not found. Not continuing with {function_name} operation"
                    raise Exception(err_msg)
                config_obj = class_ref()
                current_value = config_obj.get(context, host_ref)
                if current_value == apply_values[key]:
                    logger.debug(f"Current value [{current_value}] already equals new apply value {apply_values[key]}."
                                 f" Not performing {function_name} operation for key {path+key}")
                    result_status[SetStatus.SUCCESS.value].append(path+key)
                    continue
                operation_function = getattr(config_obj, function_name, None)
                if operation_function is not None and operation_function(context, host_ref, apply_values[key]):
                    result_status[SetStatus.SUCCESS.value].append(path+key)
                else:
                    result_status[SetStatus.FAILED.value].append(path+key)
                    err_msg = f"Setting value for key {path+key} failed. Not continuing with {function_name} operation"
                    raise Exception(err_msg)

    @staticmethod
    def precheck_all_items(config_template, result_config, context, host_ref, apply_values, path):
        path += '/'
        for key, value in config_template.items():
            if key not in apply_values:
                logger.error(f"New value not supplied for key {path+key}")
                result_config[key] = 'UNKNOWN'
                continue
            if type(value) is dict:
                if key not in result_config:
                    result_config[key] = {}
                ConfigManipulation.precheck_all_items(value, result_config[key], context, host_ref, apply_values[key], path + key)

            else:
                class_ref = ConfigManipulation.get_class(value)
                if class_ref is None:
                    continue
                result_config[key] = class_ref().precheck(context, host_ref, apply_values[key])
