# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
import json
import os
import uuid
from config_modules_vmware.utils.utils import get_template_json

logger = logging.getLogger(__name__)

#
# define config names supported for get specific configurations
#
STANDARD_CONFIGS = [
    'config.profile.esx.network.vmknics.mtu',
    'config.profile.esx.network.firewall.enabled',
    'config.profile.esx.network.firewall.default_action',
    'config.profile.esx.network_vss.switches.mtu',
    'config.profile.esx.network_vss.switches.policy.security.allow_promiscuous',
    'config.profile.esx.network_vss.switches.policy.security.forged_transmits',
    'config.profile.esx.network_vss.switches.policy.security.mac_changes'
]

EXTENDED_CONFIGS = [
    'extended_config.profile.esx.services.cim_service_enabled',
    'extended_config.profile.esx.services.shell_service_enabled',
    'extended_config.profile.esx.services.slp_service_enabled',
    'extended_config.profile.esx.services.snmp_service_enabled',
    'extended_config.profile.esx.services.ssh_service_enabled'#,
    # 'extended_config.profile.esx.security.lockdown_mode',
    # 'extended_config.profile.esx.security.lockdown_exception_users'
]

GET_CONFIG_TEMPLATE = 'config_mapping.json'
KNOWN_KEEP_KWORDS_SET =\
        ['clusters', 'hosts', 'moid', 'name', 'host-specific', 'host-override', \
         'standalone_hosts', 'device']
SPECIAL_KEY_SET = ['moid', 'name', 'device']

class ConfigTemplate:

    @staticmethod
    def check_input_configs(configs):
        """
        check if input parameters are valid
        """
        if configs:
            if configs == '*':
                return True
            else:
                for config in configs:
                    if config not in STANDARD_CONFIGS and config not in EXTENDED_CONFIGS:
                        logger.error(F"Invalid config name: {config}")
                        return False
        return True

    @staticmethod
    def is_valid_uuid(value):
        """
        check if this is a valid uuid.
        """
        try:
            uuid.UUID(str(value))
            return True
        except ValueError:
            return False

    @staticmethod
    def build_path(key):
        """
        build key path, ignore some known keys needed for every path.
        """
        if key in KNOWN_KEEP_KWORDS_SET:
            return False
        if ConfigTemplate.is_valid_uuid(key):
            return False
        return True

    @staticmethod
    def check_str_match(path, fpath):
        """
        check if path str match with filter path str
        """
        path_len = len(path)
        if path_len > len(fpath):
            return False
        return path == fpath[:path_len]

    @staticmethod
    def check_path_match(property_path, filter_property_paths):
        """
        check if path is match
        """
        if not property_path:
            return True
        for fpath in filter_property_paths:
            if ConfigTemplate.check_str_match(property_path, fpath):
                logger.info(F"Path matched: path - {property_path}, fpath - {fpath}")
                return True
        return False

    @staticmethod
    def build_on_path(filter_property_paths, property_path, values = None, key = None):
        """
        build key value pair based on input config names and base template file
        filter out un needed key/value pairs if not interested.
        """
        result = {}

        #
        # continue filtering if typs is dictionary.
        #
        if isinstance(values, dict):
            logger.info(F"Dict instance - key: {key}, value: {values}")
            for nkey, value in values.items():
                if ConfigTemplate.build_path(nkey):
                    npath = F'{property_path}.{nkey}' if property_path else nkey
                else:
                    npath = property_path
                if ConfigTemplate.check_path_match(npath, filter_property_paths):
                    if isinstance(value, list):
                        result[nkey] = []
                        for indx, item in enumerate(value):
                            logger.info(F"List element - index: {indx}, item: {item}")
                            #
                            # add filter here later, now just accept all.
                            #
                            result[nkey].append(ConfigTemplate.build_on_path(
                                            filter_property_paths, npath, values=item, key=indx))
                    else:
                        result[nkey] = ConfigTemplate.build_on_path(
                                       filter_property_paths, npath, values=value, key=nkey)
                else:
                    logger.info(F"Ignores: nkey: {nkey}, value: {value}, path: {npath}, fpaths: {filter_property_paths}")
        else:
            #
            # check if value is array.
            #
            if isinstance(values, list):
                result[key] = []
                for indx, item in enumerate(values):
                    #
                    # add filter here later, now just accept all.
                    #
                    result[key].append(ConfigTemplate.build_on_path(
                                            filter_property_paths, property_path, values=item, key=indx))
                return result
            else:
                return values
        return result

    @staticmethod
    def build_config_sets(configs):
        """
        build filter key path based on input config names
        """
        standard_configs = list()
        extended_configs = list()
        for config in configs:
            if config in STANDARD_CONFIGS:
                standard_configs.append(config)
            else:
                extended_configs.append(config)
        logger.info(F"Standard configs: {standard_configs}, Extended configs: {extended_configs}")
        return standard_configs, extended_configs

    @staticmethod
    def is_special_key(key):
        """
        some special keys in the path need to be considered based on
        different conditions, for example name and moid in a host or
        cluster need to be based on if other key/value pairs exist
        """
        if key in SPECIAL_KEY_SET:
            return True
        return False

    @staticmethod
    def is_empty_path(values):
        """
        function to check if a certain key path has empty key value.
        if one of of many key path fro a parent key is not empty, then
        that path is not empty.
        """
        result = True
        if isinstance(values, dict):
            logger.info(F"Dict instance - value: {values}")
            for nkey, value in values.items():
                if not ConfigTemplate.is_special_key(nkey):
                    if not ConfigTemplate.is_empty_path(value):
                        result = False
                    else:
                        logger.info(F"True(Empty): nkey: {nkey}, value: {value}")
        else:
            #
            # check if value is array.
            #
            if isinstance(values, list):
                for indx, item in enumerate(values):
                    #
                    # add filter here later, now just accept all.
                    #
                    if not ConfigTemplate.is_empty_path(item):
                        result = False
            else:
                logger.info(F"Final value: {values}")
                return False
        return result

    @staticmethod
    def filter_empty_path(values = None, key = None):
        """
        function to filter out empty path such as config: {} in the output
        """
        result = {}

        #
        # continue filtering if typs is dictionary.
        #
        if isinstance(values, dict):
            logger.info(F"Dict instance - key: {key}, value: {values}")
            for nkey, value in values.items():
                if not ConfigTemplate.is_empty_path(value):
                    if isinstance(value, list):
                        result[nkey] = []
                        for indx, item in enumerate(value):
                            logger.info(F"List element - index: {indx}, item: {item}")
                            #
                            # avoid empty list element.
                            #
                            if not ConfigTemplate.is_empty_path(item):
                                result[nkey].append(ConfigTemplate.filter_empty_path(values=item, key=indx))
                    else:
                        if not ConfigTemplate.is_special_key(nkey):
                            result[nkey] = ConfigTemplate.filter_empty_path(values=value, key=nkey)
                        else:
                            #
                            # not filter out names, such as switch name, moid fields if the path is
                            # not empty for example the mtu is on the path.
                            #
                            if not ConfigTemplate.is_empty_path(values):
                                result[nkey] = ConfigTemplate.filter_empty_path(values=value, key=nkey)
                else:
                    logger.info(F"Ignores(empty): nkey: {nkey}, value: {value}")
        else:
            #
            # check if value is array.
            #
            if isinstance(values, list):
                logger.info(F"List instance - key: {key}, value: {values}")
                result[key] = []
                for indx, item in enumerate(values):
                    #
                    # avoid empty list element.
                    #
                    if not ConfigTemplate.is_empty_path(item):
                        result[key].append(ConfigTemplate.filter_empty_path(values=item, key=indx))
            else:
                return values
        return result

    @staticmethod
    def build_config_template(configs = None):
        """
        Build config template based on input "configs"
        para configs- a set of config names:
        type: list['str']
                'config.esx.network.vmknics.mtu',
                'config.esx.network.firewall.enabled',
                'config.esx.network_vss.switches.mtu',
                'config.esx.network_vss.switches.policy.security.allow_promiscuous',
                'config.esx.network_vss.switches.policy.security.forged_transmits',
                'config.esx.network_vss.switches.policy.security.mac_changes'
                'extended_config.esx.services.cim_service_enabled',
                'extended_config.esx.services.shell_service_enabled',
                'extended_config.esx.services.slp_service_enabled',
                'extended_config.esx.services.snmp_service_enabled',
                'extended_config.esx.services.ssh_service_enabled',
                'extended_config.esx.security.lockdown_mode',
                'extended_config.esx.security.lockdown_exception_users'
        """

        logger.info(F"Input Configs: {configs}")
        curr_dir = os.path.dirname(__file__)
        data = get_template_json(os.path.join(curr_dir, GET_CONFIG_TEMPLATE))
        extended_template = {}
        extended_template['extended_config'] = data.get('extended_config')
        standard_template = {}
        #
        # if input configs is '*' or None , means all configs
        # for PoC project
        #
        if not configs:
            standard_template['config'] = '*'
            return standard_template, extended_template
        else:
            standard_template['config'] = data.get('config')
            if configs == '*':
                return standard_template, extended_template
        #
        # build a sets of key for filtering template
        #
        standard_configs, extended_configs = ConfigTemplate.build_config_sets(configs)
        logger.info(F"standard configs: {standard_configs}, extended configs: {extended_configs}")
        if standard_configs:
            standard_sets = ConfigTemplate.build_on_path(standard_configs, "", values = standard_template)
            standard_sets = ConfigTemplate.filter_empty_path(values=standard_sets)
        else:
            standard_sets = None
        if extended_configs:
            extended_sets = ConfigTemplate.build_on_path(extended_configs, "", values = extended_template)
            extended_sets = ConfigTemplate.filter_empty_path(values=extended_sets)
        else:
            extended_sets = None
        logger.info(F"Generated config template: {standard_sets}, extended template: {extended_sets}")
        return standard_sets, extended_sets

    @staticmethod
    def apply_filter(cluster_config, filter_list):
        """
        para cluster_config
        type: json object

        para filter_list- a set of config names or '*' (all configs)
        type: list['str']
                'config.profile.esx.network.vmknics.mtu',
                'config.profile.esx.network.firewall.enabled',
                'config.profile.esx.network_vss.switches.mtu',
                'config.profile.esx.network_vss.switches.policy.security.allow_promiscuous',
                'config.profile.esx.network_vss.switches.policy.security.forged_transmits',
                'config.profile.esx.network_vss.switches.policy.security.mac_changes'
                'extended_config.profile.esx.services.cim_service_enabled',
                'extended_config.profile.esx.services.shell_service_enabled',
                'extended_config.profile.esx.services.slp_service_enabled',
                'extended_config.profile.esx.services.snmp_service_enabled',
                'extended_config.profile.esx.services.ssh_service_enabled',
                'extended_config.profile.esx.security.lockdown_mode',
                'extended_esx.security.lockdown_exception_users'
        """
        if filter_list is None or filter_list == '*':
            return cluster_config
        cluster_config = ConfigTemplate.build_on_path(filter_list, "", cluster_config)
        cluster_config = ConfigTemplate.filter_empty_path(values=cluster_config)
        return cluster_config
