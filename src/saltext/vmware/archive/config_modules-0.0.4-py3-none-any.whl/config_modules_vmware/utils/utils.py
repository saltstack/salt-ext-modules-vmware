# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential

import logging
import json
from pyVmomi import vim

logger = logging.getLogger(__name__)


def get_template_json(filepath):
    """Read json file, convert it to object before returning to caller"""
    logger.info(f"Read the {filepath} in memory.")
    with open(filepath) as json_file:
        data = json.load(json_file)
    return data


def invoke_advanced_option_query(host_ref, prefix):
    """
    Query config manager advanced option using prefix
    :param host_ref: Host object reference of type vim.HostSystem
    :param prefix: str query
    :return: List of option values of type vim.option.OptionValue
    """

    options = None
    try:
        options = host_ref.configManager.advancedOption.QueryOptions(prefix)
    except vim.fault.InvalidName:
        logger.error(F"Invalid name for query param: {prefix} while querying for "
                     F"advanced options for host: {host_ref.name}")
    except Exception as e:
        logger.error(F"General error occurred for query param: {prefix} while querying for "
                     F"advanced options for host: {host_ref.name} with error msg: {e}")

    return options


def get_data_using_esxcli(context, host_ref, name_space, command, query_string=None):
    """Fetch data using esxcli for Advanced System Settings
     :param context: sddc context for login credentials
     :param host_ref: Host object reference of type vim.HostSystem
     :param name_space: esxcli name space
     :param command: esxcli command
     return: exscli output, list of string
    """
    try:
        esxcli_client = context.esxcli_client().host(host_ref.name). \
            namespace(name_space).command(command)
        if query_string is not None:
            esxcli_client = esxcli_client.command_options(query_string)
        return esxcli_client.execute()
    except Exception as e:
        logger.error(f'Error while fetching data for {name_space} {command} using esxcli, '
                    f'exception {str(e)}')
