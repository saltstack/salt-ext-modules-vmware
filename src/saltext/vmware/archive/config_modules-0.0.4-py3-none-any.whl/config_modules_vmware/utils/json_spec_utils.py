# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json

class JSONSpecUtils:
    """
    Utility class for operating on for JSON specifications - comparing two spec, getting all paths and values,
    filtering of JSON etc
    """

    @staticmethod
    def compare_specs_and_report_differences(json_obj1, json_obj2, path=""):
        """
        :param json_obj1: The first JSON-like object to compare.
        :type json_obj1: dict or list or any

        :param json_obj2: The second JSON-like object to compare.
        :type json_obj2: dict or list or any

        :param path: (Optional) A string representing the current path in the objects.
        :type path: str

        :return: A dictionary containing differences between the two objects, where keys represent paths to differing
                elements and values are tuples (obj1, obj2) showing the differences.
        :rtype: dict

        This function recursively compares two JSON-like objects (dictionaries or lists) and reports their differences.
        It returns a dictionary where each key is a path to a differing element and each value is a tuple (obj1, obj2)
        showing the differences between obj1 and obj2.
        """
        differences = {}

        if type(json_obj1) != type(json_obj2):
            differences[path] = (json_obj1, json_obj2)
            return differences

        if isinstance(json_obj1, dict):
            for key in json_obj1:
                new_path = f"{path}/{key}" if path else key
                if key in json_obj2:
                    sub_differences = JSONSpecUtils.compare_specs_and_report_differences(json_obj1[key],
                                                                                        json_obj2[key],
                                                                                        new_path)
                    differences.update(sub_differences)
                else:
                    differences[new_path] = (json_obj1[key], None)

            for key in json_obj2:
                new_path = f"{path}/{key}" if path else key
                if key not in json_obj1:
                    differences[new_path] = (None, json_obj2[key])
        elif isinstance(json_obj1, list):
            if len(json_obj1) != len(json_obj2):
                differences[path] = (json_obj1, json_obj2)
            else:
                for i in range(len(json_obj1)):
                    new_path = f"{path}/{i}"
                    sub_differences = JSONSpecUtils.compare_specs_and_report_differences(json_obj1[i],
                                                                                        json_obj2[i],
                                                                                        new_path)
                    differences.update(sub_differences)
        else:
            if json_obj1 != json_obj2:
                differences[path] = (json_obj1, json_obj2)

        return differences
