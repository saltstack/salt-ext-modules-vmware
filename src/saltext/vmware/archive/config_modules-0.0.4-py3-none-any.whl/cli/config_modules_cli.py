#!/usr/local/bin/python
# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import click
import logging
import os.path
import sys

sys.path.append(f"{os.path.abspath(os.path.dirname(os.path.dirname(__file__)))}")
sys.path.append(f"{os.path.abspath(os.path.dirname(os.path.dirname(__file__)))}/config_modules_vmware")

from config_modules_vmware.esxi.esx_config_modules import EsxConfigModulesEnum
from cli.cli_utils import cli_utils
from cli.cli_utils import cli_log_formatter
from cli.cli_utils.product_modules import ProductModulesEnum
from cli.cli_types.module_choice_type import ModuleChoiceType

logger = logging.getLogger(__name__)
CONTEXT_SETTINGS = dict(help_option_names=['-h', '--help'])
ESX_SUBMODULES = ModuleChoiceType(EsxConfigModulesEnum, case_sensitive=False)
PRODUCT_MODULES = ModuleChoiceType(ProductModulesEnum, case_sensitive=False)


@click.group(help='Manage configurations and drifts', context_settings=CONTEXT_SETTINGS)
@click.option('--log-config', default=cli_log_formatter.DEFAULT_LOGGING_CONFIG,
              help='Path to logging config json file.', show_default=True)
@click.option('--trace-id', help='Process trace ID for logging.')
def config_cli(log_config, trace_id):
    """
    Base entrypoint for CLI. Could add global options, configurations or setup if needed.
    """
    cli_log_formatter.configure_main_root_logger(log_config, trace_id)


@config_cli.group(help='Command to get and set specific configurations.',
                  short_help='Command to get and set specific configurations.')
def config():
    """
    Subcommand for CLI. Named for the object being worked on.
                        Following subcommands will be verbs of what action to perform on this object.
    """
    pass


@config.command('get', help='Gets the current configuration of product extension.',
                short_help='Gets the current configuration of product extension.')
@click.option('-p', '--product', type=PRODUCT_MODULES, callback=PRODUCT_MODULES.module_formatter, required=True,
              help='Product category. (e.g., \'esx\')')
@click.option('-vc', '--vc-fqdn', required=True, help='VCenter FQDN.')
@click.option('-au', '--auth-url', help='URL to retrieve VC SAML auth token from.')
@click.option('-u', '--username',
              help='If the auth-url is provided, username for auth URL request. Otherwise username for VC.')
@click.option('-pw', '--password',
              help='If the auth-url is provided, password for auth URL request. Otherwise password for VC. ('
                   'env:VAR_NAME to specify an environemnt variable)')
@click.option('-t', '--ssl-thumbprint',
              help='VC ssl_thumbprint to connect with username/password.')
@click.option('-at', '--auth-token',
              help='directly insert saml token for development purposes. Hidden from help message.',
              hidden=True)
@click.option('--cluster', help='Cluster MOID. Option can be invoked multiple times.', multiple=True, default=[])
@click.option('--host', help='Host MOID. Option can be invoked multiple times.', multiple=True, default=[])
@click.option('-s', '--sub-module', type=ESX_SUBMODULES, multiple=True, callback=ESX_SUBMODULES.module_formatter,
              help="One or more submodules for ESX config")
@click.option('--include-defaults', help='Option to include or exlude default values', default=True, is_flag=True)
@click.option('--enable-vlcm-flow', help='Option to include or exlude default values', default=False, is_flag=True,
              envvar='ENABLE_VLCM_FLOW')
def get_config(product, vc_fqdn, auth_url, username, password, ssl_thumbprint, auth_token, **kwargs):
    """
    Get subcommand under Config. (i.e. config-modules-cli config get ...).
    Retrieve config from requested product.
    :param product: Product name.
    :param vc_fqdn: VCenter fqdn.
    :param auth_url: URL to retrieve SAML auth token from.
    :param username: If the auth-url is provided, username for auth URL request. Otherwise username for VC.
    :param password: If the auth-url is provided, password for auth URL request. Otherwise password for VC.
                    Can be an environment variable in which case it should start with "env:"
    :param ssl_thumbprint: VCenter thumbprint used when connecting with credentials.
    :param auth_token: VCenter SAML auth token.
    :param kwargs:
        cluster: list of cluster MOIDs for EsxConfig
        host: list of host MOIDs for EsxConfig
        sub_module: list of submodules to include in the EsxConfig
    """
    sddc_credentials = cli_utils.create_sddc_credentials(vc_fqdn, auth_url, username, password, ssl_thumbprint,
                                                         auth_token)

    context_cls = product.get_context()
    config_cls = product.get_config()

    context = context_cls.from_kwargs(sddc_credentials, **kwargs)
    #TODO: The below option 'context.config_agent_parity' is temporary
    # and should be removed upon completing the Advanced Options submodule performance improvements.
    # https://jira.eng.vmware.com/browse/SDDCCONFIG-705
    context.config_agent_parity = True
    with context:
        module = config_cls(context)
        try:
            req_kwargs = module.kwargs_for_get_configuration(**kwargs)
            current_config = module.get_configuration(**req_kwargs)
            print(cli_utils.config_post_processing(current_config))
        except Exception as e:
            err_msg = f'Error occurred: {str(e)}'
            cli_utils.exit_with_failure_message(err_msg)
            return


if __name__ == "__main__":
    config_cli()
