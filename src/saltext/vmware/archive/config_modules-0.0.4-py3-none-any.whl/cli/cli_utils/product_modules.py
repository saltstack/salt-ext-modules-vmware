# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
from enum import Enum

from config_modules_vmware.esxi.esx_config import EsxConfig
from config_modules_vmware.esxi.esx_config import EsxContext


class ProductModulesEnum(Enum):
    """
    Enum Class to define available config modules and values hold corresponding module context and class.
    """
    ESX = (EsxContext, EsxConfig)

    @staticmethod
    def choice_list():
        """
        Returns a list of names for this enum.
        """
        return [i.name for i in ProductModulesEnum]

    def get_context(self):
        """
        Get the first value from the Tuple (Context class)
        """
        return self.value[0]

    def get_config(self):
        """
        Get the second value from the Tuple (Config class)
        """
        return self.value[1]
