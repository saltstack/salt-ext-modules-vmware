# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json
import logging
import os
import requests

from config_modules_vmware.lib.common.credentials import VcenterCredentials
from config_modules_vmware.lib.common.credentials import SddcCredentials

logger = logging.getLogger(__name__)
MODULES_DIR = 'config_modules_vmware/'
IGNORED_CLASS_CHAR = '-_.'
CONFIG_KEY = 'config'
STATUS_KEY = 'status'
SUCCEEDED = 'SUCCEEDED'
FAILED = 'FAILED'


def _retrieve_auth_token(url, username, password):
    """
    Helper function that will make a REST GET call to the URL specified.
                        Uses Basic Auth with the provided username/password.
    :param url: URL of the service to retrieve the auth token from.
    :param username: username used for Basic Auth.
    :param password: password used for Basic Auth.
    :return: The token String from the response of the request. response['token'].
    """
    try:
        response = requests.get(url, auth=(username, password))
        response.raise_for_status()
        return response.json()['token']
    except requests.exceptions.RequestException as e:
        err_message = f'There was a problem connecting to auth url' \
                      ' to retrieve the saml token. Error info:\n{str(e.args)}'
        exit_with_failure_message(err_message)


def _create_vc_credentials(vc_fqdn, auth_url, username, password, ssl_thumbprint, auth_token):
    """
    Create a VC Credentials object from inputs.
    Reads the password from an environment variable if password starts with 'env:'.
    Retrieves SAML token if an auth_url is provided.
    """
    if password is not None and password[:4].lower() == "env:":
        env_var_name = password[4:]
        password = os.environ.get(env_var_name)
        if password is None:
            err_message = f'The environment variable {env_var_name} does not exist or cannot be accessed.'
            exit_with_failure_message(err_message)
    if auth_url is not None:
        auth_token = _retrieve_auth_token(auth_url, username, password) or auth_token
        username = None
        password = None
    return {'hostname': vc_fqdn,
            'password': password,
            'username': username,
            'ssl_thumbprint': ssl_thumbprint,
            'saml_token': auth_token}


def create_sddc_credentials(vc_fqdn, auth_url, username, password, ssl_thumbprint, auth_token):
    """
    Helper function to interpret CLI inputs and construct an appropriate SddcCredentials object.
    :param vc_fqdn: VCenter FQDN.
    :param auth_url: URL of the service to retrieve the auth token from. None if using another form of authentication.
    :param username: If the auth-url is provided, username for auth URL request. Otherwise username for VC.
    :param password: If the auth-url is provided, password for auth URL request. Otherwise password for VC.
                    Can be an environment variable in which case it should start with "env:".
    :param ssl_thumbprint: VC thumbprint used when connecting with credentials.
    :param auth_token: Directly input SAML auth token.
    :return: SddcCredentials object.
    """
    auth_dict = {'vc_conn':
                 _create_vc_credentials(vc_fqdn, auth_url, username, password, ssl_thumbprint, auth_token)}
    vc_creds = VcenterCredentials.from_dict(auth_dict['vc_conn'])

    return SddcCredentials(vc_creds=vc_creds)


def config_post_processing(config):
    if config is None:
        err_msg = 'Module did not return a config'
        exit_with_failure_message(err_msg)
    result_object = {
        STATUS_KEY: SUCCEEDED,
        CONFIG_KEY: config
    }
    return json.dumps(result_object, indent=4)


def exit_with_failure_message(err_message):
    """
    Helper function to take in an error message, log an error print an empty config with FAILED status,
                            and exit the process with a failed code.
    """
    logger.error(err_message)
    result_object = {}
    result_object['status'] = 'FAILED'
    result_object['config'] = {}
    print(json.dumps(result_object, indent=4))
    exit(err_message)
