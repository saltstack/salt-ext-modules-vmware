# Copyright 2023 VMware, Inc.  All rights reserved. -- VMware Confidential
import json
import os
import logging
import logging.config
from importlib.metadata import version, PackageNotFoundError


DEFAULT_LOGGING_CONFIG = f"{os.path.abspath(os.path.dirname(__file__))}/logging_config.json"


def _expand_env_variables(config):
    for key in config.keys():
        value = config.get(key)
        if isinstance(value, str):
            config[key] = os.path.expandvars(value)
        elif isinstance(value, dict):
            _expand_env_variables(value)


def read_config_from_file(file_path):
    with open(file_path, "r") as stream:
        config = json.load(stream)
        _expand_env_variables(config)
        return config


def configure_main_root_logger(log_config, trace_id):
    """
    Configure the logging module with a log format.
    """
    logging_config = read_config_from_file(log_config)
    if log_config == DEFAULT_LOGGING_CONFIG:
        handlers = os.getenv('AGENT_NAME', 'stdout')
        logging_config['loggers']['']['handlers'] = [handler.strip(' ') for handler in list(handlers.split(','))]
    logging.config.dictConfig(logging_config)
    old_factory = logging.getLogRecordFactory()
    try:
        cli_version = version("config-modules")
    except PackageNotFoundError:
        cli_version = None

    def record_factory(*args, **kwargs):
        record = old_factory(*args, **kwargs)
        record.CLI_VERSION = cli_version
        record.TRACE_ID = trace_id
        return record

    logging.setLogRecordFactory(record_factory)
